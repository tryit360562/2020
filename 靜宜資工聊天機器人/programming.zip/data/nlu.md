## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there
- 哈囉
- 哈
- 嗨
- 不好意思
- 你好

## intent:goodbye
- bye
- 掰掰
- see you around
- see you later
- 再見

## intent:affirm
- yes
- indeed
- of course
- that sounds good
- correct
- thanks
- 謝謝

## intent:deny
- no
- never
- I don't think so
- don't like that
- no way
- 沒有

## intent:mood_great
- perfect
- very good
- great
- amazing
- wonderful
- I am feeling very good
- I am great
- 我很好

## intent:mood_unhappy
- sad
- very sad
- unhappy
- bad
- very bad
- awful
- terrible
- not very good
- extremely sad
- 我好傷心
- 我很傷心
- i'm sad

## intent:bot_challenge
- 你是機器人嗎
- 你是真人嗎
- 我是在跟機器人對話嗎
- 我是在跟人對話嗎
- 我在跟人講話嗎
- 我在跟人對話嗎
- are you human
- am i talk to human

## intent:question_BotFuntion
- 請問我能問什麼
- 你有什麼功能
- 我能問什麼
- 能問你什麼呢

## intent:question_PU-live
- 有哪些宿舍
- 我想請問宿舍問題
- 關於宿舍問題
- 我想問關於宿舍的問題
- 宿舍問題
- 想請問宿舍問題
- 宿舍
- 怎麼抽宿舍

## intent:question_PU-traffic
- 怎麼到靜宜
- 靜宜大學怎麼走
- 交通問題
- 想請問交通問題
- 怎麼到靜宜大學
- 如何到靜宜大學
- 如何到靜宜
- 請問我在高鐵站這邊 靜宜要怎麼過去呢？
- 怎到靜宜

## intent:question_PU-map
- 主顧樓怎麼走
- 文興樓怎麼走
- 主顧樓在那
- 想請問怎麼走到主顧樓
- 主顧樓怎麼走呢
- 主顧樓

## intent:question_PU-traffic-car
- 坐汽車
- 汽車

## intent:question_PU-traffic-train
- 坐火車
- 火車

## intent:question_PU-traffic-car-route1
- 國道一
- 走國道一號
- 國道一號

## intent:question_PU-traffic-car-route3
- 國道三號
- 走國道三號

## intent:question_PU-traffic-speed rail
- 高鐵
- 坐高鐵

## intent:question_PU-traffic-bus
- 客運
- 坐客運
- 坐公車

## intent:question_PU-live-xijia
- 希嘉
- 希嘉學苑

## intent:question_PU-live-sigao
- 思高學苑
- 思高

## intent:question_PU-live-pu
- 靜宜會館
- 會館

## intent:question_PU-live-male
- 男生
- 男

## intent:question_PU-live-female
- 女
- 女生
