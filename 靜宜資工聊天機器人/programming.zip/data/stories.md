## happy path
* greet
  - utter_greet
* mood_great
  - utter_happy

## sad path 1
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* affirm
  - utter_happy

## sad path 2
* greet
  - utter_greet
* mood_unhappy
  - utter_cheer_up
  - utter_did_that_help
* deny
  - utter_goodbye

## say goodbye
* goodbye
  - utter_goodbye

## bot challenge
* bot_challenge
  - utter_iamabot

## PU map 
* greet
  - utter_greet
* question_BotFuntion
  - utter_greet
* question_PU-map
  - utter_PU-map

## PU live 
* greet
  - utter_greet
* question_BotFuntion
  - utter_greet
* question_PU-live
  - utter_PU-live

## PU traffic
* greet
  - utter_greet
* question_BotFuntion
  - utter_greet
* question_PU-traffic
  - utter_PU-traffic

## PU traffic_car_no.1
* greet
  - utter_greet
* question_PU-traffic
  - utter_PU-traffic
* question_PU-traffic-car
  - utter_PU-traffic-route
* question_PU-traffic-car-route1
  - utter_answer-PUtraffic-car1
* affirm
  - utter_happy

## PU traffic_car_no.3
* greet
  - utter_greet
* question_PU-traffic
  - utter_PU-traffic
* question_PU-traffic-car
  - utter_PU-traffic-route
* question_PU-traffic-car-route3
  - utter_answer-PUtraffic-car2-1
  - utter_answer-PUtraffic-car2-2
* affirm
  - utter_happy

## PU traffic_bus

* greet
    - utter_greet
* question_PU-traffic
    - utter_PU-traffic
* question_PU-traffic-bus
    - utter_answer-PUtraffic-bus1
    - utter_answer-PUtraffic-bus2
* affirm
    - utter_happy

## PU traffic_speed rail

* greet
    - utter_greet
* question_PU-traffic
    - utter_PU-traffic
* question_PU-traffic-speed rail
    - utter_answer-PUtraffic-speed rail01
    - utter_answer-PUtraffic-speed rail02
    - utter_answer-PUtraffic-speed rail03
* affirm
    - utter_happy

## PU traffic_train 
* greet
    - utter_greet
* question_PU-traffic
    - utter_PU-traffic
* question_PU-traffic-train
    - utter_answer-PUtraffic-train01
    - utter_answer_PUtraffic-train02
* greet
    - utter_happy

## PU live_xijia_male

* greet
    - utter_greet
* question_PU-live
    - utter_PU-live
* question_PU-live-xijia
    - utter_answer-PUlive-xijia01
    - utter_answer-PUlive-xijia02
    - utter_PUlive-gender
* question_PU-live-male
    - utter_answer-PUlive-xijia-male
* affirm
    - utter_happy

## PU live_xijia_female

* greet
    - utter_greet
* question_PU-live
    - utter_PU-live
* question_PU-live-xijia
    - utter_answer-PUlive-xijia01
    - utter_answer-PUlive-xijia02
    - utter_PUlive-gender
* question_PU-live-female
    - utter_answer-PUlive-xijia-female
* affirm
    - utter_happy

## PU live_sigao_female

* greet
    - utter_greet
* question_PU-live
    - utter_PU-live
* question_PU-live-sigao
    - utter_answer-PUlive-sigao01
    - utter_answer-PUlive-sigao02
    - utter_PUlive-gender
* question_PU-live-female
    - utter_answer-PUlive-sigao-female
* affirm
    - utter_happy

## PU live_pu_male

* greet
    - utter_greet
* question_PU-live
    - utter_PU-live
* question_PU-live-pu
    - utter_answer-PUlive-pu01
    - utter_answer-PUlive-pu02
    - utter_PUlive-gender
* question_PU-live-male
    - utter_answer-PUlive-pu-male
* affirm
    - utter_happy

## PU live_pu_female

* greet
    - utter_greet
* question_PU-live
    - utter_PU-live
* question_PU-live-pu
    - utter_answer-PUlive-pu01
    - utter_answer-PUlive-pu02
    - utter_PUlive-gender
* question_PU-live-female
    - utter_answer-PUlive-pu-female
* affirm
    - utter_happy

## PU live_sigao_male

* greet
    - utter_greet
* question_PU-live
    - utter_PU-live
* question_PU-live-sigao
    - utter_answer-PUlive-sigao01
    - utter_answer-PUlive-sigao02
    - utter_PUlive-gender
* question_PU-live-male
    - utter_answer-PUlive-sigao-male
