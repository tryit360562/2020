# image_positioning
USB0無權限問題解決方案：
sudo chmod 777 /dev/ttyUSB0
