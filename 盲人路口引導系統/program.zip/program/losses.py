import tensorflow as tf

def compute_loss(logits, localizations,
               gclasses, gscores, glocalizations,
               neg_ratio=3.):
	
	lshape = gclasses.get_shape().as_list()
	batch_size = lshape[0]
	n_anchors = lshape[1]

	pmask = gscores > 0.

	nmask = tf.logical_not(pmask)

	n_positives = tf.reduce_sum(tf.cast(pmask, tf.float32))

	n_negatives = tf.reduce_sum(tf.cast(nmask, tf.int32))

	cross_entropy = tf.keras.losses.SparseCategoricalCrossentropy(
            from_logits=True, reduction='none')

	class_loss = cross_entropy(gclasses, logits)

	num_neg_max = tf.minimum(n_negatives, tf.cast(neg_ratio * n_positives, tf.int32))

	negatives = tf.where(nmask, class_loss, tf.zeros_like(class_loss))

	negatives_ids = tf.argsort(negatives, direction='DESCENDING')
	negatives_ids = tf.argsort(negatives_ids)

	negatives_max_mask = tf.less(negatives_ids, num_neg_max)
	cross_entropy = tf.keras.losses.SparseCategoricalCrossentropy(
            from_logits=True, reduction='sum')

	conf_loss = cross_entropy(gclasses[tf.logical_or(pmask, negatives_max_mask)],
                				logits[tf.logical_or(pmask, negatives_max_mask)])

	
	smooth_l1_loss = tf.keras.losses.Huber(reduction='sum')

	loc_loss = smooth_l1_loss(glocalizations[pmask], localizations[pmask])


	conf_loss = tf.math.divide(conf_loss, n_positives)
	loc_loss =  tf.math.divide(loc_loss, n_positives)
	

	return conf_loss, loc_loss





