import tensorflow as tf

def _corner_to_center(bboxes):
    
    cx = (bboxes[..., 0] + bboxes[..., 2]) / 2.
    cy = (bboxes[..., 1] + bboxes[..., 3]) / 2.
    w = bboxes[..., 2] - bboxes[..., 0]
    h = bboxes[..., 3] - bboxes[..., 1]

    return tf.stack([cx, cy, w, h], axis=-1)

def _center_to_corner(bboxes):
	

	xmin = bboxes[..., 0] - bboxes[..., 2] / 2.
	ymin = bboxes[..., 1] - bboxes[..., 3] / 2.
	xmax = bboxes[..., 0] + bboxes[..., 2] / 2.
	ymax = bboxes[..., 1] + bboxes[..., 3] / 2.

	return tf.stack([xmin, ymin, xmax, ymax], axis=-1)

def _iter_area(bboxes, anchor_bboxes):

	xmin = tf.maximum(bboxes[..., 0], anchor_bboxes[..., 0])
	ymin = tf.maximum(bboxes[..., 1], anchor_bboxes[..., 1])
	xmax = tf.minimum(bboxes[..., 2], anchor_bboxes[..., 2])
	ymax = tf.minimum(bboxes[..., 3], anchor_bboxes[..., 3])

	h = tf.maximum(ymax - ymin, 0.)
	w = tf.maximum(xmax - xmin, 0.)

	return h * w

def _compute_area(bboxes):
	return (bboxes[..., 2] - bboxes[..., 0]) * (bboxes[..., 3] - bboxes[..., 1])

def _compute_IOU(bboxes, anchor_bboxes):
	
	corner_anchors = _center_to_corner(anchor_bboxes)
	iter_area = _iter_area(bboxes, corner_anchors)

	bboxes_area = _compute_area(bboxes)

	anchor_bboxes_area = _compute_area(corner_anchors)
	
	union_area = bboxes_area + anchor_bboxes_area - iter_area

	return iter_area / union_area

def _encode(encoded_bboxes, anchor_tensor, variable):

	yref = anchor_tensor[..., 0]
	xref = anchor_tensor[..., 1]
	h = anchor_tensor[..., 2]
	w = anchor_tensor[..., 3]

	cy = encoded_bboxes[..., 0]
	cx = encoded_bboxes[..., 1]
	h = encoded_bboxes[..., 2]
	w = encoded_bboxes[..., 3]

	_cy = (cy - yref) / href / variable[..., 0]
	_cx = (cx - xref) / wref / variable[..., 1]
	_h = tf.log(h / href) / variable[..., 2]
	_w = tf.log(w / wref) / variable[..., 3]

	return tf.stack([_cy, _cx, h, w], axis=-1)