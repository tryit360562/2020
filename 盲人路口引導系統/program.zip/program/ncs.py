from openvino.inference_engine import IECore
import os
import cv2
import tensorflow as tf
import numpy as np
from time import time
from time import sleep
from PyQt5.QtGui import QPixmap, QImage
import threading
import queue

def computeIOU(max_box, less_box):
    def _iter_area(box1, box2):
        
        ymin = np.maximum(box1[..., 0], box2[..., 0])
        xmin = np.maximum(box1[..., 1], box2[..., 1])
        ymax = np.minimum(box1[..., 2], box2[..., 2])
        xmax = np.minimum(box1[..., 3], box2[..., 3])

        h = np.maximum(ymax - ymin, 0)
        w = np.maximum(xmax - xmin, 0)

        return h * w

    def _area(box):
        return (box[..., 2] - box[..., 0]) * (box[..., 3] - box[..., 1])

    iter_area = _iter_area(max_box, less_box)
    max_area = _area(max_box)
    less_area = _area(less_box)

    union_area = max_area + less_area - iter_area

    return iter_area / union_area

def NON_MAX_SEPRESSION(oclasses, oscores, obboxes, top_k=400, threshold=0.5):
    
    sor = np.argsort(-oscores)

    max_top = np.minimum(top_k, oscores[sor].shape[0])
    o_classes = oclasses[sor][:max_top]
    o_scores = oscores[sor][:max_top]
    o_bboxes = obboxes[sor][:max_top]

    o_scores_cp = o_scores.copy()
    example_tensor = np.ones_like(o_scores_cp)
    result_tensor = np.zeros_like(o_scores_cp)

    while np.sum(example_tensor) != 0:
        this_max = np.argmax(o_scores_cp)
        o_scores_cp[this_max] = 0
        example_tensor[this_max] = 0
        result_tensor[this_max] = 1

        IOU = computeIOU(o_bboxes[this_max], o_bboxes)
        filter_IOU = np.where(np.equal(example_tensor, 1), IOU, np.zeros_like(example_tensor))

        filter_mask = filter_IOU > threshold
        example_tensor[filter_mask] = 0

    result_mask = result_tensor.astype(np.bool)

    result_classes = o_classes[result_mask]
    result_scores = o_scores[result_mask]
    result_bboxes = o_bboxes[result_mask]

    return result_classes, result_scores, result_bboxes

def process_ssd_result(r_scores, r_bboxes, IMG_SIZE, ori_w, ori_h):

    rclasses = np.argmax(r_scores, axis=-1)
    rscores = np.max(r_scores, axis=-1)

    pmask = rscores > 0.
    pmask = np.logical_and(pmask, rclasses > 0)

    oclasses = rclasses[pmask]

    if not np.any(oclasses):
        return [], []

    oscores = rscores[pmask]
    obboxes = np.clip(r_bboxes[pmask], 0.0, 1.0)
    oclasses, oscores, obboxes = NON_MAX_SEPRESSION(oclasses, oscores, obboxes, top_k=1)
    
    for i in range(oscores.shape[0]):
        clas_ = oclasses[i]
        conf_ = oscores[i]
        box = obboxes[i]

        ymin, xmin, ymax, xmax = (box * IMG_SIZE).astype(np.int32)
        
        if [ymin, ymax, xmin, xmax] == [0, 0, IMG_SIZE, IMG_SIZE] or \
           (ymin >= ymax) or (xmin >= xmax):
            return [], []
        cc_xmin = int(xmin / IMG_SIZE * ori_w)
        cc_ymin = int(ymin / IMG_SIZE * ori_h)
        cc_xmax = int(xmax / IMG_SIZE * ori_w)
        cc_ymax = int(ymax / IMG_SIZE * ori_h)
        
        cc_w = cc_xmax - cc_xmin
        cc_h = cc_ymax - cc_ymin
        
        add_w = int(cc_w * 1.2) - cc_w
        add_h = int(cc_h * 1.2) - cc_h
        
        offset_min = 3
        offset_max = 7
        
        if int(add_w * 0.3) < offset_min or int(add_h * 0.7) < offset_max:
            cc_xmin -= offset_min
            cc_ymin -= offset_min
            cc_xmax += offset_max
            cc_ymax += offset_max
        else:
            cc_xmin = int(cc_xmin - int(add_w * 0.3))
            cc_ymin = int(cc_ymin - int(add_h * 0.3))
            cc_xmax = int(cc_xmax + int(add_w * 0.7))
            cc_ymax = int(cc_ymax + int(add_h * 0.7))
        
        cc_xmin = np.clip(cc_xmin, 0, ori_w)
        cc_ymin = np.clip(cc_ymin, 0, ori_h)
        cc_xmax = np.clip(cc_xmax, 0, ori_w)
        cc_ymax = np.clip(cc_ymax, 0, ori_h)


        return [cc_xmin, cc_ymin, cc_xmax, cc_ymax], [xmin, ymin, xmax, ymax]


class multi_ncs(object):
    def __init__(self):
        self.model_names = ['ssd_300', 'ssd_512',
                       'single', 'second_green', 'second_red',
                       'left_green', 'left_red']
        self.model_path = './IR_model'

        self.classes = dict()

        self.classes[self.model_names[0]] = ['person_green', 'person_red']
        self.classes[self.model_names[1]] = ['person_green', 'person_red']
        self.classes[self.model_names[2]] = ['nothing', 'green', 'red']

        for i in range(3, 7):
            self.classes[self.model_names[i]] = ['nothing'] + [str(x) for x in range(10)]

        self.request_num = 16
        self.gap = 1
        self.init_queue()

        self.all_stop = False

        self.load_models()

    def set_gap(self, gap):
        self.gap = gap

    def stop_light(self):
        self.all_stop = True


    def start_light(self):
        self.all_stop = False


    def init_queue(self):
        self.queue = {'inputs':queue.Queue(maxsize=self.request_num * 3),
                    'outputs':queue.Queue(maxsize=self.request_num * 3),
                    'next':0,
                    'previous':{'clip_img':[],
                                'bbox':[],
                                'msg':''
                                }
            }


    def load_models(self):
        self.nets = dict()
        self.exec_nets = dict()
        self.ies = dict()
        self.inputs = dict()

        self.models = set([x.split('.')[0] for x in os.listdir(self.model_path)])

        
        ie = IECore()


        for i, filename in enumerate(self.models):
            model_xml = os.path.join(self.model_path, '{}.xml'.format(filename))
            model_bin = os.path.join(self.model_path, '{}.bin'.format(filename))

            if 'ssd' in filename.lower():
                filename2 = 'ssd_{}'.format(filename.split('_')[-1].split('-')[0])
            else:
                filename2 = filename[6:-4].lower()

            net = ie.read_network(model=model_xml, weights=model_bin)

            self.nets[filename2] = net
            self.ies[filename2] = ie

        for filename in self.model_names:
            load_time = time()
            self.exec_nets[filename] = ie.load_network(network=self.nets[filename], num_requests=self.request_num, device_name='MYRIAD')
            
            self.inputs[filename] = next(iter(self.exec_nets[filename].input_info))
        
    def get_start(self, request_id, IMG_SIZE):
        retangle_color = (255, 0, 0)

        while True:
            if self.all_stop:
                break

            empty = np.zeros(shape=[IMG_SIZE, IMG_SIZE + 200, 3], dtype=np.uint8) + 100
            start_h = int((IMG_SIZE - 160) / 2)
            start_w = int((IMG_SIZE + 200 - IMG_SIZE - 100) / 2)

            while True:
                if not self.queue['inputs'].empty():
                    now_data = self.queue['inputs'].get()
                    break
                if self.all_stop:
                    break
            if self.all_stop:
                break
            
            ori_img = now_data['img']

            ssd_name = 'ssd_{}'.format(IMG_SIZE)

            ori_h, ori_w, _ = ori_img.shape
            
            ori_img = ori_img[..., ::-1]
            frame = cv2.resize(ori_img, (IMG_SIZE, IMG_SIZE), cv2.INTER_AREA)
            
            empty[:IMG_SIZE, :IMG_SIZE] = frame[..., ::-1]
            
            if not now_data['detect']:

                if len(self.queue['previous']['bbox']) > 0:
                    previous = self.queue['previous']

                    cc_xmin, cc_ymin, cc_xmax, cc_ymax = previous['bbox']
                    clip_img_100 = previous['clip_img']
                    msg = previous['msg']

                    empty[start_h:start_h + 160, IMG_SIZE + start_w:IMG_SIZE + start_w + 100] = clip_img_100[..., ::-1]
                    cv2.rectangle(empty, (cc_xmin, cc_ymin), (cc_xmax, cc_ymax), retangle_color, 2)

                    cv2.line(empty, (cc_xmax, cc_ymin), (IMG_SIZE + start_w, start_h), (0, 0, 255), 2)
                    cv2.line(empty, (cc_xmax, cc_ymax), (IMG_SIZE + start_w, start_h + 160), (0, 0, 255), 2)

                    cv2.putText(empty, msg, (IMG_SIZE + start_w + 15, start_h + 160 + 20), 1, 1, (255, 255, 255), 2, cv2.LINE_AA)

                while True:
                    if self.all_stop:
                        break
                    if now_data['number'] == self.queue['next']:
                        self.queue['outputs'].put(empty)
                        self.queue['next'] += 1
                        break
                

                continue

            process_img = tf.expand_dims(frame.astype(np.float32), axis=0)
            process_img = tf.image.per_image_standardization(tf.math.divide(process_img, 255.))
            
            blob = np.array(process_img, dtype=np.float32).transpose(0, 3, 1, 2)

            ssd_time = time()
            self.exec_nets[ssd_name].start_async(request_id=request_id, inputs={self.inputs[ssd_name]:blob})
            
            t_time = time()
            if self.exec_nets[ssd_name].requests[request_id].wait(-1) == 0:

                ssd_out = self.exec_nets[ssd_name].requests[request_id].outputs
                r_bboxes, ori_bboxes = process_ssd_result(ssd_out['out_conf'], ssd_out['out_boxes'],
                                            IMG_SIZE, ori_w, ori_h)
                if len(r_bboxes) == 0:
                    while True:
                        if self.all_stop:
                            break
                        if now_data['number'] == self.queue['next']:

                            self.queue['outputs'].put(empty)
                            self.queue['previous'] = {
                                    'clip_img' : [],
                                    'bbox' : [],
                                    'msg':''
                                }

                            self.queue['next'] += 1
                            break
                    continue

                cc_xmin, cc_ymin, cc_xmax, cc_ymax = r_bboxes



                ori_clip_img = ori_img[cc_ymin:cc_ymax, cc_xmin:cc_xmax]
                clip_img = cv2.resize(ori_clip_img, (20, 32), cv2.INTER_AREA)
                clip_img_100 = cv2.resize(ori_clip_img, (100, 160), cv2.INTER_AREA)
                
                c_xmin, c_ymin, c_xmax, c_ymax = ori_bboxes
                               

                blob_single = np.expand_dims(np.array(clip_img, dtype=np.float32) / 255, axis=0).transpose(0, 3, 1, 2)
                
                single_time = time()
                self.exec_nets['single'].start_async(request_id=request_id, 
                                                    inputs={self.inputs['single']:blob_single})
                
                if self.exec_nets['single'].requests[request_id].wait(-1) == 0:

                    single_out = self.exec_nets['single'].requests[request_id].outputs[next(iter(self.exec_nets['single'].outputs))]
                    single_cls = self.classes['single'][np.argmax(single_out)]

                    if 'nothing' in single_cls:
                        cv2.rectangle(empty, (c_xmin, c_ymin), (c_xmax, c_ymax), retangle_color, 2)

                        empty[start_h:start_h + 160, IMG_SIZE + start_w:IMG_SIZE + start_w + 100] = clip_img_100[..., ::-1]
                        cv2.line(empty, (c_xmax, c_ymin), (IMG_SIZE + start_w, start_h), (0, 0, 255), 2)
                        cv2.line(empty, (c_xmax, c_ymax), (IMG_SIZE + start_w, start_h + 160), (0, 0, 255), 2)
                        
                        msg = 'nothing'
                        cv2.putText(empty, msg, (IMG_SIZE + start_w + 15, start_h + 160 + 20), 1, 1, (255, 255, 255), 2, cv2.LINE_AA)
                        
                        while True:
                            if self.all_stop:
                                break
                            if now_data['number'] == self.queue['next']:

                                self.queue['outputs'].put(empty)
                                self.queue['previous'] = {
                                        'clip_img' : clip_img_100,
                                        'bbox' : ori_bboxes,
                                        'msg':msg
                                    }
                                self.queue['next'] += 1
                                break
                        continue
                        
                        
                    second_name =  'second_{}'.format(single_cls)
                    left_name =  'left_{}'.format(single_cls)
                    sl_time = time()

                    self.exec_nets[second_name].start_async(request_id=request_id, 
                                                    inputs={self.inputs[second_name]:blob_single})
                    self.exec_nets[left_name].start_async(request_id=request_id, 
                                                    inputs={self.inputs[left_name]:blob_single})

                    if self.exec_nets[second_name].requests[request_id].wait(-1) == 0 and self.exec_nets[left_name].requests[request_id].wait(-1) == 0:

                        second_out = self.exec_nets[second_name].requests[request_id].outputs[next(iter(self.exec_nets[second_name].outputs))]
                        left_out = self.exec_nets[left_name].requests[request_id].outputs[next(iter(self.exec_nets[left_name].outputs))]

                        result_second =  self.classes[second_name][np.argmax(second_out)]
                        result_left =  self.classes[left_name][np.argmax(left_out)]

                        result = '{}{}'.format(result_second, result_left)


                        cv2.rectangle(empty, (c_xmin, c_ymin), (c_xmax, c_ymax), retangle_color, 2)

                        empty[start_h:start_h + 160, IMG_SIZE + start_w:IMG_SIZE + start_w + 100] = clip_img_100[..., ::-1]
                        cv2.line(empty, (c_xmax, c_ymin), (IMG_SIZE + start_w, start_h), (0, 0, 255), 2)
                        cv2.line(empty, (c_xmax, c_ymax), (IMG_SIZE + start_w, start_h + 160), (0, 0, 255), 2)
                        
                        msg = '{} : {}'.format(single_cls, result)
                        cv2.putText(empty, msg, (IMG_SIZE + start_w + 15, start_h + 160 + 20), 1, 1, (255, 255, 255), 2, cv2.LINE_AA)
                        
                        while True:
                            if self.all_stop:
                                break
                            if now_data['number'] == self.queue['next']:

                                self.queue['outputs'].put(empty)
                                self.queue['previous'] = {
                                        'clip_img' : clip_img_100,
                                        'bbox' : ori_bboxes,
                                        'msg':msg
                                    }
                                self.queue['next'] += 1
                                break
                        continue


    
    def show(self):

        while True:
            if self.queue['outputs'].qsize() > self.request_num * 2:
                break
        
        First = True
        while True:
            if self.all_stop:
                break
            if not self.queue['outputs'].empty():
                img = self.queue['outputs'].get()
                img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
                height, width, depth = img.shape

                cvimg = QImage(img.data, width, height, width * depth, QImage.Format_RGB888)
                pix = QPixmap(cvimg)
                self.lb_.setPixmap(pix)

                sleep(0.2)
                if First:
                    sleep(3)
                    First = False

    def start(self, IMG_SIZE, cap, gap=1):
        t = 0
        k = 0
        while cap.isOpened():
            if self.all_stop:
                break
            
            ret, ori_frame = cap.read()
            detect = True if t % (gap + 1) == 0 else False
            while True:
                if not self.queue['inputs'].full():
                    self.queue['inputs'].put({
                            'img':ori_frame,
                            'number':k,
                            'detect':detect
                        })
                    break

            t += 1
            k += 1

    def main(self, lb_, gap, demo_clip, IMG_SIZE):
        
        video_input = './Videos/{}'.format(demo_clip)
        cap = cv2.VideoCapture(video_input)
        
        self.set_gap(gap)

        self.init_queue()
            
        self.threads = list()
        
        
        self.lb_ = lb_    
        
        for i in range(self.request_num):
            self.threads.append(threading.Thread(target=self.get_start, args=(i, IMG_SIZE), daemon=True))
            self.threads[-1].start()
            
        self.threads.append(threading.Thread(target=self.start, args=(IMG_SIZE, cap, self.gap), daemon=True))
        self.threads[-1].start()
        
        self.show()

        
if __name__ == '__main__':
    detect = multi_ncs()
