"""
Layers for SSD
"""

import tensorflow as tf
import numpy as np
def conv2d(x, filters, kernel_size, stride=1, padding="same",
           dilation_rate=1, activation=tf.nn.relu, scope="conv2d"):
    kernel_sizes = [kernel_size] * 2
    strides = [stride] * 2
    dilation_rate = [dilation_rate] * 2

    return tf.compat.v1.layers.conv2d(x, filters, kernel_sizes, strides=strides,
                            dilation_rate=dilation_rate, padding=padding,
                            name=scope, activation=activation)

def max_pool2d(x, pool_size, stride=None, scope="max_pool2d"):
    pool_sizes = [pool_size] * 2
    strides = [pool_size] * 2 if stride is None else [stride] * 2
    return tf.compat.v1.layers.max_pooling2d(x, pool_sizes, strides, name=scope, padding="same")

def pad2d(x, pad):
    return tf.pad(x, paddings=[[0, 0], [pad, pad], [pad, pad], [0, 0]])

def dropout(x, rate=0.5, is_training=True):
    return tf.compat.v1.layers.dropout(x, rate=rate, training=is_training)

# l2norm (not bacth norm, spatial normalization)
def l2norm(x, scale, trainable=True, scope="L2Normalization"):
    n_channels = x.get_shape().as_list()[-1]
    l2_norm = tf.nn.l2_normalize(x, [3], epsilon=1e-12)
    with tf.compat.v1.variable_scope(scope):
        gamma = tf.compat.v1.get_variable("gamma", shape=[n_channels, ], dtype=tf.float32,
                                initializer=tf.constant_initializer(scale),
                                trainable=trainable)
        return l2_norm * gamma

# multibox layer: get class and location predicitions from detection layer
def ssd_multibox_layer(x, num_classes, sizes, ratios, normalization=-1, scope="multibox"):
    pre_shape = x.get_shape().as_list()[1:-1]
    pre_shape = [-1] + pre_shape
    with tf.compat.v1.variable_scope(scope):
        # l2 norm
        if normalization > 0:
            x = l2norm(x, normalization)
        # numbers of anchors
        n_anchors = len(sizes) + len(ratios)
        # location predictions
        loc_pred = conv2d(x, n_anchors * 4, 3, activation=None, scope="conv_loc")
        
        loc_pred = tf.reshape(loc_pred, pre_shape + [n_anchors, 4])
        # class prediction

        conf_pred = conv2d(x, n_anchors * num_classes, 3, activation=None, scope="conv_cls")
        conf_pred = tf.reshape(conf_pred, pre_shape + [n_anchors, num_classes])

        return conf_pred, loc_pred

def resnet_conv2d(x, filters, kernel_size, strides=(1, 1), name='conv2d', padding='valid'):
    return tf.compat.v1.layers.conv2d(x, filters=filters, kernel_size=kernel_size, strides=strides, name=name, padding=padding)

def identity_block(X_input, kernel_size, filters, stage, block, training=True):
    # defining name basis
    conv_name_base = 'res' + str(stage) + block + '_branch'
    bn_name_base = 'bn' + str(stage) + block + '_branch'

    with tf.name_scope("id_block_stage"+str(stage)):
        filter1, filter2, filter3 = filters
        X_shortcut = X_input

        # First component of main path
        x = resnet_conv2d(X_input, filter1,
                 kernel_size=(1, 1), strides=(1, 1),name=conv_name_base +'2a')
        x = tf.compat.v1.layers.batch_normalization(x, axis=3, name=bn_name_base +'2a', training=training)
        x = tf.nn.relu(x)

        # Second component of main path
        x = resnet_conv2d(x, filter2, (kernel_size, kernel_size),
                                 padding='same', name=conv_name_base +'2b')
        x = tf.compat.v1.layers.batch_normalization(x, axis=3, name=bn_name_base +'2b', training=training)
        x = tf.nn.relu(x)

        x = resnet_conv2d(x, filter3, kernel_size=(1, 1), name=conv_name_base +'2c')
        x = tf.compat.v1.layers.batch_normalization(x, axis=3, name=bn_name_base + '2c', training=training)

        X_add_shortcut = tf.add(x, X_shortcut)
        add_result = tf.nn.relu(X_add_shortcut)

    return add_result


def convolutional_block(X_input, kernel_size, filters, stage, block, stride=2, training=True):
    # defining name basis
    conv_name_base = 'res' + str(stage) + block + '_branch'
    bn_name_base = 'bn' + str(stage) + block + '_branch'

    with tf.name_scope("conv_block_stage" + str(stage)):

        # Retrieve Filters
        filter1, filter2, filter3 = filters

        # Save the input value
        X_shortcut = X_input

        # First component of main path
        x = resnet_conv2d(X_input, filter1,
                                 kernel_size=(1, 1),
                                 strides=(stride, stride),
                                 name=conv_name_base+'2a')
        x = tf.compat.v1.layers.batch_normalization(x, axis=3, name=bn_name_base+'2a', training=training)
        x = tf.nn.relu(x)

        # Second component of main path
        x = resnet_conv2d(x, filter2, (kernel_size, kernel_size), name=conv_name_base + '2b',padding='same')
        x = tf.compat.v1.layers.batch_normalization(x, axis=3, name=bn_name_base + '2b', training=training)
        x = tf.nn.relu(x)

        # Third component of main path
        x = resnet_conv2d(x, filter3, (1, 1), name=conv_name_base + '2c')
        x = tf.compat.v1.layers.batch_normalization(x, axis=3, name=bn_name_base + '2c', training=training)

        X_shortcut = resnet_conv2d(X_shortcut, filter3, (1,1),
                                      strides=(stride, stride), name=conv_name_base + '1')
        X_shortcut = tf.compat.v1.layers.batch_normalization(X_shortcut, axis=3, name=bn_name_base + '1', training=training)

        X_add_shortcut = tf.add(X_shortcut, x)
        add_result = tf.nn.relu(X_add_shortcut)

    return add_result