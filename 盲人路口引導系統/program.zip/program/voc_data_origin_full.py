import tensorflow as tf
import os
import numpy as np
import xml.etree.ElementTree as ET
from PIL import Image
import random
import cv2

from configuration import *
from image_utils import random_patching, horizontal_flip_ymin
from functools import partial
from generate_dataset import DataSet

class VOCDataset(object):
    

    def __init__(self, class_name, root_dir, year, default_boxes, 
                batch_size, num_examples, 
                 augmentation, training_data_ratio,
                 f_dtype, i_dtype,
                 rgb_mean=[123., 117., 104.]):

        super(VOCDataset, self).__init__()
        # self.idx_to_name = [
        #     'aeroplane', 'bicycle', 'bird', 'boat',
        #     'bottle', 'bus', 'car', 'cat', 'chair',
        #     'cow', 'diningtable', 'dog', 'horse',
        #     'motorbike', 'person', 'pottedplant',
        #     'sheep', 'sofa', 'train', 'tvmonitor']


        self.idx_to_name = class_name
        
        self.datasetPath = './dataset'
        self.dataset_train_txt = 'train.txt'
        self.dataset_val_txt = 'val.txt'

        self.name_to_idx = dict([(v, k)
                                 for k, v in enumerate(self.idx_to_name)])

        self.data_dir = os.path.join(root_dir, 'VOC{}'.format(year))
        self.image_dir = os.path.join(self.data_dir, 'JPEGImages')
        self.anno_dir = os.path.join(self.data_dir, 'Annotations')


        

        self.default_boxes = default_boxes
        self.new_size = IMG_SIZE
        self.batch_size = batch_size

        self._get_train_val_data(num_examples, training_data_ratio)

        if augmentation == None:
            self.augmentation = ['original']
        else:
            self.augmentation = augmentation + ['original']

        self.step = self._get_step(len(self.ids))
        self.train_step = self._get_step(len(self.train_ids))
        self.val_step = self._get_step(len(self.val_ids))

        self.f_dtype = f_dtype
        self.i_dtype = i_dtype
        self.rgb_mean = np.array(rgb_mean)

    def __len__(self):
        return len(self.ids)

    def _create_train_val_data(self, num_examples, training_data_ratio):
        datasetTrainPath = os.path.join(self.datasetPath, self.dataset_train_txt)
        datasetValPath = os.path.join(self.datasetPath, self.dataset_val_txt)

        self.ids = list(map(lambda x: x[:-4], os.listdir(self.image_dir)))

        if num_examples != -1:
            self.ids = self.ids[:num_examples]

        splitLine = int(len(self.ids) * training_data_ratio)
        self.train_ids = self.ids[:splitLine]
        self.val_ids = self.ids[splitLine:]

        with open(datasetTrainPath, 'w') as tfile:
            for row in self.train_ids:
                tfile.write('{}\n'.format(row))

        with open(datasetValPath, 'w') as tfile:
            for row in self.val_ids:
                tfile.write('{}\n'.format(row))

    def _get_train_val_data(self, num_examples, training_data_ratio):
        datasetTrainPath = os.path.join(self.datasetPath, self.dataset_train_txt)
        datasetValPath = os.path.join(self.datasetPath, self.dataset_val_txt)

        if not os.path.exists(self.datasetPath):
            os.mkdir(self.datasetPath)
            self._create_train_val_data(num_examples, training_data_ratio)
        else:
            if (not os.path.exists(datasetTrainPath)) or (not os.path.exists(datasetValPath)):
                self._create_train_val_data(num_examples, training_data_ratio)
            else:
                self.train_ids = list(filter(lambda z:z, [x.strip() for x in open(datasetTrainPath, 'r').readlines()]))
                self.val_ids = list(filter(lambda z:z, [x.strip() for x in open(datasetValPath, 'r').readlines()]))
                self.ids = self.train_ids + self.val_ids



    def _get_step(self, num_data):
        if (int('{:.0f}'.format(num_data / self.batch_size)) - num_data // self.batch_size) > 0:
            step = int('{:.0f}'.format(num_data / self.batch_size))
            print('This step is not Integer will auto add 1')
        else:
            step = num_data // self.batch_size
        
        return step

    def _get_train_valid_filenames(self):
        return self.train_ids, self.val_ids

    def _full_data(self, gt_labels, gt_bboxes):
        result_labels = list()
        result_bboxes = list()

        max_len = 0
        for batch in range(len(gt_labels)):
            max_len = len(gt_labels[batch]) if max_len < len(gt_labels[batch]) else max_len

        for batch in range(len(gt_labels)):
            temp_bboxes = list()
            if len(gt_labels[batch]) < max_len:
                added_count = max_len - len(gt_labels[batch])
                result_labels.append(np.array(list(gt_labels[batch]) + [-1] * added_count))
                
                for box in gt_bboxes[batch]:
                    temp_bboxes.append(list(box))
                for i in range(added_count):
                    temp_bboxes.append([-1., -1., -1., -1.])

                result_bboxes.append(np.array(temp_bboxes, dtype=self.f_dtype['np']))
            else:
                result_labels.append(gt_labels[batch])
                result_bboxes.append(gt_bboxes[batch])


        return np.array(result_labels, dtype=self.i_dtype['np']), np.array(result_bboxes, dtype=self.f_dtype['np'])

    def _get_image(self, index):
        
        filename = self.ids[index]
        img_path = os.path.join(self.image_dir, filename + '.jpg')
        img = Image.open(img_path)

        return img

    def one_hot(self, labels):
        one_hot_labels = [0.] * (len(self.idx_to_name) + 1)
        one_hot_labels[labels] = 1.
        return one_hot_labels

    def _get_annotation(self, index, orig_shape):
        
        h, w = orig_shape
        filename = self.ids[index]
        anno_path = os.path.join(self.anno_dir, filename + '.xml')
        objects = ET.parse(anno_path).findall('object')
        boxes = []
        labels = []

        for obj in objects:
            name = obj.find('name').text.lower().strip()
            bndbox = obj.find('bndbox')
            xmin = (float(bndbox.find('xmin').text) - 1) / w
            ymin = (float(bndbox.find('ymin').text) - 1) / h
            xmax = (float(bndbox.find('xmax').text) - 1) / w
            ymax = (float(bndbox.find('ymax').text) - 1) / h
            if name in self.name_to_idx:
                boxes.append([ymin, xmin, ymax, xmax])
                labels.append(self.name_to_idx[name] + 1)

        return np.array(boxes, dtype=self.f_dtype['np']), np.array(labels, dtype=self.i_dtype['np'])

    def generate(self, session=None, subset=None):

        if subset == 'train':
            dataset = DataSet(self.train_ids)
            step = self.train_step
        elif subset == 'val':
            dataset = DataSet(self.val_ids)
            step = self.val_step
        else:
            dataset = DataSet(self.ids)
            step = self.step

        count = 0

        with tf.compat.v1.variable_scope('voc_data', reuse=tf.compat.v1.AUTO_REUSE):
            while True:

                if count == step:
                    break

                gt_confs = list()
                gt_locs = list()
                imgs = list()

                gt_labels = list()
                gt_bboxes = list()

                max_len = 0

                indices = dataset.next_batch(self.batch_size)
                for index in range(len(indices)):
                    filename = indices[index]

                    t_index = self.ids.index(filename)

                    img = self._get_image(t_index)

                    w, h = img.size
                    boxes, labels = self._get_annotation(t_index, (h, w))
                    
                    augmentation_method = np.random.choice(self.augmentation)
                    if augmentation_method == 'patch':
                        img, boxes, labels = random_patching(img, boxes, labels)
                    elif augmentation_method == 'flip':
                        img, boxes, labels = horizontal_flip_ymin(img, boxes, labels)

                    img = cv2.resize(np.array(img, dtype=self.f_dtype['np']), (self.new_size, self.new_size), cv2.INTER_AREA) / 255.

                    imgs.append(img)
                    gt_labels.append(labels)
                    gt_bboxes.append(boxes)

                filenames = np.array(indices)
                imgs = np.array(imgs)


                gt_labels, gt_bboxes = self._full_data(gt_labels, gt_bboxes)

                count += 1
                yield filenames, imgs, gt_labels, gt_bboxes


def create_batch_generator(class_name, root_dir, year, default_boxes, 
                            batch_size=1, num_batches=-1,
                           mode='train',
                           augmentation=None,
                           training_data_ratio=0.8,
                           f_dtype={'tf':tf.float32, 'np':np.float32},
                           i_dtype={'tf':tf.int32, 'np':np.int32}):

    num_examples = batch_size * num_batches if num_batches > 0 else -1
    voc = VOCDataset(class_name, root_dir, year, default_boxes,
                    batch_size, num_examples,
                     augmentation, training_data_ratio,
                     f_dtype, i_dtype)

    info = {
        'idx_to_name': voc.idx_to_name,
        'name_to_idx': voc.name_to_idx,
        
        'image_dir': voc.image_dir,
        'anno_dir': voc.anno_dir,
        
        'length': len(voc),
        'train_num': len(voc.train_ids),
        'val_num': len(voc.val_ids),
        
        'train_data': voc.train_ids,
        'val_data': voc.val_ids,

        'step': voc.step,
        'train_step': voc.train_step,
        'val_step': voc.val_step
    }
    return voc.generate, info
