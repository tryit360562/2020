import os
import argparse
import numpy as np
from queue import Queue
import tensorflow as tf
from time import time
from time import sleep
from time import strftime
from time import localtime
from threading import Thread
from datetime import datetime

import matplotlib.pyplot as plt

tf.compat.v1.disable_eager_execution()

from box_utils_new import create_encode
from ssd_300 import SSD
from losses import compute_loss
from inforce_images import preprocessing_images
from voc_data_origin_full import create_batch_generator


def create_dataset(batch_gen, subset='train'):
	print('Dataset --{}-- is open.'.format(subset))

	while True:
		re_time = time()
		for i, (filenames, imgs, encoded_scores, encoded_bboxes) in enumerate(batch_gen(subset=subset)):
			_dataset = {
						'filenames' : filenames,
						'imgs' : imgs,
						'encoded_scores' : encoded_scores,
						'encoded_bboxes' : encoded_bboxes
						}
			queues[subset].put(_dataset)

			if queues[subset].full():
				while True:
					if not queues[subset].full() or not THREAD_IS_OPEN[subset]:
						break

			if not THREAD_IS_OPEN[subset]:
				breakpoint

		if not THREAD_IS_OPEN[subset]:
			break


def create_dataset2(batch_gen):
	while True:
		subset = 'train'
		if THREAD_IS_OPEN[subset]:
			for i, (filenames, imgs, encoded_scores, encoded_bboxes) in enumerate(batch_gen(subset=subset)):
				_dataset = {
							'filenames' : filenames,
							'imgs' : imgs,
							'encoded_scores' : encoded_scores,
							'encoded_bboxes' : encoded_bboxes
							}
				queues[subset].put(_dataset)

				if queues[subset].full():
					while True:
						if not queues[subset].full() or not THREAD_IS_OPEN[subset]:
							break

				if not THREAD_IS_OPEN[subset]:
					break

		if not THREAD_IS_OPEN[subset]:
			print('Dataset thread --{}-- is closed.'.format(subset))
			break

		subset = 'val'
		if THREAD_IS_OPEN[subset]:
			for i, (filenames, imgs, encoded_scores, encoded_bboxes) in enumerate(batch_gen(subset=subset)):
				_dataset = {
							'filenames' : filenames,
							'imgs' : imgs,
							'encoded_scores' : encoded_scores,
							'encoded_bboxes' : encoded_bboxes
							}
				queues[subset].put(_dataset)

				if queues[subset].full():
					while True:
						if not queues[subset].full() or not THREAD_IS_OPEN[subset]:
							break

				if not THREAD_IS_OPEN[subset]:
					break

		if not THREAD_IS_OPEN[subset]:
			print('Dataset thread --{}-- is closed.'.format(subset))
			break

def get_dataset(dataset):
	return dataset['filenames'], dataset['imgs'], dataset['encoded_scores'], dataset['encoded_bboxes']

parser = argparse.ArgumentParser()
parser.add_argument('--data-dir', default='./VOC_DataSet/VOCdevkit')
parser.add_argument('--data-year', default='2007')
parser.add_argument('--batch-size', default=5, type=int)
parser.add_argument('--num-batches', default=-1, type=int)
parser.add_argument('--neg-ratio', default=3, type=int)
parser.add_argument('--num-epochs', default=4000, type=int)
parser.add_argument('--training-data-ratio', default=0.8, type=float)


ckptPath = './checkpoints_new'
parser.add_argument('--checkpoint_dir', default=ckptPath)
parser.add_argument('--gpu-id', default='1')
args = parser.parse_args()
os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_id

backbone = 'resnet_50'

class_name = ['person_green', 'person_red']

# class_name = [
# 			'aeroplane',
# 			'bicycle',
# 			'bird',
# 			'boat',
# 			'bottle',
# 			'bus',
# 			'car',
# 			'cat',
# 			'chair',
# 			'cow',
# 			'diningtable',
# 			'dog',
# 			'horse',
# 			'motorbike',
# 			'person',
# 			'pottedplant',
# 			'sheep',
# 			'sofa',
# 			'train',
# 			'tvmonitor'
# ]

QUEUE_MAXSIZE = 2
THREAD_IS_OPEN = {
		'train' : True,
		'val' : True
		}

queues = {
		'train' : Queue(maxsize=QUEUE_MAXSIZE),
		'val' : Queue(maxsize=QUEUE_MAXSIZE)
		}



save_pb = False
pb_file = 'model-{:02d}.pb'
get_pb_variable = None

ckpt_file = 'my_model-{:02d}.ckpt'
latest = True

start_epoch = 0

log_path = './log'

start_1000_epoch_time = None



if not os.path.exists(log_path):
	os.mkdir(log_path)
	print('Create dir:', log_path)
if not os.path.exists(args.checkpoint_dir):
	os.mkdir(args.checkpoint_dir)
	print('Create dir:', args.checkpoint_dir)
	
temp = [x for x in os.listdir(log_path) if 'train' in x]
train_txt_file = 'train_msg-{:02d}.txt'.format(len(temp) + 1)
val_txt_file = 'val_msg-{:02d}.txt'.format(len(temp) + 1)



#input params
inputImages = tf.compat.v1.placeholder(tf.float32, shape=[None, 300, 300, 3])
g_labels = tf.compat.v1.placeholder(tf.int32, [None, None])
g_bboxes = tf.compat.v1.placeholder(tf.float32, [None, None, 4])

preprocessing = True

if preprocessing:
	input_images, processed_labels, processed_bboxes = preprocessing_images(inputImages, g_labels, g_bboxes, args.batch_size)
else:
	input_images = inputImages

ssd = SSD(class_name, input_images, args.batch_size, backbone=backbone)

predictions, logits, localizations = ssd.detections()
encode = create_encode(ssd.ssd_params.num_classes, args.batch_size)


if preprocessing:
	eclasses, escores, ebboxes = encode(processed_labels, processed_bboxes, one_hot=False)
else:
	eclasses, escores, ebboxes = encode(g_labels, g_bboxes, one_hot=False)

conf_loss, loc_loss = compute_loss(logits, localizations,
           							eclasses, escores, ebboxes)
loss = conf_loss + loc_loss


if backbone == 'vgg':
	train_op = tf.compat.v1.train.AdamOptimizer(1e-3).minimize(loss)

elif backbone == 'resnet_50':
	optimizer = tf.compat.v1.train.AdamOptimizer(1e-3)
	update_ops = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.UPDATE_OPS)
	with tf.control_dependencies(update_ops):
		train_op = optimizer.minimize(loss)

batch_generator, info = create_batch_generator(
        class_name, args.data_dir, args.data_year, None,
        batch_size=args.batch_size, num_batches=args.num_batches,
        mode='train', augmentation=['flip'], training_data_ratio=args.training_data_ratio)



threads = {'train' : Thread(target=create_dataset2, args=(batch_generator,)),
			}

for key in threads:
	threads[key].daemon = True
	threads[key].start()


saver = tf.compat.v1.train.Saver(max_to_keep=1000)

if latest:
	ckptFiles = [x for x in os.listdir(args.checkpoint_dir) if ckpt_file.split('-')[0] in x]
	if ckptFiles:
		MAX = max(set(map(lambda x: int(x.split('.')[0].split('-')[-1]), ckptFiles)))
		start_epoch = MAX
		restore_ckpt_path = os.path.join(args.checkpoint_dir, ckpt_file.format(MAX))
		print('Restore Check Point FIle:', os.path.join(args.checkpoint_dir, ckpt_file.format(MAX)))
	else:
		restore_ckpt_path = None
		print('Check Point File not found.')
else:
	restore_ckpt_path = None

cfg = tf.compat.v1.ConfigProto()
cfg.gpu_options.allow_growth = True



def convt2Pb():
	get_pb_variable = list()
	lis = [x.name for x in tf.get_default_graph().as_graph_def().node]
	for i in lis:
		if ('conv_loc/BiasAdd' in i or 'conv_cls/BiasAdd' in i) and 'BiasAdd_grad' not in i:
			get_pb_variable.append(i)

	constant_graph = tf.compat.v1.graph_util.convert_variables_to_constants(sess, tf.get_default_graph().as_graph_def(), get_pb_variable)
	with tf.gfile.FastGFile(os.path.join(args.checkpoint_dir, pb_file.format(1600)), mode='wb') as f:
		f.write(constant_graph.SerializeToString())
with tf.compat.v1.Session(config=cfg) as sess:
	sess.run(tf.compat.v1.global_variables_initializer())

	if restore_ckpt_path:
		saver.restore(sess, restore_ckpt_path)
	
	tf.compat.v1.get_default_graph().finalize()

	train_imgs = 0
	start_all_epoch_time = datetime.now()
	for epoch in range(start_epoch, args.num_epochs):
		# Train
		start_time = time()
		if epoch == 0:
			start_1000_epoch_time = datetime.now()
		avg_loss = 0.0
		avg_conf_loss = 0.0
		avg_loc_loss = 0.0
		
		readtime = time()

		for i in range(info['train_step']):
			batch_time = time()
			train_imgs += args.batch_size

			t1 = time()
			if queues['train'].empty():
				while True:
					if not queues['train'].empty():
						break
			filenames, imgs, gt_labels, gt_bboxes = get_dataset(queues['train'].get())

			read_time = time() - t1
			
			feed_dict = {
				inputImages : imgs,
				g_labels : gt_labels,
				g_bboxes : gt_bboxes
			}

			t1 = time()
			sess.run(train_op, feed_dict=feed_dict)
			train_time = time() - t1

			rconf_loss, rloc_loss = sess.run([conf_loss, loc_loss], feed_dict=feed_dict)
			
			rloss = rconf_loss + rloc_loss
			
			avg_loss = np.divide(np.multiply(avg_loss, i) + rloss, (i + 1))
			avg_conf_loss = np.divide(np.multiply(avg_conf_loss, i) + rconf_loss, (i + 1))
			avg_loc_loss = np.divide(np.multiply(avg_loc_loss, i) + rloc_loss, (i + 1))

			train_msg = 'Epoch: {}, Batch: {}/{}, Time: {:.6f}s/image, Learning_rate: {} || Loss: {:.6f}, Conf_loss: {:.6f}, Loc_loss: {:.6f} || Train_images: {}'.\
						format(epoch + 1, i + 1, info['train_step'], (time() - batch_time) / args.batch_size,
							# sess.run(lr)
							'None', rloss, rconf_loss, rloc_loss, train_imgs)
			train_msg2 = '\t\t\tAvg_loss: {}, Avg_conf_loss: {}, Avg_loc_loss: {} || Train_time: {}, Read_time: {}'.format(
							avg_loss, avg_conf_loss, avg_loc_loss, train_time, read_time)
			if (i + 1) % 10 == 0:
				print(train_msg)
				print(train_msg2)

			with open(os.path.join(log_path, train_txt_file), 'a+') as train_log:
				train_log.write('{}\n'.format(train_msg))
				train_log.write('{}\n'.format(train_msg2))

		print('Epoch: {}, Time: {}s'.format(epoch + 1, time() - start_time))
		start_time = time()

		avg_val_loss = 0.0
		avg_val_conf_loss = 0.0
		avg_val_loc_loss = 0.0

		for i in range(info['val_step']):

			if queues['val'].empty():
				while True:
					if not queues['val'].empty():
						break
			filenames, imgs, gt_labels, gt_bboxes = get_dataset(queues['val'].get())

			feed_dict = {
				inputImages : imgs,
				g_labels : gt_labels,
				g_bboxes : gt_bboxes
			}


			rval_conf_loss, rval_loc_loss = sess.run([conf_loss, loc_loss], feed_dict=feed_dict)
			rval_loss = rval_conf_loss + rval_loc_loss

			avg_val_loss = np.divide(np.multiply(avg_val_loss, i) + rval_loss, (i + 1))
			avg_val_conf_loss = np.divide(np.multiply(avg_val_conf_loss, i) + rval_conf_loss, (i + 1))
			avg_val_loc_loss = np.divide(np.multiply(avg_val_loc_loss, i) + rval_loc_loss, (i + 1))


		print('Epoch: {}, Time: {}s, Avg_val_loss: {}, Avg_val_conf_loss: {}, Avg_val_loc_loss: {}'.format(
			epoch + 1, time() - start_time, avg_val_loss, avg_val_conf_loss, avg_val_loc_loss))
		if (epoch + 1) % 1000 == 0:
			if start_1000_epoch_time:
				passed_time = str(datetime.now() - start_1000_epoch_time).split('.')[0]
			else:
				passed_time = None

		if (epoch + 1) % 1000 == 0:
			if save_pb:
				constant_graph = tf.compat.v1.graph_util.convert_variables_to_constants(sess, tf.get_default_graph().as_graph_def(), get_pb_variable)
				with tf.gfile.FastGFile(os.path.join(args.checkpoint_dir, pb_file.format(epoch + 1)), mode='wb') as f:
					f.write(constant_graph.SerializeToString())
			else:
				saver.save(sess, os.path.join(args.checkpoint_dir, ckpt_file.format(epoch + 1)))
				print('Saved.')
		if (epoch + 1) % 1000 == 0:
			start_1000_epoch_time = datetime.now()
