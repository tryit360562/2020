from PIL import Image
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import cv2
from configuration import *

def _full_data(gt_labels, gt_bboxes):
    result_labels = list()
    result_bboxes = list()

    max_len = 0
    for batch in range(len(gt_labels)):
        max_len = tf.maximum(gt_labels[batch].shape[0], max_len)
    for batch in range(len(gt_labels)):
        temp_bboxes = list()
        if len(gt_labels[batch]) < max_len:
            added_count = max_len - len(gt_labels[batch])
            result_labels.append(np.array(list(gt_labels[batch]) + [-1] * added_count))
            
            for box in gt_bboxes[batch]:
                temp_bboxes.append(list(box))
            for i in range(added_count):
                temp_bboxes.append([-1., -1., -1., -1.])

            result_bboxes.append(np.array(temp_bboxes, dtype=np.float32))
        else:
            result_labels.append(gt_labels[batch])
            result_bboxes.append(gt_bboxes[batch])


    return np.array(result_labels, dtype=np.int32), np.array(result_bboxes, dtype=np.float32)

def _filter_air(g_labels, g_bboxes):
    lmask = tf.logical_not(tf.equal(g_labels, -1))
    bmask = tf.logical_not(tf.equal(g_bboxes, -1))

    f_lables = tf.reshape(tf.boolean_mask(g_labels, lmask), [-1])
    f_bboxes = tf.reshape(tf.boolean_mask(g_bboxes, bmask), [-1, 4])

    return f_lables, f_bboxes

def check_sliced_box(bboxes, bboxes_for_draw, shape, data_format='float'):
	

	ymin = bboxes[..., 0]
	xmin = bboxes[..., 1]
	ymax = bboxes[..., 2]
	xmax = bboxes[..., 3]

	n_num = tf.shape(bboxes)[1]
	b_ymin = tf.tile(bboxes_for_draw[..., 0], [1, n_num])
	b_xmin = tf.tile(bboxes_for_draw[..., 1], [1, n_num])
	b_ymax = tf.tile(bboxes_for_draw[..., 2], [1, n_num])
	b_xmax = tf.tile(bboxes_for_draw[..., 3], [1, n_num])

	paded_xmin = tf.where(tf.less(xmin, b_xmin), b_xmin, xmin) - b_xmin
	paded_ymin = tf.where(tf.less(ymin, b_ymin), b_ymin, ymin) - b_ymin
	paded_xmax = tf.where(tf.greater(xmax, b_xmax), b_xmax, xmax) - b_xmin
	paded_ymax = tf.where(tf.greater(ymax, b_ymax), b_ymax, ymax) - b_ymin

	co_xmin = paded_xmin * IMG_SIZE
	co_ymin = paded_ymin * IMG_SIZE
	co_xmax = paded_xmax * IMG_SIZE
	co_ymax = paded_ymax * IMG_SIZE

	paded_box = check_paded_box(co_ymin, co_xmin, co_ymax, co_xmax, shape)
	if data_format == 'int':
		return paded_box
	elif data_format == 'float':
		return tf.cast(paded_box, tf.float32) / IMG_SIZE

def check_paded_box(ymin, xmin, ymax, xmax, shape):
	h = tf.cast(shape[0], tf.float32)
	w = tf.cast(shape[1], tf.float32)
	pad_helt_w = (IMG_SIZE - w) / 2.
	pad_helt_h = (IMG_SIZE - h) / 2.

	return tf.cast(tf.stack([ymin + pad_helt_h, xmin + pad_helt_w,
					 ymax + pad_helt_h, xmax + pad_helt_w], axis=-1), tf.int32)



def preprocessing_images(images, gt_labels, gt_bboxes, batch_size):
	
	def distorted_img_box():
		_bbox = tf.expand_dims(bboxes, axis=0)

		begin, size, bbox_for_draw = tf.image.sample_distorted_bounding_box(tf.shape(img), bounding_boxes=_bbox, min_object_covered=0.6)
		_img = tf.slice(img, begin, size)
		paded_box = check_sliced_box(_bbox, bbox_for_draw, size)
		return _img, tf.squeeze(paded_box, axis=0)

	def nothing():
		return img, bboxes

	images_list = list()
	labels_list = list()
	bboxes_list = list()

	for batch in range(batch_size):
		labels, bboxes = _filter_air(gt_labels[batch], gt_bboxes[batch])
		img = images[batch]

		bbox = bboxes
		ran = tf.random.shuffle([0, 1])
		_img, paded_box = tf.cond(tf.equal(tf.argmax(ran), 1), distorted_img_box, nothing)

		_img = tf.image.random_brightness(_img,max_delta=0.3)
		_img = tf.image.random_contrast(_img,lower=0.8,upper=1.2) #0.8 ~ 1.2
		_img = tf.image.random_hue(_img,max_delta=0.1) # 0 ~ 0.1
		_img = tf.image.random_saturation(_img,lower=0,upper=2) # 0 ~ 2
		_img = tf.image.resize_with_crop_or_pad(_img, int(IMG_SIZE), int(IMG_SIZE))

		images_list.append(tf.reshape(_img, [int(IMG_SIZE), int(IMG_SIZE), 3]))
		labels_list.append(labels)
		bboxes_list.append(paded_box)

	return tf.stack(images_list, axis=0), labels_list, bboxes_list


