"""
SSD net (vgg_based) 300x300
"""
from collections import namedtuple

import numpy as np
import tensorflow as tf

from ssd_layers import conv2d, max_pool2d, l2norm, dropout, \
    pad2d, ssd_multibox_layer, convolutional_block, identity_block
from ssd_anchors import ssd_anchors_all_layers

# SSD parameters
SSDParams = namedtuple('SSDParameters', ['img_shape',  # the input image size: 300x300
                                         'num_classes',  # number of classes: 20+1
                                         'no_annotation_label',
                                         'feat_layers', # list of names of layer for detection
                                         'feat_shapes', # list of feature map sizes of layer for detection
                                         'anchor_size_bounds', # the down and upper bounds of anchor sizes
                                         'anchor_sizes',   # list of anchor sizes of layer for detection
                                         'anchor_ratios',  # list of rations used in layer for detection
                                         'anchor_steps',   # list of cell size (pixel size) of layer for detection
                                         'anchor_offset',  # the center point offset
                                         'normalizations', # list of normalizations of layer for detection
                                         'prior_scaling'   #
                                         ])


class SSD(object):
    """SSD net 300"""
    def __init__(self, class_name, _images, batch_size=1, is_training=True, backbone='vgg'):
        self._images = _images
        self.is_training = is_training
        self.batch_size = batch_size
        self.threshold = 0.  # class score threshold
        self.IMG_SIZE = self._images.shape[1]


       
        if self.IMG_SIZE == 300:
            self.ssd_params = SSDParams(img_shape=(300, 300),
                                        num_classes=len(class_name) + 1,
                                        no_annotation_label=len(class_name) + 1,
                                        feat_layers=["block4", "block7", "block8", "block9", "block10", "block11"],
                                        feat_shapes=[(38, 38), (19, 19), (10, 10), (5, 5), (3, 3), (1, 1)],
                                        anchor_size_bounds=[0.15, 0.90],  # diff from the original paper
                                        anchor_sizes=[(21., 45.),
                                                      (45., 99.),
                                                      (99., 153.),
                                                      (153., 207.),
                                                      (207., 261.),
                                                      (261., 315.)],
                                        anchor_ratios=[[2, .5],
                                                       [2, .5, 3, 1. / 3],
                                                       [2, .5, 3, 1. / 3],
                                                       [2, .5, 3, 1. / 3],
                                                       [2, .5],
                                                       [2, .5]],
                                        anchor_steps=[8, 16, 32, 64, 100, 300],
                                        anchor_offset=0.5,
                                        normalizations=[20, -1, -1, -1, -1, -1],
                                        prior_scaling=[0.1, 0.1, 0.2, 0.2]
                                        )
        elif self.IMG_SIZE == 512:
            self.ssd_params = SSDParams(img_shape=(512, 512),
                                    num_classes=len(class_name) + 1,
                                    no_annotation_label=len(class_name) + 1,
                                    feat_layers=["block4", "block7", "block8", "block9", "block10", "block11", "block12"],
                                    feat_shapes=[(64, 64), (32, 32), (16, 16), (8, 8), (4, 4), (2, 2), (1, 1)],
                                    anchor_size_bounds=[0.15, 0.90],  # diff from the original paper
                                    anchor_sizes=[(20.48, 51.2),
                                                  (51.2, 133.12),
                                                  (133.12, 215.04),
                                                  (215.04, 296.96),
                                                  (296.96, 378.88),
                                                  (378.88, 460.8),
                                                  (460.8, 542.72)],
                                    anchor_ratios=[[2, .5],
                                                   [2, .5, 3, 1. / 3],
                                                   [2, .5, 3, 1. / 3],
                                                   [2, .5, 3, 1. / 3],
                                                   [2, .5],
                                                   [2, .5],
                                                   [2, .5]],
                                    anchor_steps=[8, 16, 32, 64, 128, 256, 512],
                                    anchor_offset=0.5,
                                    normalizations=[20, -1, -1, -1, -1, -1, -1],
                                    prior_scaling=[0.1, 0.1, 0.2, 0.2]
                                    )

        predictions, logits, locations = self._built_net(backbone)
        #self._update_feat_shapes_from_net()
        if self.is_training:
            fpredictions, flogits, flocations = self._bboxes_flatten(predictions, logits, locations)
            self._classes = fpredictions
            self._scores = flogits
            self._bboxes = flocations
        else:
            fpredictions, flogits, flocations = self._bboxes_flatten(predictions, logits, locations)
            self._classes = fpredictions
            self._scores = flogits
            self._bboxes = flocations

            

    def backbone_vgg(self):
        net = conv2d(self._images, 64, 3, scope="conv1_1")
        net = conv2d(net, 64, 3, scope="conv1_2")
        self.end_points["block1"] = net
        net = max_pool2d(net, 2, scope="pool1")
        # block 2
        net = conv2d(net, 128, 3, scope="conv2_1")
        net = conv2d(net, 128, 3, scope="conv2_2")
        self.end_points["block2"] = net
        net = max_pool2d(net, 2, scope="pool2")
        # block 3
        net = conv2d(net, 256, 3, scope="conv3_1")
        net = conv2d(net, 256, 3, scope="conv3_2")
        net = conv2d(net, 256, 3, scope="conv3_3")
        self.end_points["block3"] = net
        net = max_pool2d(net, 2, scope="pool3")
        # block 4
        net = conv2d(net, 512, 3, scope="conv4_1")
        net = conv2d(net, 512, 3, scope="conv4_2")
        net = conv2d(net, 512, 3, scope="conv4_3")
        self.end_points["block4"] = net
        net = max_pool2d(net, 2, scope="pool4")
        # block 5
        net = conv2d(net, 512, 3, scope="conv5_1")
        net = conv2d(net, 512, 3, scope="conv5_2")
        net = conv2d(net, 512, 3, scope="conv5_3")
        self.end_points["block5"] = net
        return net

    def backbone_resnet_50(self, training=True):
        if self.IMG_SIZE == 300:
            net = tf.pad(self._images, tf.constant([[0, 0], [7, 7], [7, 7], [0, 0]]), "CONSTANT")
        elif self.IMG_SIZE == 512:
            net = tf.pad(self._images, tf.constant([[0, 0], [5, 5], [5, 5], [0, 0]]), "CONSTANT")

        # stage 1
        net = tf.compat.v1.layers.conv2d(net, filters=64, kernel_size=(7, 7), strides=(2, 2), name='conv1')
        net = tf.compat.v1.layers.batch_normalization(net, axis=3, name='bn_conv1', training=training)
        net = tf.nn.relu(net)
        net = tf.compat.v1.layers.max_pooling2d(net, pool_size=(3, 3), strides=(2, 2))

        # stage 2
        net = convolutional_block(net, kernel_size=3, filters=[64, 64, 256], stage=2, block='a', stride=1, training=training)
        net = identity_block(net, 3, [64, 64, 256], stage=2, block='b', training=training)
        net = identity_block(net, 3, [64, 64, 256], stage=2, block='c', training=training)

        # stage 3
        net = convolutional_block(net, kernel_size=3, filters=[128,128,512],
                                                stage=3, block='a', stride=2, training=training)
        net = identity_block(net, 3, [128,128,512], stage=3, block='b', training=training)
        net = identity_block(net, 3, [128,128,512], stage=3, block='c', training=training)
        net = identity_block(net, 3, [128,128,512], stage=3, block='d', training=training)
        self.end_points["block4"] = net

        # stage 4
        net = convolutional_block(net, kernel_size=3, filters=[256, 256, 1024], stage=4, block='a', stride=2, training=training)

        net = identity_block(net, 3, [256, 256, 1024], stage=4, block='b', training=training)
        net = identity_block(net, 3, [256, 256, 1024], stage=4, block='c', training=training)
        net = identity_block(net, 3, [256, 256, 1024], stage=4, block='d', training=training)
        net = identity_block(net, 3, [256, 256, 1024], stage=4, block='e', training=training)
        net = identity_block(net, 3, [256, 256, 1024], stage=4, block='f', training=training)
        self.end_points["block5"] = net

        return net

    def _built_net(self, backbone):
        """Construct the SSD net"""
        self.end_points = {}  # record the detection layers output
        with tf.compat.v1.variable_scope("ssd_300_" + backbone):
            # original vgg layers
            # block 1
            print('images:', self._images)
            
            assert backbone in ['vgg', 'resnet_50'], 'Error backbone choice [vgg] or [resnet]'

            if backbone == 'vgg':
                net = self.backbone_vgg()
            elif backbone == 'resnet_50':
                net = self.backbone_resnet_50(False)

            net = max_pool2d(net, 3, stride=1, scope="pool5")
            print('pool:', net)

            net = conv2d(net, 1024, 3, dilation_rate=6, scope="conv6")
            self.end_points["block6"] = net
            # block 7
            net = conv2d(net, 1024, 1, scope="conv7")
            self.end_points["block7"] = net
            # block 8
            net = conv2d(net, 256, 1, scope="conv8_1x1")
            net = conv2d(pad2d(net, 1), 512, 3, stride=2, scope="conv8_3x3",
                         padding="valid")
            self.end_points["block8"] = net
            # block 9
            net = conv2d(net, 128, 1, scope="conv9_1x1")
            net = conv2d(pad2d(net, 1), 256, 3, stride=2, scope="conv9_3x3",
                         padding="valid")
            self.end_points["block9"] = net
            # block 10
            net = conv2d(net, 128, 1, scope="conv10_1x1")
            net = conv2d(net, 256, 3, scope="conv10_3x3", padding="valid")
            self.end_points["block10"] = net
            # block 11
            net = conv2d(net, 128, 1, scope="conv11_1x1")
            net = conv2d(net, 256, 3, scope="conv11_3x3", padding="valid")
            self.end_points["block11"] = net

            if self.IMG_SIZE == 512:
                net = conv2d(net, 128, 1, scope="conv12_1x1")
                net = conv2d(net, 256, 4, scope="conv12_4x4", padding="valid")
                self.end_points["block12"] = net

            # class and location predictions
            predictions = []
            logits = []
            locations = []
            for i, layer in enumerate(self.ssd_params.feat_layers):
                conf, loc = ssd_multibox_layer(self.end_points[layer], self.ssd_params.num_classes,
                                              self.ssd_params.anchor_sizes[i],
                                              self.ssd_params.anchor_ratios[i],
                                              self.ssd_params.normalizations[i], scope=layer + "_box")
                predictions.append(tf.nn.softmax(conf))
                logits.append(conf)
                locations.append(loc)
            return predictions, logits, locations

    def _update_feat_shapes_from_net(self, predictions):
        """ Obtain the feature shapes from the prediction layers"""
        new_feat_shapes = []
        for l in predictions:
            new_feat_shapes.append(l.get_shape().as_list()[1:])
        self.ssd_params._replace(feat_shapes=new_feat_shapes)

    def anchors(self):
        """Get sSD anchors"""
        return ssd_anchors_all_layers(self.ssd_params.img_shape,
                                      self.ssd_params.feat_shapes,
                                      self.ssd_params.anchor_sizes,
                                      self.ssd_params.anchor_ratios,
                                      self.ssd_params.anchor_steps,
                                      self.ssd_params.anchor_offset,
                                      np.float32)

    def _bboxes_flatten(self, fpredictions, flogits, flocations):
        f_predictions_list = list()
        f_logits_list = list()
        f_locations_list = list()

        for i in range(len(fpredictions)):
            find_shape = np.product(fpredictions[i].get_shape().as_list()[1 : -1])

            f_predictions_list.append(tf.reshape(fpredictions[i], [-1, find_shape, self.ssd_params.num_classes]))
            f_logits_list.append(tf.reshape(flogits[i], shape=[-1, find_shape, self.ssd_params.num_classes]))
            f_locations_list.append(tf.reshape(flocations[i], [-1, find_shape, 4]))

        fpredictions_tensor = tf.concat(f_predictions_list, axis=1)
        flogits_tensor = tf.concat(f_logits_list, axis=1)
        flocations_tensor = tf.concat(f_locations_list, axis=1)

        return fpredictions_tensor, flogits_tensor, flocations_tensor

    def _bboxes_decode_layer(self, feat_locations, anchor_bboxes, prior_scaling):
        
        yref, xref, href, wref = anchor_bboxes

        cx = feat_locations[:, :, :, :, 0] * wref * prior_scaling[0] + xref
        cy = feat_locations[:, :, :, :, 1] * href * prior_scaling[1] + yref
        w = wref * tf.exp(feat_locations[:, :, :, :, 2] * prior_scaling[2])
        h = href * tf.exp(feat_locations[:, :, :, :, 3] * prior_scaling[3])


        bboxes = tf.stack([cy - h / 2., cx - w / 2.,
                           cy + h / 2., cx + w / 2.], axis=-1)
        return bboxes

    def _bboxes_select_layer(self, feat_predictions, feat_locations, anchor_bboxes,
                             prior_scaling):
        """Select boxes from the feat layer, only for bacth_size=1"""
        n_bboxes = np.product(feat_predictions.get_shape().as_list()[1:-1])
        bboxes = self._bboxes_decode_layer(feat_locations, anchor_bboxes, prior_scaling)
        bboxes = tf.reshape(bboxes, [n_bboxes, 4])
        predictions = tf.reshape(feat_predictions, [n_bboxes, self.ssd_params.num_classes])
        sub_predictions = predictions[:, 1:]
        classes = tf.argmax(sub_predictions, axis=1) + 1  # class labels
        scores = tf.reduce_max(sub_predictions, axis=1)   # max_class scores
        
        return classes, scores, bboxes

    def _bboxes_select(self, predictions, locations):
        """Select all bboxes predictions, only for bacth_size=1"""
        anchor_bboxes_list = self.anchors()
        classes_list = []
        scores_list = []
        bboxes_list = []
        # select bboxes for each feat layer
        for n in range(len(predictions)):
            anchor_bboxes = list(map(tf.convert_to_tensor, anchor_bboxes_list[n]))
            classes, scores, bboxes = self._bboxes_select_layer(predictions[n],
                            locations[n], anchor_bboxes, self.ssd_params.prior_scaling)
            classes_list.append(classes)
            scores_list.append(scores)
            bboxes_list.append(bboxes)
        # combine all feat layers
        classes = tf.concat(classes_list, axis=0)
        scores = tf.concat(scores_list, axis=0)
        bboxes = tf.concat(bboxes_list, axis=0)
        return classes, scores, bboxes


    def _bboxes_encode_layer(self, 
                            feat_ymin, feat_xmin, feat_ymax, feat_xmax,
                            yref, xref, href, wref,
                            prior_scaling):

        feat_cy = (feat_ymax + feat_ymin) / 2.
        feat_cx = (feat_xmax + feat_xmin) / 2.
        feat_h = feat_ymax - feat_ymin
        feat_w = feat_xmax - feat_xmin

        feat_cy = (feat_cy - yref) / href / prior_scaling[0]
        feat_cx = (feat_cx - xref) / wref / prior_scaling[1]
        feat_h = tf.math.log(feat_h / href) / prior_scaling[2]
        feat_w = tf.math.log(feat_w / wref) / prior_scaling[3]

        return tf.stack([feat_cx, feat_cy, feat_w, feat_h], axis=-1)


    def _bboxes_encode_select_layer(self, gt_labels, gt_bboxes,
                                    anchor_bboxes, prior_scaling,
                                    dtype):
        
        yref, xref, href, wref = anchor_bboxes

        ymin = yref - href / 2.
        xmin = xref - wref / 2.
        ymax = yref + href / 2.
        xmax = xref + wref / 2.


        #compute area
        anchor_area = (xmax - xmin) * (ymax - ymin)


        shape = (yref.shape[0], yref.shape[1], href.shape[0])

        feat_labels = tf.zeros(shape, dtype=tf.int32)
        feat_scores = tf.zeros(shape, dtype=dtype)



        feat_ymin = tf.zeros(shape, dtype=dtype)
        feat_xmin = tf.zeros(shape, dtype=dtype)
        feat_ymax = tf.ones(shape, dtype=dtype)
        feat_xmax = tf.ones(shape, dtype=dtype)



        def compute_bbox_with_anchor_IOU(bbox):
            int_ymin = tf.maximum(ymin, bbox[0])
            int_xmin = tf.maximum(xmin, bbox[1])
            int_ymax = tf.minimum(ymax, bbox[2])
            int_xmax = tf.minimum(xmax, bbox[3])

            h = tf.maximum(int_ymax - int_ymin, 0.)
            w = tf.maximum(int_xmax - int_xmin, 0.)

            inter_area = h * w
            union_area = anchor_area - inter_area \
                        + (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])
            IOU = tf.math.divide(inter_area, union_area)
            return IOU

        def condition(i, feat_labels, feat_scores,
                        feat_ymin, feat_xmin, feat_ymax, feat_xmax):

            result = tf.less(i, tf.shape(gt_labels))
            return result[0]

        def body(i, feat_labels, feat_scores,
                    feat_ymin, feat_xmin, feat_ymax, feat_xmax):
            '''
                `gt_labels` type: tensorflow
                `gt_bboxes` type: tensorflow
            '''
            label = gt_labels[i]

            bbox = gt_bboxes[i]

            IOU = compute_bbox_with_anchor_IOU(bbox)

            mask = tf.greater(IOU, feat_scores)
            mask = tf.logical_and(mask, feat_scores > -0.5)
            mask = tf.logical_and(mask, label < self.ssd_params.num_classes)

            imask = tf.cast(mask, tf.int32)
            fmask = tf.cast(mask, dtype)

            feat_labels = imask * label + (1 - imask) * feat_labels
            feat_scores = tf.where(mask, IOU, feat_scores)

            feat_ymin = fmask * bbox[0] + (1 - fmask) * feat_ymin
            feat_xmin = fmask * bbox[1] + (1 - fmask) * feat_xmin
            feat_ymax = fmask * bbox[2] + (1 - fmask) * feat_ymax
            feat_xmax = fmask * bbox[3] + (1 - fmask) * feat_xmax

            return [i + 1, feat_labels, feat_scores,
                    feat_ymin, feat_xmin, feat_ymax, feat_xmax]

        
        i = 0

        [i, feat_labels, feat_scores,
            feat_ymin, feat_xmin, feat_ymax, feat_xmax] = tf.while_loop(condition, body,
                                                [i, feat_labels, feat_scores,
                                                    feat_ymin, feat_xmin, feat_ymax, feat_xmax])
        
        feat_localizations = self._bboxes_encode_layer(feat_ymin, feat_xmin, feat_ymax, feat_xmax,
                                                        yref, xref, href, wref,
                                                        prior_scaling)

        return feat_labels, feat_scores, feat_localizations


    def _filter_air(self, g_labels, g_bboxes):
        lmask = tf.logical_not(tf.equal(g_labels, -1))
        bmask = tf.logical_not(tf.equal(g_bboxes, -1))

        f_lables = tf.reshape(tf.boolean_mask(g_labels, lmask), [-1])
        f_bboxes = tf.reshape(tf.boolean_mask(g_bboxes, bmask), [-1, 4])

        return f_lables, f_bboxes

    def _bboxes_encode_select(self, gt_labels, gt_bboxes, ignore_threshold=0.5,
                                dtype=tf.float32):

        with tf.compat.v1.variable_scope('encode', reuse=tf.compat.v1.AUTO_REUSE):
            anchor_bboxes_list = self.anchors()
            classes_list = list()
            scores_list = list()
            bboxes_list = list()

            

            for batch in range(self.batch_size):
                target_labels = list()
                target_scores = list()
                target_localizations = list()


                labels, bboxes = self._filter_air(gt_labels[batch], gt_bboxes[batch])
                for n in range(len(anchor_bboxes_list)):
                    anchor_bboxes = list(map(tf.convert_to_tensor, anchor_bboxes_list[n]))
                    t_labels, t_scores, t_loc  = self._bboxes_encode_select_layer(labels, bboxes,
                                                                        anchor_bboxes, self.ssd_params.prior_scaling,
                                                                        dtype)

                    target_labels.append(tf.reshape(t_labels, [-1]))
                    target_scores.append(tf.reshape(t_scores, [-1]))
                    
                    target_localizations.append(tf.reshape(t_loc, [-1, 4]))


                classes_list.append(tf.concat(target_labels, axis=0))
                scores_list.append(tf.concat(target_scores, axis=0))
                bboxes_list.append(tf.concat(target_localizations, axis=0))


            classes_tensor = tf.stack(classes_list, axis=0)
            scores_tensor = tf.stack(scores_list, axis=0)
            bboxes_tensor = tf.stack(bboxes_list, axis=0)

            classes_tensor = tf.one_hot(classes_tensor, self.ssd_params.num_classes)

            return classes_tensor, scores_tensor, bboxes_tensor

    def images(self):
        return self._images

    def detections(self):
        return self._classes, self._scores, self._bboxes

