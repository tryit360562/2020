"""
SSD demo
"""
import os
import cv2
import math
import numpy as np
import tensorflow as tf
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
from time import time

from configuration import *
from box_utils_new import create_decode
from ssd_300 import SSD
from util_tools import preprocess_image, process_bboxes
from visualization import plt_bboxes
from PIL import Image

tf.compat.v1.disable_eager_execution()

global all_count

all_count = 0

def computeIOU(max_box, less_box):
	def _iter_area(box1, box2):
		
		ymin = np.maximum(box1[..., 0], box2[..., 0])
		xmin = np.maximum(box1[..., 1], box2[..., 1])
		ymax = np.minimum(box1[..., 2], box2[..., 2])
		xmax = np.minimum(box1[..., 3], box2[..., 3])

		h = np.maximum(ymax - ymin, 0)
		w = np.maximum(xmax - xmin, 0)

		return h * w

	def _area(box):
		return (box[..., 2] - box[..., 0]) * (box[..., 3] - box[..., 1])

	iter_area = _iter_area(max_box, less_box)
	max_area = _area(max_box)
	less_area = _area(less_box)

	union_area = max_area + less_area - iter_area

	return iter_area / union_area

def NON_MAX_SEPRESSION(oclasses, oscores, obboxes, top_k=400, threshold=0.5):
	
	sor = np.argsort(-oscores)

	max_top = np.minimum(top_k, oscores[sor].shape[0])
	o_classes = oclasses[sor][:max_top]
	o_scores = oscores[sor][:max_top]
	o_bboxes = obboxes[sor][:max_top]

	o_scores_cp = o_scores.copy()
	example_tensor = np.ones_like(o_scores_cp)
	result_tensor = np.zeros_like(o_scores_cp)

	while np.sum(example_tensor) != 0:
		this_max = np.argmax(o_scores_cp)
		o_scores_cp[this_max] = 0
		example_tensor[this_max] = 0
		result_tensor[this_max] = 1

		IOU = computeIOU(o_bboxes[this_max], o_bboxes)
		filter_IOU = np.where(np.equal(example_tensor, 1), IOU, np.zeros_like(example_tensor))
		filter_mask = filter_IOU > threshold
		example_tensor[filter_mask] = 0

	result_mask = result_tensor.astype(np.bool)

	result_classes = o_classes[result_mask]
	result_scores = o_scores[result_mask]
	result_bboxes = o_bboxes[result_mask]

	return result_classes, result_scores, result_bboxes

def showshow_np(img, rclasses, rscores, rbboxes, ori_img):


	global all_count
	
	result = list()

	pmask = rscores > 0.
	pmask = np.logical_and(pmask, rclasses > 0)

	oclasses = rclasses[pmask]
	if not np.any(oclasses):
		print('This image not detection anything...')
		return False, [], [], []

	oscores = rscores[pmask]
	obboxes = np.clip(rbboxes[pmask], 0.0, 1.0)

	oclasses, oscores, obboxes = NON_MAX_SEPRESSION(oclasses, oscores, obboxes, top_k=1)
	
	count_box = list()
	clips = list()
	ori_clips = list()

	ori_h, ori_w, _ = ori_img.shape




	for i in range(oscores.shape[0]):
		clas_ = oclasses[i]
		conf_ = oscores[i]
		box = obboxes[i]

		ymin, xmin, ymax, xmax = (box * IMG_SIZE).astype(np.int32)

		scales_loc = False
		if scales_loc:



			cc_xmin = int(xmin / IMG_SIZE * ori_w)
			cc_ymin = int(ymin / IMG_SIZE * ori_h)
			cc_xmax = int(xmax / IMG_SIZE * ori_w)
			cc_ymax = int(ymax / IMG_SIZE * ori_h)

			cc_w = cc_xmax - cc_xmin
			cc_h = cc_ymax - cc_ymin


			add_w = int(cc_w * 1.2) - cc_w
			add_h = int(cc_h * 1.2) - cc_h


			offset_min = 3
			offset_max = 7

			if int(add_w * 0.3) < offset_min or int(add_h * 0.7) < offset_max:
				cc_xmin -= offset_min
				cc_ymin -= offset_min
				cc_xmax += offset_max
				cc_ymax += offset_max
			else:
				cc_xmin = int(cc_xmin - int(add_w * 0.3))
				cc_ymin = int(cc_ymin - int(add_h * 0.3))
				cc_xmax = int(cc_xmax + int(add_w * 0.7))
				cc_ymax = int(cc_ymax + int(add_h * 0.7))


			
			c_xmin = int(xmin / IMG_SIZE * ori_w) - offset_min if int(xmin / IMG_SIZE * ori_w) > offset_min else int(xmin / IMG_SIZE * ori_w)
			c_ymin = int(ymin / IMG_SIZE * ori_h) - offset_min if int(ymin / IMG_SIZE * ori_h) > offset_min else int(ymin / IMG_SIZE * ori_h)
			c_xmax = int(xmax / IMG_SIZE * ori_w) + offset_max if int(xmax / IMG_SIZE * ori_w) < ori_w - offset_max else int(xmax / IMG_SIZE * ori_w)
			c_ymax = int(ymax / IMG_SIZE * ori_h) + offset_max if int(ymax / IMG_SIZE * ori_h) < ori_h - offset_max else int(ymax / IMG_SIZE * ori_h)



			cc_xmin = np.clip(cc_xmin, 0, ori_w)
			cc_ymin = np.clip(cc_ymin, 0, ori_h)
			cc_xmax = np.clip(cc_xmin, 0, ori_w)
			cc_ymax = np.clip(cc_ymax, 0, ori_h)

			ori_clip_ = cv2.resize(ori_img[c_ymin:c_ymax, c_xmin:c_xmax], (100, 160), cv2.INTER_CUBIC)
			clip_ = cv2.resize(ori_img[cc_ymin:cc_ymax, cc_xmin:cc_xmax], (100, 160), cv2.INTER_CUBIC)
			clips.append(clip_)
			ori_clips.append(ori_clip_)

		all_count += 1

		print([clas_], xmin, ymin, xmax, ymax, '--------{:.2f}'.format(conf_))

		base_filename = os.path.basename(filename)

		count_box.append(box)
		cv2.rectangle(img, (xmin, ymin), (xmax, ymax), (0, 0, 255), 2)


		cv2.imshow('img', img)
		cv2.waitKey(0)
		if 'green' in class_name[clas_ - 1]:
			draw_color = (0, 255, 0)
		else:
			draw_color = (255, 0, 0)
		cv2.putText(img, '{:.2f}: {}'.format(conf_, class_name[clas_ - 1]), (xmin, ymin - 5), 1, 1, draw_color, 1, cv2.LINE_AA)
	return True, clips, ori_clips + [class_name[clas_ - 1].split('_')[-1]], count_box


class_name = ['person_green', 'person_red']

# class_name = ["aeroplane", "bicycle", "bird", "boat", "bottle",
#                         "bus", "car", "cat", "chair", "cow", "diningtable",
#                         "dog", "horse", "motorbike", "person", "pottedplant",
#                         "sheep", "sofa", "train","tvmonitor"]


# backbone = 'vgg'
backbone = 'resnet_50'

save_to_pb = False

YAML_USE = 'SSD300'

batchsize = 1
images = tf.compat.v1.placeholder(tf.float32, shape=[None, IMG_SIZE, IMG_SIZE, 3])

if save_to_pb:
	ssd_net = SSD(class_name, images, batchsize, backbone=backbone, is_training=False)
else:
	_images = tf.image.per_image_standardization(tf.math.divide(images, 255.))

	ssd_net = SSD(class_name, _images, batchsize, backbone=backbone, is_training=False)

classes, scores, bboxes = ssd_net.detections()
saver = tf.compat.v1.train.Saver()

decode = create_decode(ssd_net.ssd_params.num_classes, batchsize, YAML_USE)
classes, scores, bboxes = decode(classes, bboxes)

sess = tf.compat.v1.Session()
# Restore SSD model.
epoch = 300

ckpt_filename = './ckpt/my_model-{}.ckpt'.format(epoch)
sess.run(tf.compat.v1.global_variables_initializer())
saver.restore(sess, ckpt_filename)


pb_file = 'model-{:02d}.pb'

if save_to_pb:
	get_pb_variable = list()
	lis = [x.name for x in tf.compat.v1.get_default_graph().as_graph_def().node]

	for i in lis:
		if ('out_classes' in i or 'out_boxes' in i or 'out_conf' in i) and '/' not in i:
			get_pb_variable.append(i)
	constant_graph = tf.compat.v1.graph_util.convert_variables_to_constants(sess, tf.compat.v1.get_default_graph().as_graph_def(), get_pb_variable)
	with tf.compat.v1.gfile.FastGFile(os.path.join(os.path.dirname(ckpt_filename), pb_file.format(epoch)), mode='wb') as f:
		f.write(constant_graph.SerializeToString())
	print('Saved.')
	exit()

mydemo_path = './demo'
filenames = [os.path.join(mydemo_path, x) for x in os.listdir(mydemo_path)]

result_imgs = list()

count = 1


all_detected = list()

for kkk, filename in enumerate(filenames):

	ori_img = Image.open(filename)
	img = cv2.resize(np.array(ori_img), (IMG_SIZE,  IMG_SIZE), cv2.INTER_AREA)
	ori_size = ori_img.size

	ori_img = np.array(ori_img)
	
	img_prepocessed = np.copy(img).astype(np.float32)
	
	img_prepocessed = np.expand_dims(img_prepocessed, axis=0)

	rclasses, rscores, rbboxes = sess.run([classes, scores, bboxes],
	                                      feed_dict={images: img_prepocessed})

	detected, clips, ori_clips, detected_box = showshow_np(img, rclasses, rscores, rbboxes, ori_img)

	print('[{} / {}]:'.format(kkk + 1, len(filenames)), all_count)
	result_imgs.append(img)

	empty = np.zeros(shape=[IMG_SIZE, IMG_SIZE + 200, 3], dtype=np.uint8) + 100

	empty[:IMG_SIZE, :IMG_SIZE] = img[..., ::-1]

	if detected:
		all_detected.append(kkk)
		show = False


		start_h = int((IMG_SIZE - 160) / 2)
		start_w = int((IMG_SIZE + 200 - IMG_SIZE - 100) / 2)
		if show:
			empty[start_h:start_h + 160, IMG_SIZE + start_w:IMG_SIZE + start_w + 100] = ori_clips[0][..., ::-1]
		ymin, xmin, ymax, xmax = (detected_box[0] * IMG_SIZE).astype(np.int32)

		if show:
			cv2.line(empty, (xmax, ymin), (IMG_SIZE + start_w, start_h), (0, 0, 255), 2)
			cv2.line(empty, (xmax, ymax), (IMG_SIZE + start_w, start_h + 160), (0, 0, 255), 2)
			if 'green' in ori_clips[-1]:
				draw_color = (0, 255, 0)
				cv2.putText(empty, ori_clips[-1], (IMG_SIZE + start_w + 25, start_h + 160 + 20), 1, 1, draw_color, 2, cv2.LINE_AA)
			else:
				draw_color = (0, 0, 255)
				cv2.putText(empty, ori_clips[-1], (IMG_SIZE + start_w + 35, start_h + 160 + 20), 1, 1, draw_color, 2, cv2.LINE_AA)
		

		cv2.imshow('Image', empty)
	else:
		cv2.imshow('Image', empty)
	

	if cv2.waitKey(1) & 0xFF == ord('q'):
		break

	if kkk + 1 == 100:
		break

	if count % 25 == 0:
		count = 1
	else:
		count += 1
cv2.destroyAllWindows()
