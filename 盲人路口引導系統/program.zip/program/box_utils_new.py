import tensorflow as tf
import numpy as np
import yaml
import os

from box_IOU_tf import _compute_IOU
from anchor import generate_default_boxes


class Bboxes_tools(object):
	def __init__(self, cfg, num_classes, batch_size, threshold=0.5,
				variables=[0.1, 0.1, 0.2, 0.2]):

		self.default_bboxes = self._convert2center_yx(generate_default_boxes(cfg))
		# num_classes is added 1
		self.num_classes = num_classes
		self.batch_size = batch_size
		self.threshold = threshold

		self.variables = variables

		self.i_dtype = {'np':np.int32, 'tf':tf.int32}
		self.f_dtype = {'np':np.float32, 'tf':tf.float32}

	def _convert2center_yx(self, bboxes):
		
		cx = bboxes[..., 0]
		cy = bboxes[..., 1]
		w = bboxes[..., 2]
		h = bboxes[..., 3]

		return np.stack([cy, cx, h, w], axis=-1)

	def _bboxes_decode_layer(self, locations):

		yref = self.default_bboxes_tensor[..., 0]
		xref = self.default_bboxes_tensor[..., 1]
		href = self.default_bboxes_tensor[..., 2]
		wref = self.default_bboxes_tensor[..., 3]


		cx = locations[..., 0] * wref * self.variables[1] + xref
		cy = locations[..., 1] * href * self.variables[0] + yref
		w = wref * tf.exp(locations[..., 2] * self.variables[3])
		h = href * tf.exp(locations[..., 3] * self.variables[2])

		bboxes = tf.stack([cy - h / 2., cx - w / 2.,
						   cy + h / 2., cx + w / 2.], axis=-1)
		return bboxes

	def _bboxes_decode_select(self, pred_predictions, pred_locations, threshold=0.5):
		self.default_bboxes_tensor = tf.constant(self.default_bboxes, dtype=self.f_dtype['tf'])

		pred_predictions = tf.squeeze(pred_predictions, axis=0, name='out_conf')
		bboxes = self._bboxes_decode_layer(pred_locations)
		bboxes = tf.squeeze(bboxes, axis=0, name='out_boxes')

		classes = tf.argmax(pred_predictions, axis=-1)
		scores = tf.reduce_max(pred_predictions, axis=-1)
		
		return classes, scores, bboxes


	def _bboxes_encode_layer(self, encode_ymin, encode_xmin, encode_ymax, encode_xmax):

		yref = self.default_bboxes_tensor[..., 0]
		xref = self.default_bboxes_tensor[..., 1]
		href = self.default_bboxes_tensor[..., 2]
		wref = self.default_bboxes_tensor[..., 3]

		cy = (encode_ymin + encode_ymax) / 2.
		cx = (encode_xmin + encode_xmax) / 2.
		h = encode_ymax - encode_ymin
		w = encode_xmax - encode_xmin

		cy = (cy - yref) / href / self.variables[0]
		cx = (cx - xref) / wref / self.variables[1]
		h = tf.math.log(h / href) / self.variables[2]
		w = tf.math.log(w / wref) / self.variables[3]

		return tf.stack([cx, cy, w, h], axis=-1)

	def _bboxes_encode_match_select_layer(self, labels, bboxes, encoded=True):
		encode_shape = self.default_bboxes_tensor.get_shape().as_list()[0]

		encode_labels = tf.zeros(encode_shape, dtype=self.i_dtype['tf'])
		encode_scores = tf.zeros(encode_shape, dtype=self.f_dtype['tf'])
		record_scores = tf.zeros(encode_shape, dtype=self.f_dtype['tf'])

		encode_ymin = tf.zeros(encode_shape, dtype=self.f_dtype['tf'])
		encode_xmin = tf.zeros(encode_shape, dtype=self.f_dtype['tf'])
		encode_ymax = tf.ones(encode_shape, dtype=self.f_dtype['tf'])
		encode_xmax = tf.ones(encode_shape, dtype=self.f_dtype['tf'])

		def condition(i, encode_labels, encode_scores, record_scores,
						encode_ymin, encode_xmin, encode_ymax, encode_xmax):
			result = tf.less(i, tf.shape(labels)[0])
			return result

		def body(i, encode_labels, encode_scores, record_scores,
						encode_ymin, encode_xmin, encode_ymax, encode_xmax):
			
			_labels = labels[i]
			_bboxes = bboxes[i]

			IOU = _compute_IOU(_bboxes, self.default_bboxes_tensor)
			iou_max_idx = tf.argmax(IOU)

			max_mask = tf.where(tf.equal(IOU, IOU[iou_max_idx]), tf.ones_like(IOU), tf.zeros_like(IOU))
			max_mask = tf.cast(max_mask, tf.bool)

			imax_mask = tf.cast(max_mask, self.i_dtype['tf'])
			fmax_mask = tf.cast(max_mask, self.f_dtype['tf'])

			encode_labels = imax_mask * _labels + (1 - imax_mask) * encode_labels
			encode_scores = tf.where(max_mask, IOU, encode_scores)
			record_scores = tf.where(max_mask, tf.ones_like(IOU) * (-1), record_scores)

			IOU = tf.where(max_mask, tf.zeros_like(IOU), IOU)

			encode_ymin = fmax_mask * _bboxes[0] + (1 - fmax_mask) * encode_ymin
			encode_xmin = fmax_mask * _bboxes[1] + (1 - fmax_mask) * encode_xmin
			encode_ymax = fmax_mask * _bboxes[2] + (1 - fmax_mask) * encode_ymax
			encode_xmax = fmax_mask * _bboxes[3] + (1 - fmax_mask) * encode_xmax
			
			mask = tf.greater(IOU, 0.5)
			mask = tf.logical_and(mask, tf.logical_not(tf.equal(record_scores, -1)))
			mask = tf.logical_and(mask, tf.greater(IOU, encode_scores))
			mask = tf.logical_and(mask, tf.less(_labels, self.num_classes))

			imask = tf.cast(mask, self.i_dtype['tf'])
			fmask = tf.cast(mask, self.f_dtype['tf'])

			encode_labels = imask * _labels + (1 - imask) * encode_labels
			encode_scores = tf.where(mask, IOU, encode_scores)

			encode_ymin = fmask * _bboxes[0] + (1 - fmask) * encode_ymin
			encode_xmin = fmask * _bboxes[1] + (1 - fmask) * encode_xmin
			encode_ymax = fmask * _bboxes[2] + (1 - fmask) * encode_ymax
			encode_xmax = fmask * _bboxes[3] + (1 - fmask) * encode_xmax

			return [i + 1, encode_labels, encode_scores, record_scores,
					encode_ymin, encode_xmin, encode_ymax, encode_xmax]
		i = 0
		[i, encode_labels, encode_scores, record_scores,
			encode_ymin, encode_xmin, encode_ymax, encode_xmax] = tf.while_loop(condition, body,
																	[i, encode_labels, encode_scores, record_scores,
																		encode_ymin, encode_xmin, encode_ymax, encode_xmax])

		if encoded:
			encode_locations = self._bboxes_encode_layer(encode_ymin, encode_xmin, encode_ymax, encode_xmax)
		else:
			encode_locations = tf.stack([encode_ymin, encode_xmin, encode_ymax, encode_xmax], axis=-1)

		return encode_labels, encode_scores, encode_locations

	def _filter_air(self, g_labels, g_bboxes):
		lmask = tf.logical_not(tf.equal(g_labels, -1))
		bmask = tf.logical_not(tf.equal(g_bboxes, -1))

		f_lables = tf.reshape(tf.boolean_mask(g_labels, lmask), [-1])
		f_bboxes = tf.reshape(tf.boolean_mask(g_bboxes, bmask), [-1, 4])

		return f_lables, f_bboxes

	def _bboxes_encode_match_select_tf(self, gt_labels, gt_bboxes, encoded=True, one_hot=True):
		self.default_bboxes_tensor = tf.constant(self.default_bboxes, dtype=self.f_dtype['tf'])

		encode_labels_tensor = list()
		encode_scores_tensor = list()
		encode_locations_tensor = list()

		for batch in range(self.batch_size):
			labels = gt_labels[batch]
			bboxes = gt_bboxes[batch]
			encode_labels, encode_scores, encode_locations = self._bboxes_encode_match_select_layer(labels, bboxes, encoded=encoded)

			encode_labels_tensor.append(encode_labels)
			encode_scores_tensor.append(encode_scores)
			encode_locations_tensor.append(encode_locations)

		encode_labels_tensor = tf.stack(encode_labels_tensor, axis=0)
		encode_scores_tensor = tf.stack(encode_scores_tensor, axis=0)
		encode_locations_tensor = tf.stack(encode_locations_tensor, axis=0)

		if one_hot:
			encode_labels_tensor = tf.one_hot(encode_labels_tensor, self.num_classes)
		
		return encode_labels_tensor, encode_scores_tensor, encode_locations_tensor




ymlPath = './config.yml'
def create_encode(num_classes, batch_size, YAML_USE, data_format='tf'):
	assert os.path.exists(ymlPath), 'Yaml data not found: {}'.format(ymlPath)

	with open(ymlPath) as f:
		cfg = yaml.load(f)

	encode_tool = Bboxes_tools(cfg[YAML_USE], num_classes, batch_size)

	if data_format == 'tf':
		return encode_tool._bboxes_encode_match_select_tf
	elif data_format == 'box':
		return encode_tool.default_bboxes

def create_decode(num_classes, batch_size, YAML_USE):
	assert os.path.exists(ymlPath), 'Yaml data not found: {}'.format(ymlPath)

	with open(ymlPath) as f:
		cfg = yaml.load(f)
	encode_tool = Bboxes_tools(cfg[YAML_USE], num_classes, batch_size)

	return encode_tool._bboxes_decode_select
