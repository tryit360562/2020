# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'light_GUI.ui'
#
# Created by: PyQt5 UI code generator 5.14.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
from time import sleep
from PyQt5.QtGui import QPixmap, QImage

class MyWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()

    def closeEvent(self, event):
        QtWidgets.QApplication.closeAllWindows()

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        width = 342
        height = 321
        Form.resize(width, height)
        Form.setFixedWidth(width)
        Form.setFixedHeight(height)
        
        self.light = multi_ncs()
        self.verticalLayoutWidget_2 = QtWidgets.QWidget(Form)
        self.verticalLayoutWidget_2.setGeometry(QtCore.QRect(20, 20, 181, 281))
        self.verticalLayoutWidget_2.setObjectName("verticalLayoutWidget_2")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_2)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.lb_size = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        self.lb_size.setFont(font)
        self.lb_size.setAutoFillBackground(True)
        self.lb_size.setAlignment(QtCore.Qt.AlignCenter)
        self.lb_size.setObjectName("lb_size")
        self.verticalLayout.addWidget(self.lb_size)
        self.rBtn_300 = QtWidgets.QRadioButton(self.verticalLayoutWidget_2)
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        self.rBtn_300.setFont(font)
        self.rBtn_300.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.rBtn_300.setObjectName("rBtn_300")
        self.verticalLayout.addWidget(self.rBtn_300)
        self.rBtn_512 = QtWidgets.QRadioButton(self.verticalLayoutWidget_2)
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        self.rBtn_512.setFont(font)
        self.rBtn_512.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.rBtn_512.setObjectName("rBtn_512")
        self.verticalLayout.addWidget(self.rBtn_512)
        self.verticalLayout_2.addLayout(self.verticalLayout)
        self.lb_video = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        self.lb_video.setFont(font)
        self.lb_video.setAutoFillBackground(True)
        self.lb_video.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.lb_video.setScaledContents(False)
        self.lb_video.setAlignment(QtCore.Qt.AlignCenter)
        self.lb_video.setWordWrap(False)
        self.lb_video.setObjectName("lb_video")
        self.verticalLayout_2.addWidget(self.lb_video)
        self.lv_video = QtWidgets.QListView(self.verticalLayoutWidget_2)
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        self.lv_video.setFont(font)
        self.lv_video.setObjectName("lv_video")
        self.verticalLayout_2.addWidget(self.lv_video)
        self.verticalLayoutWidget_3 = QtWidgets.QWidget(Form)
        self.verticalLayoutWidget_3.setGeometry(QtCore.QRect(240, 20, 81, 101))
        self.verticalLayoutWidget_3.setObjectName("verticalLayoutWidget_3")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_3)
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.btn_start = QtWidgets.QPushButton(self.verticalLayoutWidget_3)
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        self.btn_start.setFont(font)
        self.btn_start.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.btn_start.setObjectName("btn_start")
        self.verticalLayout_3.addWidget(self.btn_start)
        self.btn_stop = QtWidgets.QPushButton(self.verticalLayoutWidget_3)
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        self.btn_stop.setFont(font)
        self.btn_stop.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.btn_stop.setObjectName("btn_stop")
        self.verticalLayout_3.addWidget(self.btn_stop)

        self.gap_lb = QtWidgets.QLabel(self.verticalLayoutWidget_3)
        font = QtGui.QFont()
        font.setFamily("微軟正黑體")
        self.gap_lb.setFont(font)
        self.gap_lb.setText('Gap:0')
        self.gap_lb.setAutoFillBackground(True)
        self.gap_lb.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.gap_lb.setScaledContents(False)
        self.gap_lb.setAlignment(QtCore.Qt.AlignCenter)
        self.gap_lb.setWordWrap(False)
        self.gap_lb.setObjectName("gap_lb")
        self.verticalLayout_3.addWidget(self.gap_lb)
        

        self.slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.verticalLayout_3.addWidget(self.slider)
        self.slider.setTickPosition(QtWidgets.QSlider.TicksBelow)
        self.slider.setTickInterval(5)
        self.slider.setMinimum(0)
        self.slider.setMaximum(30)
        self.slider.setValue(0)

        self.slider.valueChanged.connect(self.slider_change)


        self.init()
        
        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

        self.rBtn_300.toggled.connect(self.size_click)
        self.rBtn_512.toggled.connect(self.size_click)
        self.btn_start.clicked.connect(self.start_video)
        self.btn_stop.clicked.connect(self.stop_video)


    def slider_change(self):
        sli_value = self.slider.value()
        self.gap_lb.setText('Gap:{}'.format(sli_value))




    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Traffic light"))
        self.lb_size.setText(_translate("Form", "Size"))
        self.rBtn_300.setText(_translate("Form", "300"))
        self.rBtn_512.setText(_translate("Form", "512"))
        self.lb_video.setText(_translate("Form", "Video"))
        self.btn_start.setText(_translate("Form", "Start"))
        self.btn_stop.setText(_translate("Form", "Stop"))

    def init(self):
        self.rBtn_300.setChecked(True)
        self.rBtn_512.setChecked(False)
        self.check_size()
        self.thread = None
        self.stop = False

        self.clip_path = './Videos'
        self.clip_data = sorted(os.listdir(self.clip_path))
        self.slm = QtCore.QStringListModel()
        self.slm.setStringList(self.clip_data)

        self.lv_video.setModel(self.slm)
        self.lv_video.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.lv_video.setCurrentIndex(self.slm.index(0))

    def check_size(self):
        if self.rBtn_300.isChecked():
            self.IMG_SIZE = 300
        else:
            self.IMG_SIZE = 512

    def draw_result(self, lb_, slider_value, queue):

        first = True
        while True:
            if self.stop:
                break

            if queue.qsize() > 15 * (slider_value + 1) and first:
                qu = queue.get()
                height, width, depth = qu.shape

                cvimg = QImage(qu.data, width, height, width * depth, QImage.Format_RGB888)
                pix = QPixmap(cvimg)
                lb_.setPixmap(pix)
                sleep(0.1)
                first = False
            elif not first and queue.qsize() > 0:
                qu = queue.get()
                height, width, depth = qu.shape

                cvimg = QImage(qu.data, width, height, width * depth, QImage.Format_RGB888)
                pix = QPixmap(cvimg)
                lb_.setPixmap(pix)
                sleep(0.1)



    def start_video(self):
        self.video_window = QtWidgets.QMainWindow()
        self.video_window.setGeometry(0, 0, self.IMG_SIZE + 200, self.IMG_SIZE)
        self.video_window.setFixedWidth(self.IMG_SIZE + 200)
        self.video_window.setFixedHeight(self.IMG_SIZE)


        self.v_lb = QtWidgets.QLabel(self.video_window)
        self.v_lb.setGeometry(0, 0, self.IMG_SIZE + 200, self.IMG_SIZE)
        self.v_lb.setScaledContents(True)

        self.video_window.show()

        index = self.lv_video.currentIndex().row()

        demo_clip = self.clip_data[index]
        
        self.video_window.setWindowTitle(demo_clip)



        if hasattr(self.thread, 'is_alive'):
            self.light.stop_light()
            self.stop = True
            sleep(2)


        self.stop = False
        self.light.start_light()

        self.thread = Thread(target=self.light.main, args=(self.v_lb, self.slider.value(), demo_clip, self.IMG_SIZE))
        self.thread.daemon = True
        self.thread.start()

    def stop_video(self):

        if self.thread.is_alive():
            self.light.stop_light()
            self.video_window.close()
            self.stop = True

    def size_click(self):
        self.check_size()



import sys
from ncs import multi_ncs
from threading import Thread
import multiprocessing
import os
import queue
from time import sleep

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MyWindow()
    ui = Ui_Form()
    ui.setupUi(window)
    window.show()
    sys.exit(app.exec_())
