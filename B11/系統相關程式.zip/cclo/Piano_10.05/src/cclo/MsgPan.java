/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cclo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author cclo
 */
public class MsgPan extends JPanel {

    Main main;
    DecimalFormat df = new DecimalFormat("0.00");
    JTextField tfMsg;
    JButton btGo;
    boolean going = false;

    public MsgPan(Main main_) {
        main = main_;
        tfMsg = new JTextField("Hello");
        btGo = new JButton("Go");
        Font font = new Font("Serif", Font.BOLD, 48);
        tfMsg.setFont(font);
        btGo.setFont(font);
        
        // init condition
        btGo.setOpaque(true);
        btGo.setBackground(Color.GREEN);

        this.setLayout(new BorderLayout());
        add(tfMsg, BorderLayout.CENTER);
        add(btGo, BorderLayout.EAST);
        btGo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (going) {
                    // change to stop conditon
                    going = false;
                    btGo.setText("Go");
                    btGo.setBackground(Color.GREEN);
                    main.newClass.stopRec();
                } else {
                    // change to go
                    going = true;
                    btGo.setText("Stop");
                    btGo.setBackground(Color.RED);
                    main.newClass.musicState = 0;
                    main.newClass.beginRec();
                }                
            }
        });
    }

    public void showMsg(String str_) {
        tfMsg.setText(str_);
    }
}
