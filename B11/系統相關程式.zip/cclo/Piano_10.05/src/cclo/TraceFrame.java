/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cclo;

import project.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Queue;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author user
 */
public class TraceFrame extends JFrame implements Share {

    public Queue<FVec> queue = new LinkedList<FVec>();
    TracePanel tracePanel;
    Boolean start = true;
    JButton showStop;
    int rate = 3;

    public TraceFrame() {
        Container container = this.getContentPane();
        tracePanel = new TracePanel();
        container.setLayout(new BorderLayout());
        container.add(tracePanel, BorderLayout.CENTER);
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new GridLayout(4, 1));
        showStop = new JButton("Stop");
        rightPanel.add(showStop);
        container.add(rightPanel, BorderLayout.EAST);
        showStop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (start) {
                    start = false;
                    showStop.setText("Start");
                } else {
                    start = true;
                    showStop.setText("Stop");
                }
            }
        });
    }

    public void pInsert(int[] intVec) {
        rate = (rate + 1) % 3;
        if (rate != 0) {
            return;
        }

        if (!start) {
            return;
        }
        FVec newVec = new FVec(intVec);
        synchronized (queue) {
            if (queue.size() < 600) {
                queue.offer(newVec);
            } else {
                queue.poll();
                queue.offer(newVec);
            }
            tracePanel.repaint();
        }
    }

    class TracePanel extends JPanel {

        public void paintComponent(Graphics g) {
            int x = 20, y = 20;
            int width = this.getWidth();
            int height = this.getHeight();
            g.setColor(Color.WHITE);
            g.clearRect(0, 0, 1200, 800);
            g.setColor(Color.red);
            for (int i = 0; i < 50; i++) {
                g.drawLine(x + i * 20, y + 50, x + i * 20, y + 500);
            }

            for (int i = 0; i < 10; i++) {
                g.drawString(String.valueOf(i * 100), x + i * 200, y);
            }

            y+=50;
            g.setColor(Color.BLUE);
            // g.drawString("Hello", 100, 100);
            synchronized (queue) {
                for (FVec fv : queue) {
                    x = 20;
                    for (int i = 0; i < 500; i++) {
                        if (fv.spec[i] == 1) {
                            g.drawOval(x + i * 2, y, 2, 2);
                            x++;
                        }
                    }
                    y++;
                }
            }
        }
    }

}

class FVec {

    public int[] spec = new int[2048];

    public FVec(int[] in_) {
        spec = in_.clone();
    }
}
