/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cclo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author cclo
 */
public class SheetFrame extends JFrame {

    ArrayList<Integer> symbols = new ArrayList<>();  // 記錄本來打上去的有那些
    SheetPanel sheetPan = new SheetPanel();
    BufferedImage[] imgSingle = new BufferedImage[43];  // 記錄單音37個圖片
    BufferedImage imgSilent;
    
    public void add(int symbol_) {
        symbols.add(symbol_);
        repaint();
    }

    public SheetFrame() {
        Container container = this.getContentPane();
        sheetPan = new SheetFrame.SheetPanel();
        container.setLayout(new BorderLayout());
        container.add(sheetPan, BorderLayout.CENTER);
        try {
            for (int i = 0; i < 44; i++) {
                imgSingle[i] = ImageIO.read(new File("single//"+ i + ".png"));
            }
            imgSilent = ImageIO.read(new File("single//silent.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    class SheetPanel extends JPanel {

        public void paintComponent(Graphics g) {
            int xBorder = 20, yBorder = 20;
            int x = xBorder, y = yBorder;
            int width = this.getWidth();
            int height = this.getHeight();
            g.setColor(Color.WHITE);
            g.clearRect(0, 0, 1200, 800);
            for (int symbol: symbols) {
                g.drawImage(imgSingle[symbol], x, y, this);
                x+= 59;
                if (x > (width - 90)) {
                    x  = xBorder;
                    y += 125;
                }
            }
        }
    }
}
