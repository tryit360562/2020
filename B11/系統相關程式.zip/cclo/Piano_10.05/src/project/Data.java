/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.ArrayList;
import java.util.Arrays;

public class Data {    
    
    //單音辨識
    ArrayList<Integer> A0 = new ArrayList<>(Arrays.asList(13, 25, 38, 49, 63, 74, 88, 110, 129, 146, 166, 183, 207));
    
    ArrayList<Integer> AA0 = new ArrayList<>(Arrays.asList(20, 39, 52, 67, 78, 92, 116, 136, 155, 168, 176, 194, 232));
               
    ArrayList<Integer> B0 = new ArrayList<>(Arrays.asList(15, 28, 44, 58, 70, 83, 104, 123, 144, 164, 186));
    
    ArrayList<Integer> C1 = new ArrayList<>(Arrays.asList(15, 22, 48, 63, 75, 88, 111, 130, 152, 163, 174, 197, 217));
    
    ArrayList<Integer> CC1 = new ArrayList<>(Arrays.asList(16, 24, 50, 62, 78, 93, 114, 138, 150, 161, 184, 209, 231));
    
    ArrayList<Integer> D1 = new ArrayList<>(Arrays.asList(24, 39, 53, 68, 84, 105, 116, 146, 160, 172, 183, 195, 211, 230));
    
    ArrayList<Integer> DD1 = new ArrayList<>(Arrays.asList(26, 40, 53, 72, 86, 101, 118, 132, 150, 163, 187, 213, 234));
        
    ArrayList<Integer> E1 = new ArrayList<>(Arrays.asList(12, 25, 49, 60, 74, 88, 106, 124, 149, 162, 173, 248));
    
    ArrayList<Integer> F1 = new ArrayList<>(Arrays.asList(11, 28, 37, 52, 81, 96, 112, 131, 148, 159, 173));
        
    ArrayList<Integer> FF1 = new ArrayList<>(Arrays.asList(12, 21, 41, 62, 85, 101, 119, 131, 149, 161, 181));
        
    ArrayList<Integer> G1 = new ArrayList<>(Arrays.asList(13, 25, 41, 53, 64, 90, 107, 127, 158, 192, 210, 254));
       
    ArrayList<Integer> GG1 = new ArrayList<>(Arrays.asList(14, 26, 44, 68, 93, 113, 133, 147, 168, 184, 204, 236));
    
    ArrayList<Integer> A1 = new ArrayList<>(Arrays.asList(25, 36, 59, 71, 101, 120, 141, 152, 178, 216));
    
    ArrayList<Integer> AA1 = new ArrayList<>(Arrays.asList(16, 36, 49, 63, 77, 105, 127, 150, 164, 188, 228));
    
    ArrayList<Integer> B1 = new ArrayList<>(Arrays.asList(16, 29, 61, 80, 91, 111, 135, 159, 171, 199, 210, 235));
    
    ArrayList<Integer> C2 = new ArrayList<>(Arrays.asList(18, 43, 65, 86, 118, 132, 143, 169, 184, 212));
    
    ArrayList<Integer> CC2 = new ArrayList<>(Arrays.asList(19, 35, 46, 62, 75, 92, 103, 117, 129, 151, 178, 196, 217));
    
    ArrayList<Integer> D2 = new ArrayList<>(Arrays.asList(20, 37, 62, 73, 95, 109, 132, 148, 160, 177, 189, 207, 237));
        
    ArrayList<Integer> DD2 = new ArrayList<>(Arrays.asList(22, 40, 51, 62, 85, 101, 115, 132, 144, 170, 187, 200, 215, 236, 251));
    
    ArrayList<Integer> E2 = new ArrayList<>(Arrays.asList(15, 27, 38, 58, 86, 103, 120, 132, 151, 179, 198));
    
    ArrayList<Integer> F2 = new ArrayList<>(Arrays.asList(14, 28, 49, 61, 87, 100, 127, 145, 160, 195, 210));
    
    ArrayList<Integer> FF2 = new ArrayList<>(Arrays.asList(14, 30, 43, 65, 79, 92, 106, 134, 148, 169, 212));
    
    ArrayList<Integer> G2 = new ArrayList<>(Arrays.asList(14, 32, 45, 69, 112, 142, 157, 179, 190, 213, 236));
    
    ArrayList<Integer> GG2 = new ArrayList<>(Arrays.asList(14, 24, 34, 44, 58, 63, 73, 88, 114, 151, 178, 190, 202, 225));
    
    ArrayList<Integer> A2 = new ArrayList<>(Arrays.asList(15, 36, 77, 88, 104, 120, 137, 160, 175, 201, 220, 239));
    
    ArrayList<Integer> AA2 = new ArrayList<>(Arrays.asList(27, 38, 49, 65, 82, 110, 127, 145, 169, 185, 200, 213));
    
    ArrayList<Integer> B2 = new ArrayList<>(Arrays.asList(12, 23, 29, 40, 57, 69, 81, 111, 129, 136, 142, 155, 175));
    
    ArrayList<Integer> C3 = new ArrayList<>(Arrays.asList(18, 30, 43, 61, 73, 86, 103, 117, 137));
    
    ArrayList<Integer> CC3 = new ArrayList<>(Arrays.asList(13, 26, 45, 65, 78, 91, 124, 145, 159));
    
    ArrayList<Integer> D3 = new ArrayList<>(Arrays.asList(14, 27, 48, 68, 82, 103, 132, 154, 169));
    
    ArrayList<Integer> DD3 = new ArrayList<>(Arrays.asList(14, 51, 73, 88, 103, 118, 142, 159));
    
    ArrayList<Integer> E3 = new ArrayList<>(Arrays.asList(15, 54, 69, 93, 117, 159, 185));
    
    ArrayList<Integer> F3 = new ArrayList<>(Arrays.asList(16, 40, 57, 82, 98, 124));
    
    ArrayList<Integer> FF3 = new ArrayList<>(Arrays.asList(17, 34, 60, 78, 113, 132, 208));
    
    ArrayList<Integer> G3 = new ArrayList<>(Arrays.asList(18, 36, 64, 82, 120, 139, 220, 231));
    
    ArrayList<Integer> GG3 = new ArrayList<>(Arrays.asList(19, 29, 38, 48, 68, 127, 147, 158, 190, 201, 234, 245));
    
    ArrayList<Integer> A3 = new ArrayList<>(Arrays.asList(10, 20, 31, 51, 72, 103, 114, 135, 157, 168, 224, 248));
    
    ArrayList<Integer> AA3 = new ArrayList<>(Arrays.asList(11, 22, 43, 54, 65, 76, 87, 98, 109, 121, 132, 144, 167, 179));
    
    ArrayList<Integer> B3 = new ArrayList<>(Arrays.asList(12, 23, 34, 46, 57, 70, 81, 92, 104, 116, 128, 140, 152, 164, 190));
    
    ArrayList<Integer> C4 = new ArrayList<>(Arrays.asList(12, 24, 36, 49, 61, 73, 85, 98, 110, 123, 136, 149, 161, 175, 201));
    
    ArrayList<Integer> CC4 = new ArrayList<>(Arrays.asList(13, 26, 39, 50, 65, 90, 103, 117, 130, 144, 157, 171, 183, 213));
    
    ArrayList<Integer> D4 = new ArrayList<>(Arrays.asList(14, 28, 41, 53, 68, 83, 96, 109, 124, 138, 152, 167, 181, 194, 225));
    
    ArrayList<Integer> DD4 = new ArrayList<>(Arrays.asList(14, 29, 43, 58, 72, 87, 102, 116, 131, 146, 161, 178, 192, 207, 239));
    
    ArrayList<Integer> E4 = new ArrayList<>(Arrays.asList(15, 30, 46, 62, 77, 93, 108, 124, 140, 173, 190, 209, 225));
    
    ArrayList<Integer> F4 = new ArrayList<>(Arrays.asList(16, 32, 49, 65, 81, 98, 115, 132, 149, 166, 184, 221, 239));
    
    ArrayList<Integer> FF4 = new ArrayList<>(Arrays.asList(17, 34, 52, 69, 86, 104, 121, 139, 158, 176, 194, 214, 226));
    
    ArrayList<Integer> G4 = new ArrayList<>(Arrays.asList(18, 36, 55, 73, 92, 110, 130, 148, 167, 187, 206, 226, 239));
    
    ArrayList<Integer> GG4 = new ArrayList<>(Arrays.asList(19, 39, 58, 78, 97, 117, 138, 159, 180));
    
    ArrayList<Integer> A4 = new ArrayList<>(Arrays.asList(21, 42, 62, 83, 103, 125, 146, 168, 191));
    
    ArrayList<Integer> AA4 = new ArrayList<>(Arrays.asList(22, 44, 65, 87, 109, 132, 155, 202));
    
    ArrayList<Integer> B4 = new ArrayList<>(Arrays.asList(23, 46, 69, 92, 116, 140, 164, 187, 214));
    
    ArrayList<Integer> C5 = new ArrayList<>(Arrays.asList(24, 50, 73, 98, 123, 149, 173, 199, 227));
    
    ArrayList<Integer> CC5 = new ArrayList<>(Arrays.asList(26, 52, 78, 104, 130, 156, 184, 211, 240));
    
    ArrayList<Integer> D5 = new ArrayList<>(Arrays.asList(27, 55, 82, 110, 138, 166, 195, 254));
    
    ArrayList<Integer> DD5 = new ArrayList<>(Arrays.asList(29, 58, 87, 117, 147, 177, 204));
    
    ArrayList<Integer> E5 = new ArrayList<>(Arrays.asList(31, 61, 92, 124, 156, 188, 255));
    
    ArrayList<Integer> F5 = new ArrayList<>(Arrays.asList(32, 65, 98, 131, 165, 199));
    
    ArrayList<Integer> FF5 = new ArrayList<>(Arrays.asList(34, 69, 104, 139, 174, 211));
    
    ArrayList<Integer> G5 = new ArrayList<>(Arrays.asList(36, 73, 110, 147, 185));
    
    ArrayList<Integer> GG5 = new ArrayList<>(Arrays.asList(39, 78, 156, 197, 237));
    
    ArrayList<Integer> A5 = new ArrayList<>(Arrays.asList(41, 82, 124, 165, 208, 251));
    
    ArrayList<Integer> AA5 = new ArrayList<>(Arrays.asList(43, 87, 132, 177, 224));
    
    ArrayList<Integer> B5 = new ArrayList<>(Arrays.asList(46, 92, 139, 188));
    
    ArrayList<Integer> C6 = new ArrayList<>(Arrays.asList(49, 98, 148, 198, 251));
    
    ArrayList<Integer> CC6 = new ArrayList<>(Arrays.asList(52, 104, 156, 210));
    
    ArrayList<Integer> D6 = new ArrayList<>(Arrays.asList(55, 110, 166, 223));
    
    ArrayList<Integer> DD6 = new ArrayList<>(Arrays.asList(58, 116, 176, 236));
    
    ArrayList<Integer> E6 = new ArrayList<>(Arrays.asList(61, 123, 187, 250));
    
    ArrayList<Integer> F6 = new ArrayList<>(Arrays.asList(65, 131, 197));
    
    ArrayList<Integer> FF6 = new ArrayList<>(Arrays.asList(69, 138, 209));
    
    ArrayList<Integer> G6 = new ArrayList<>(Arrays.asList(73, 147, 221));
    
    ArrayList<Integer> GG6 = new ArrayList<>(Arrays.asList(78, 156));
    
    ArrayList<Integer> A6 = new ArrayList<>(Arrays.asList(82, 166));
    
    ArrayList<Integer> AA6 = new ArrayList<>(Arrays.asList(87, 174));
    
    ArrayList<Integer> B6 = new ArrayList<>(Arrays.asList(92, 187));
    
    ArrayList<Integer> C7 = new ArrayList<>(Arrays.asList(98, 197));
    
    ArrayList<Integer> CC7 = new ArrayList<>(Arrays.asList(104, 210));
    
    ArrayList<Integer> D7 = new ArrayList<>(Arrays.asList(110, 219));
    
    ArrayList<Integer> DD7 = new ArrayList<>(Arrays.asList(117, 236));
    
    ArrayList<Integer> E7 = new ArrayList<>(Arrays.asList(124, 125, 250));
    
    ArrayList<Integer> F7 = new ArrayList<>(Arrays.asList(132, 133));
    
    ArrayList<Integer> FF7 = new ArrayList<>(Arrays.asList(138, 139, 140));
    //單音辨識End
    
    //和弦辨識
    ArrayList<Integer> CEG = new ArrayList<>(Arrays.asList(18, 24, 36, 47, 61, 62, 73, 85, 92, 123, 136, 148, 161, 190, 206, 226, 243));
    
    ArrayList<Integer> BFG = new ArrayList<>(Arrays.asList(23, 37, 46, 54, 57, 58, 65, 73, 92, 98, 104, 110, 115, 128, 129, 132, 148, 149, 167, 203, 220));   
    //和弦辨識End
} 