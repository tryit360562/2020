///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package project;
//
//import cclo.DiscreteFourierTransform;
//import project.Data;
//import java.text.DecimalFormat;
//import java.util.ArrayList;
//
//public class SoundRecognition {
//
//    static Data data = new Data();
//
//    public static void findPeak(double sound[]) {
//
//        int now = 10;    // 當前位置從第五個開始，前五個頻率不算
//        int interval = 10;  // 取樣間隔為10
//        int sample = 256;    // 設取樣點為256個
//        double max = 0; // maxList的最大值
//        double min_value = 1000;   // 最低峰值
//        double max_value = 0;   // 最高峰值
//        ArrayList<Double> maxList = new ArrayList();
//        ArrayList<Integer> indexList = new ArrayList();
//
////        long startTime = System.currentTimeMillis();    // 獲取開始時間
//        // 找波峰的極大值
//        for (int i = now; i <= sample; i++) {
//            if (sound[i] < min_value) {
//                min_value = sound[i];
//            } else if (sound[i] > max_value) {
//                max_value = sound[i];
//                if (isMax_value(i, max_value, sound)) {
//                    double maxLog = Math.log10(max_value);  // 訊號以10為底取log，單位是分貝 (dB)
//                    DecimalFormat df = new DecimalFormat("##.00000"); // 四捨五入取到小數點第三位
//                    maxLog = Double.parseDouble(df.format(maxLog));
//                    maxList.add(maxLog);
//                    indexList.add(i);
//                    System.out.printf("TRUE! sample index: %d, Max_value: %.5f \r\n", i, maxLog);
//                    i = i + interval;
//                    max_value = sound[i];
//                }
//            }
//        }
//
//        System.out.println("indexList: " + indexList);
//
//        //過濾小波峰，先找出極大值裡面的最大值     
//        for (int i = 0; i < maxList.size(); i++) {
//            if (maxList.get(i) > max) {
//                max = maxList.get(i);
//            }
//        }
//
//        //如果相差太多，就把該極大值刪除
//        for (int i = 0; i < maxList.size(); i++) {
//            if (Math.floor(max) - Math.floor(maxList.get(i)) >= 4 || Math.floor(maxList.get(i)) <= 6) {
//                maxList.remove(i);
//                indexList.remove(i);
//                i -= 1;
//            }
//        }
//        // [1, 2, 5, 7, 9]
//        // 0 1 2 3 4
//        System.out.printf("Result index: %s \r\n", indexList);
//
//        //        long endTime = System.currentTimeMillis();  // 獲取結束時間
//        //        float seconds = (endTime - startTime) / 1000F;  // 毫秒換算成秒，1秒=1000毫秒
//        //        System.out.println("test: " + Float.toString(seconds) + " seconds.");   // 輸出程式執行時間
//        //單音辨識
//        isA0(indexList);
//        isAA0(indexList);
//        isB0(indexList);
//        //
//        isC1(indexList);
//        isCC1(indexList);
//        isD1(indexList);
//        isDD1(indexList);
//        isE1(indexList);
//        isF1(indexList);
//        isFF1(indexList);
//        isG1(indexList);
//        isGG1(indexList);
//        isA1(indexList);
//        isAA1(indexList);
//        isB1(indexList);
//        //
//        isC2(indexList);
//        isCC2(indexList);
//        isD2(indexList);
//        isDD2(indexList);
//        isE2(indexList);
//        isF2(indexList);
//        isFF2(indexList);
//        isG2(indexList);
//        isGG2(indexList);
//        isA2(indexList);
//        isAA2(indexList);
//        isB2(indexList);
//        //
//        isC3(indexList);
//        isCC3(indexList);
//        isD3(indexList);
//        isDD3(indexList);
//        isE3(indexList);
//        isF3(indexList);
//        isFF3(indexList);
//        isG3(indexList);
//        isGG3(indexList);
//        isA3(indexList);
//        isAA3(indexList);
//        isB3(indexList);
//        //中央Do開始
//        isC4(indexList);
//        isCC4(indexList);
//        isD4(indexList);
//        isDD4(indexList);
//        isE4(indexList);
//        isF4(indexList);
//        isFF4(indexList);
//        isG4(indexList);
//        isGG4(indexList);
//        isA4(indexList);
//        isAA4(indexList);
//        isB4(indexList);
//        //中央Si結束
//        isC5(indexList);
//        isCC5(indexList);
//        isD5(indexList);
//        isDD5(indexList);
//        isE5(indexList);
//        isF5(indexList);
//        isFF5(indexList);
//        isG5(indexList);
//        isGG5(indexList);
//        isA5(indexList);
//        isAA5(indexList);
//        isB5(indexList);
//        //
//        isC6(indexList);
//        isCC6(indexList);
//        isD6(indexList);
//        isDD6(indexList);
//        isE6(indexList);
//        isF6(indexList);
//        isFF6(indexList);
//        isG6(indexList);
//        isGG6(indexList);
//        isA6(indexList);
//        isAA6(indexList);
//        isB6(indexList);
//        //
//        isC7(indexList);
//        isCC7(indexList);
//        isD7(indexList);
//        isDD7(indexList);
//        isE7(indexList);
//        isF7(indexList);
//        isFF7(indexList);
//        //單音辨識End
//
//        //和弦辨識
//        isCEG(indexList);
//        isBFG(indexList);
//        //和弦辨識End
//    }
//
//    // 是否找到波峰
//    public static boolean isMax_value(int current, double currentMax, double sound[]) {
//        boolean isMax = true;
//
//        for (int i = current + 1; i <= current + 5; i++) // 先判斷右邊五個位置
//        {
//            if (sound[i] > currentMax) {
//                isMax = false;
//                break;
//            }
//        }
//
//        if (isMax) // 右邊判斷完換判斷左邊，如果右邊已經找到另一個最大值，就不用再判斷了，因為抓得值並不是波峰的極大值
//        {
//            for (int i = current - 1; i >= current - 5; i--) {
//                if (sound[i] > currentMax) {
//                    isMax = false;
//                    break;
//                }
//            }
//        }
//
//        return isMax;
//
//    }
//
//    public static void isA0(ArrayList<Integer> index) {
//
//        int countA0 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.A0.size(); j++) {
//                    if (index.get(i - 1).equals(data.A0.get(j))) {
//                        countA0++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.A0.get(j))) {
//                            countA0++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countA0: " + countA0);
//        if (countA0 <= data.A0.size() && countA0 >= 6) {
//            System.out.println("It's A0");
//        }
//    }
//
//    public static void isAA0(ArrayList<Integer> index) {
//
//        int countAA0 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.AA0.size(); j++) {
//                    if (index.get(i - 1).equals(data.AA0.get(j))) {
//                        countAA0++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.AA0.get(j))) {
//                            countAA0++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countAA0: " + countAA0);
//        if (countAA0 <= data.AA0.size() && countAA0 >= 7) {
//            System.out.println("It's AA0");
//        }
//    }
//
//    public static void isB0(ArrayList<Integer> index) {
//
//        int countB0 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.B0.size(); j++) {
//                    if (index.get(i - 1).equals(data.B0.get(j))) {
//                        countB0++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.B0.get(j))) {
//                            countB0++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countB0: " + countB0);
//        if (countB0 <= data.B0.size() && countB0 >= 7) {
//            System.out.println("It's B0");
//        }
//    }
//
//    public static void isC1(ArrayList<Integer> index) {
//
//        int countC1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.C1.size(); j++) {
//                    if (index.get(i - 1).equals(data.C1.get(j))) {
//                        countC1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.C1.get(j))) {
//                            countC1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countC1: " + countC1);
//        if (countC1 <= data.C1.size() && countC1 >= 6) {
//            System.out.println("It's C1");
//        }
//    }
//
//    public static void isCC1(ArrayList<Integer> index) {
//
//        int countCC1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.CC1.size(); j++) {
//                    if (index.get(i - 1).equals(data.CC1.get(j))) {
//                        countCC1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.CC1.get(j))) {
//                            countCC1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countCC1: " + countCC1);
//        if (countCC1 <= data.CC1.size() && countCC1 >= 6) {
//            System.out.println("It's CC1");
//        }
//    }
//
//    public static void isD1(ArrayList<Integer> index) {
//
//        int countD1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.D1.size(); j++) {
//                    if (index.get(i - 1).equals(data.D1.get(j))) {
//                        countD1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.D1.get(j))) {
//                            countD1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countD1: " + countD1);
//        if (countD1 <= data.D1.size() && countD1 >= 6) {
//            System.out.println("It's D1");
//        }
//    }
//
//    public static void isDD1(ArrayList<Integer> index) {
//
//        int countDD1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.DD1.size(); j++) {
//                    if (index.get(i - 1).equals(data.DD1.get(j))) {
//                        countDD1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.DD1.get(j))) {
//                            countDD1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countDD1: " + countDD1);
//        if (countDD1 <= data.DD1.size() && countDD1 >= 7) {
//            System.out.println("It's DD1");
//        }
//    }
//
//    public static void isE1(ArrayList<Integer> index) {
//
//        int countE1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.E1.size(); j++) {
//                    if (index.get(i - 1).equals(data.E1.get(j))) {
//                        countE1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.E1.get(j))) {
//                            countE1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countE1: " + countE1);
//        if (countE1 <= data.E1.size() && countE1 >= 7) {
//            System.out.println("It's E1");
//        }
//    }
//
//    public static void isF1(ArrayList<Integer> index) {
//
//        int countF1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.F1.size(); j++) {
//                    if (index.get(i - 1).equals(data.F1.get(j))) {
//                        countF1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.F1.get(j))) {
//                            countF1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countF1: " + countF1);
//        if (countF1 <= data.F1.size() && countF1 >= 5) {
//            System.out.println("It's F1");
//        }
//    }
//
//    public static void isFF1(ArrayList<Integer> index) {
//
//        int countFF1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.FF1.size(); j++) {
//                    if (index.get(i - 1).equals(data.FF1.get(j))) {
//                        countFF1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.FF1.get(j))) {
//                            countFF1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countFF1: " + countFF1);
//        if (countFF1 <= data.FF1.size() && countFF1 >= 5) {
//            System.out.println("It's FF1");
//        }
//    }
//
//    public static void isG1(ArrayList<Integer> index) {
//
//        int countG1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.G1.size(); j++) {
//                    if (index.get(i - 1).equals(data.G1.get(j))) {
//                        countG1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.G1.get(j))) {
//                            countG1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countG1: " + countG1);
//        if (countG1 <= data.G1.size() && countG1 >= 7) {
//            System.out.println("It's G1");
//        }
//    }
//
//    public static void isGG1(ArrayList<Integer> index) {
//
//        int countGG1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.GG1.size(); j++) {
//                    if (index.get(i - 1).equals(data.GG1.get(j))) {
//                        countGG1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.GG1.get(j))) {
//                            countGG1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countGG1: " + countGG1);
//        if (countGG1 <= data.GG1.size() && countGG1 >= 7) {
//            System.out.println("It's GG1");
//        }
//    }
//
//    public static void isA1(ArrayList<Integer> index) {
//
//        int countA1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.A1.size(); j++) {
//                    if (index.get(i - 1).equals(data.A1.get(j))) {
//                        countA1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.A1.get(j))) {
//                            countA1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countA1: " + countA1);
//        if (countA1 <= data.A1.size() && countA1 >= 7) {
//            System.out.println("It's A1");
//        }
//    }
//
//    public static void isAA1(ArrayList<Integer> index) {
//
//        int countAA1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.AA1.size(); j++) {
//                    if (index.get(i - 1).equals(data.AA1.get(j))) {
//                        countAA1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.AA1.get(j))) {
//                            countAA1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countAA1: " + countAA1);
//        if (countAA1 <= data.AA1.size() && countAA1 >= 7) {
//            System.out.println("It's AA1");
//        }
//    }
//
//    public static void isB1(ArrayList<Integer> index) {
//
//        int countB1 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.B1.size(); j++) {
//                    if (index.get(i - 1).equals(data.B1.get(j))) {
//                        countB1++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.B1.get(j))) {
//                            countB1++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countB1: " + countB1);
//        if (countB1 <= data.B1.size() && countB1 >= 7) {
//            System.out.println("It's B1");
//        }
//    }
//
//    public static void isC2(ArrayList<Integer> index) {
//
//        int countC2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.C2.size(); j++) {
//                    if (index.get(i - 1).equals(data.C2.get(j))) {
//                        countC2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.C2.get(j))) {
//                            countC2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countC2: " + countC2);
//        if (countC2 <= data.C2.size() && countC2 >= 6) {
//            System.out.println("It's C2");
//        }
//    }
//
//    public static void isCC2(ArrayList<Integer> index) {
//
//        int countCC2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.CC2.size(); j++) {
//                    if (index.get(i - 1).equals(data.CC2.get(j))) {
//                        countCC2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.CC2.get(j))) {
//                            countCC2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countCC2: " + countCC2);
//        if (countCC2 <= data.CC2.size() && countCC2 >= 8) {
//            System.out.println("It's CC2");
//        }
//    }
//
//    public static void isD2(ArrayList<Integer> index) {
//
//        int countD2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.D2.size(); j++) {
//                    if (index.get(i - 1).equals(data.D2.get(j))) {
//                        countD2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.D2.get(j))) {
//                            countD2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countD2: " + countD2);
//        if (countD2 <= data.D2.size() && countD2 >= 7) {
//            System.out.println("It's D2");
//        }
//    }
//
//    public static void isDD2(ArrayList<Integer> index) {
//
//        int countDD2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.DD2.size(); j++) {
//                    if (index.get(i - 1).equals(data.DD2.get(j))) {
//                        countDD2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.DD2.get(j))) {
//                            countDD2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countDD2: " + countDD2);
//        if (countDD2 <= data.DD2.size() && countDD2 >= 12) {
//            System.out.println("It's DD2");
//        }
//    }
//
//    public static void isE2(ArrayList<Integer> index) {
//
//        int countE2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.E2.size(); j++) {
//                    if (index.get(i - 1).equals(data.E2.get(j))) {
//                        countE2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.E2.get(j))) {
//                            countE2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countE2: " + countE2);
//        if (countE2 <= data.E2.size() && countE2 >= 7) {
//            System.out.println("It's E2");
//        }
//    }
//
//    public static void isF2(ArrayList<Integer> index) {
//
//        int countF2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.F2.size(); j++) {
//                    if (index.get(i - 1).equals(data.F2.get(j))) {
//                        countF2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.F2.get(j))) {
//                            countF2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countF2: " + countF2);
//        if (countF2 <= data.F2.size() && countF2 >= 6) {
//            System.out.println("It's F2");
//        }
//    }
//
//    public static void isFF2(ArrayList<Integer> index) {
//
//        int countFF2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.FF2.size(); j++) {
//                    if (index.get(i - 1).equals(data.FF2.get(j))) {
//                        countFF2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.FF2.get(j))) {
//                            countFF2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countFF2: " + countFF2);
//        if (countFF2 <= data.FF2.size() && countFF2 >= 6) {
//            System.out.println("It's FF2");
//        }
//    }
//
//    public static void isG2(ArrayList<Integer> index) {
//
//        int countG2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.G2.size(); j++) {
//                    if (index.get(i - 1).equals(data.G2.get(j))) {
//                        countG2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.G2.get(j))) {
//                            countG2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countG2: " + countG2);
//        if (countG2 <= data.G2.size() && countG2 >= 6) {
//            System.out.println("It's G2");
//        }
//    }
//
//    public static void isGG2(ArrayList<Integer> index) {
//
//        int countGG2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 11) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.GG2.size(); j++) {
//                    if (index.get(i - 1).equals(data.GG2.get(j))) {
//                        countGG2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.GG2.get(j))) {
//                            countGG2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countGG2: " + countGG2);
//        if (countGG2 <= data.GG2.size() && countGG2 >= 6) {
//            System.out.println("It's GG2");
//        }
//    }
//
//    public static void isA2(ArrayList<Integer> index) {
//
//        int countA2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 11) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.A2.size(); j++) {
//                    if (index.get(i - 1).equals(data.A2.get(j))) {
//                        countA2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.A2.get(j))) {
//                            countA2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countA2: " + countA2);
//        if (countA2 <= data.A2.size() && countA2 >= 7) {
//            System.out.println("It's A2");
//        }
//    }
//
//    public static void isAA2(ArrayList<Integer> index) {
//
//        int countAA2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 11) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.AA2.size(); j++) {
//                    if (index.get(i - 1).equals(data.AA2.get(j))) {
//                        countAA2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.AA2.get(j))) {
//                            countAA2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countAA2: " + countAA2);
//        if (countAA2 <= data.AA2.size() && countAA2 >= 7) {
//            System.out.println("It's AA2");
//        }
//    }
//
//    public static void isB2(ArrayList<Integer> index) {
//
//        int countB2 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 11) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.B2.size(); j++) {
//                    if (index.get(i - 1).equals(data.B2.get(j))) {
//                        countB2++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.B2.get(j))) {
//                            countB2++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countB2: " + countB2);
//        if (countB2 <= data.B2.size() && countB2 >= 7) {
//            System.out.println("It's B2");
//        }
//    }
//
//    //
//    public static void isC3(ArrayList<Integer> index) {
//
//        int countC3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 12) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.C3.size(); j++) {
//                    if (index.get(i - 1).equals(data.C3.get(j))) {
//                        countC3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.C3.get(j))) {
//                            countC3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countC3: " + countC3);
//        if (countC3 <= data.C3.size() && countC3 >= 7) {
//            System.out.println("It's C3");
//        }
//    }
//
//    public static void isCC3(ArrayList<Integer> index) {
//
//        int countCC3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 11) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.CC3.size(); j++) {
//                    if (index.get(i - 1).equals(data.CC3.get(j))) {
//                        countCC3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.CC3.get(j))) {
//                            countCC3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countCC3: " + countCC3);
//        if (countCC3 <= data.CC3.size() && countCC3 >= 7) {
//            System.out.println("It's CC3");
//        }
//    }
//
//    public static void isD3(ArrayList<Integer> index) {
//
//        int countD3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 13) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.D3.size(); j++) {
//                    if (index.get(i - 1).equals(data.D3.get(j))) {
//                        countD3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.D3.get(j))) {
//                            countD3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countD3: " + countD3);
//        if (countD3 <= data.D3.size() && countD3 >= 6) {
//            System.out.println("It's D3");
//        }
//    }
//
//    public static void isDD3(ArrayList<Integer> index) {
//
//        int countDD3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 14) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.DD3.size(); j++) {
//                    if (index.get(i - 1).equals(data.DD3.get(j))) {
//                        countDD3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.DD3.get(j))) {
//                            countDD3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countDD3: " + countDD3);
//        if (countDD3 <= data.DD3.size() && countDD3 >= 5) {
//            System.out.println("It's DD3");
//        }
//    }
//
//    public static void isE3(ArrayList<Integer> index) {
//
//        int countE3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 15) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.E3.size(); j++) {
//                    if (index.get(i - 1).equals(data.E3.get(j))) {
//                        countE3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.E3.get(j))) {
//                            countE3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countE3: " + countE3);
//        if (countE3 <= data.E3.size() && countE3 >= 5) {
//            System.out.println("It's E3");
//        }
//    }
//
//    public static void isF3(ArrayList<Integer> index) {
//
//        int countF3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 16) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.F3.size(); j++) {
//                    if (index.get(i - 1).equals(data.F3.get(j))) {
//                        countF3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.F3.get(j))) {
//                            countF3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countF3: " + countF3);
//        if (countF3 <= data.F3.size() && countF3 >= 5) {
//            System.out.println("It's F3");
//        }
//    }
//
//    public static void isFF3(ArrayList<Integer> index) {
//
//        int countFF3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 17) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.FF3.size(); j++) {
//                    if (index.get(i - 1).equals(data.FF3.get(j))) {
//                        countFF3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.FF3.get(j))) {
//                            countFF3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countFF3: " + countFF3);
//        if (countFF3 <= data.FF3.size() && countFF3 >= 5) {
//            System.out.println("It's FF3");
//        }
//    }
//
//    public static void isG3(ArrayList<Integer> index) {
//
//        int countG3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 18) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.G3.size(); j++) {
//                    if (index.get(i - 1).equals(data.G3.get(j))) {
//                        countG3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.G3.get(j))) {
//                            countG3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countG3: " + countG3);
//        if (countG3 <= data.G3.size() && countG3 >= 5) {
//            System.out.println("It's G3");
//        }
//    }
//
//    public static void isGG3(ArrayList<Integer> index) {
//
//        int countGG3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 11) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.GG3.size(); j++) {
//                    if (index.get(i - 1).equals(data.GG3.get(j))) {
//                        countGG3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.GG3.get(j))) {
//                            countGG3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countGG3: " + countGG3);
//        if (countGG3 <= data.GG3.size() && countGG3 >= 4) {
//            System.out.println("It's GG3");
//        }
//    }
//
//    public static void isA3(ArrayList<Integer> index) {
//
//        int countA3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 11) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.A3.size(); j++) {
//                    if (index.get(i - 1).equals(data.A3.get(j))) {
//                        countA3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.A3.get(j))) {
//                            countA3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countA3: " + countA3);
//        if (countA3 <= data.A3.size() && countA3 >= 5) {
//            System.out.println("It's A3");
//        }
//    }
//
//    public static void isAA3(ArrayList<Integer> index) {
//
//        int countAA3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.AA3.size(); j++) {
//                    if (index.get(i - 1).equals(data.AA3.get(j))) {
//                        countAA3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.AA3.get(j))) {
//                            countAA3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countAA3: " + countAA3);
//        if (countAA3 <= data.AA3.size() && countAA3 >= 11) {
//            System.out.println("It's AA3");
//        }
//    }
//
//    public static void isB3(ArrayList<Integer> index) {
//
//        int countB3 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.B3.size(); j++) {
//                    if (index.get(i - 1).equals(data.B3.get(j))) {
//                        countB3++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.B3.get(j))) {
//                            countB3++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countB3: " + countB3);
//        if (countB3 <= data.B3.size() && countB3 >= 12) {
//            System.out.println("It's B3");
//        }
//    }
//
//    //中央Do
//    public static void isC4(ArrayList<Integer> index) {
//
//        int countC4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.C4.size(); j++) {
//                    if (index.get(i - 1).equals(data.C4.get(j))) {
//                        countC4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.C4.get(j))) {
//                            countC4++;
//                        }
//                    }
//                } 
//            }
//        }
////        System.out.println("countC4: " + countC4);
//        if (countC4 <= data.C4.size() && countC4 >= 10) {
//            System.out.println("It's C4");
//        }
//    }
//
//    public static void isCC4(ArrayList<Integer> index) {
//
//        int countCC4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 11) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.CC4.size(); j++) {
//                    if (index.get(i - 1).equals(data.CC4.get(j))) {
//                        countCC4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.CC4.get(j))) {
//                            countCC4++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countCC4: " + countCC4);
//        if (countCC4 <= data.CC4.size() && countCC4 >= 11) {
//            System.out.println("It's CC4");
//        }
//    }
//
//    public static void isD4(ArrayList<Integer> index) {
//
//        int countD4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 12) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.D4.size(); j++) {
//                    if (index.get(i - 1).equals(data.D4.get(j))) {
//                        countD4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.D4.get(j))) {
//                            countD4++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countD4: " + countD4);
//        if (countD4 <= data.D4.size() && countD4 >= 11) {
//            System.out.println("It's D4");
//        }
//    }
//
//    public static void isDD4(ArrayList<Integer> index) {
//
//        int countDD4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 14) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.DD4.size(); j++) {
//                    if (index.get(i - 1).equals(data.DD4.get(j))) {
//                        countDD4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.DD4.get(j))) {
//                            countDD4++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countDD4: " + countDD4);
//        if (countDD4 <= data.DD4.size() && countDD4 >= 12) {
//            System.out.println("It's DD4");
//        }
//    }
//
//    public static void isE4(ArrayList<Integer> index) {
//
//        int countE4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 15) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.E4.size(); j++) {
//                    if (index.get(i - 1).equals(data.E4.get(j))) {
//                        countE4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.E4.get(j))) {
//                            countE4++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countE4: " + countE4);
//        if (countE4 <= data.E4.size() && countE4 >= 10) {
//            System.out.println("It's E4");
//        }
//    }
//
//    public static void isF4(ArrayList<Integer> index) {
//
//        int countF4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 16) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.F4.size(); j++) {
//                    if (index.get(i - 1).equals(data.F4.get(j))) {
//                        countF4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.F4.get(j))) {
//                            countF4++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countF4: " + countF4);
//        if (countF4 <= data.F4.size() && countF4 >= 10) {
//            System.out.println("It's F4");
//        }
//    }
//
//    public static void isFF4(ArrayList<Integer> index) {
//
//        int countFF4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 17) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.FF4.size(); j++) {
//                    if (index.get(i - 1).equals(data.FF4.get(j))) {
//                        countFF4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.FF4.get(j))) {
//                            countFF4++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countFF4: " + countFF4);
//        if (countFF4 <= data.FF4.size() && countFF4 >= 10) {
//            System.out.println("It's FF4");
//        }
//    }
//
//    public static void isG4(ArrayList<Integer> index) {
//
//        int countG4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 18) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.G4.size(); j++) {
//                    if (index.get(i - 1).equals(data.G4.get(j))) {
//                        countG4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.G4.get(j))) {
//                            countG4++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countG4: " + countG4);
//        if (countG4 <= data.G4.size() && countG4 >= 10) {
//            System.out.println("It's G4");
//        }
//    }
//
//    public static void isGG4(ArrayList<Integer> index) {
//
//        int countGG4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 19) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.GG4.size(); j++) {
//                    if (index.get(i - 1).equals(data.GG4.get(j))) {
//                        countGG4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.GG4.get(j))) {
//                            countGG4++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countGG4: " + countGG4);
//        if (countGG4 <= data.GG4.size() && countGG4 >= 7) {
//            System.out.println("It's GG4");
//        }
//    }
//
//    public static void isA4(ArrayList<Integer> index) {
//
//        int countA4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 20) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.A4.size(); j++) {
//                    if (index.get(i - 1).equals(data.A4.get(j))) {
//                        countA4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.A4.get(j))) {
//                            countA4++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countA4: " + countA4);
//        if (countA4 <= data.A4.size() && countA4 >= 5) {
//            System.out.println("It's A4");
//        }
//    }
//
//    public static void isAA4(ArrayList<Integer> index) {
//
//        int countAA4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 21) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.AA4.size(); j++) {
//                    if (index.get(i - 1).equals(data.AA4.get(j))) {
//                        countAA4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.AA4.get(j))) {
//                            countAA4++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countAA4: " + countAA4);
//        if (countAA4 <= data.AA4.size() && countAA4 >= 7) {
//            System.out.println("It's AA4");
//        }
//    }
//
//    public static void isB4(ArrayList<Integer> index) {
//
//        int countB4 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 23) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.B4.size(); j++) {
//                    if (index.get(i - 1).equals(data.B4.get(j))) {
//                        countB4++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.B4.get(j))) {
//                            countB4++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countB4: " + countB4);
//        if (countB4 <= data.B4.size() && countB4 >= 7) {
//            System.out.println("It's B4");
//        }
//    }
//
//    public static void isC5(ArrayList<Integer> index) {
//
//        int countC5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 23) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.C5.size(); j++) {
//                    if (index.get(i - 1).equals(data.C5.get(j))) {
//                        countC5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.C5.get(j))) {
//                            countC5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countC5: " + countC5);
//        if (countC5 <= data.C5.size() && countC5 >= 6) {
//            System.out.println("It's C5");
//        }
//    }
//
//    public static void isCC5(ArrayList<Integer> index) {
//
//        int countCC5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 26) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.CC5.size(); j++) {
//                    if (index.get(i - 1).equals(data.CC5.get(j))) {
//                        countCC5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.CC5.get(j))) {
//                            countCC5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countCC5: " + countCC5);
//        if (countCC5 <= data.CC5.size() && countCC5 >= 7) {
//            System.out.println("It's CC5");
//        }
//    }
//
//    public static void isD5(ArrayList<Integer> index) {
//
//        int countD5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 27) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.D5.size(); j++) {
//                    if (index.get(i - 1).equals(data.D5.get(j))) {
//                        countD5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.D5.get(j))) {
//                            countD5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countD5: " + countD5);
//        if (countD5 <= data.D5.size() && countD5 >= 7) {
//            System.out.println("It's D5");
//        }
//    }
//
//    public static void isDD5(ArrayList<Integer> index) {
//
//        int countDD5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 29) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.DD5.size(); j++) {
//                    if (index.get(i - 1).equals(data.DD5.get(j))) {
//                        countDD5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.DD5.get(j))) {
//                            countDD5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countDD5: " + countDD5);
//        if (countDD5 <= data.DD5.size() && countDD5 >= 6) {
//            System.out.println("It's DD5");
//        }
//    }
//
//    public static void isE5(ArrayList<Integer> index) {
//
//        int countE5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 30) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.E5.size(); j++) {
//                    if (index.get(i - 1).equals(data.E5.get(j))) {
//                        countE5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.E5.get(j))) {
//                            countE5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countE5: " + countE5);
//        if (countE5 <= data.E5.size() && countE5 >= 5) {
//            System.out.println("It's E5");
//        }
//    }
//
//    public static void isF5(ArrayList<Integer> index) {
//
//        int countF5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 32) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.F5.size(); j++) {
//                    if (index.get(i - 1).equals(data.F5.get(j))) {
//                        countF5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.F5.get(j))) {
//                            countF5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countF5: " + countF5);
//        if (countF5 <= data.F5.size() && countF5 >= 5) {
//            System.out.println("It's F5");
//        }
//    }
//
//    public static void isFF5(ArrayList<Integer> index) {
//
//        int countFF5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 34) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.FF5.size(); j++) {
//                    if (index.get(i - 1).equals(data.FF5.get(j))) {
//                        countFF5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.FF5.get(j))) {
//                            countFF5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countFF5: " + countFF5);
//        if (countFF5 <= data.FF5.size() && countFF5 >= 5) {
//            System.out.println("It's FF5");
//        }
//    }
//
//    public static void isG5(ArrayList<Integer> index) {
//
//        int countG5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 36) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.G5.size(); j++) {
//                    if (index.get(i - 1).equals(data.G5.get(j))) {
//                        countG5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.G5.get(j))) {
//                            countG5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countG5: " + countG5);
//        if (countG5 <= data.G5.size() && countG5 >= 4) {
//            System.out.println("It's G5");
//        }
//    }
//
//    public static void isGG5(ArrayList<Integer> index) {
//
//        int countGG5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 39) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.GG5.size(); j++) {
//                    if (index.get(i - 1).equals(data.GG5.get(j))) {
//                        countGG5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.GG5.get(j))) {
//                            countGG5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countGG5: " + countGG5);
//        if (countGG5 <= data.GG5.size() && countGG5 >= 4) {
//            System.out.println("It's GG5");
//        }
//    }
//
//    public static void isA5(ArrayList<Integer> index) {
//
//        int countA5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 41) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.A5.size(); j++) {
//                    if (index.get(i - 1).equals(data.A5.get(j))) {
//                        countA5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.A5.get(j))) {
//                            countA5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countA5: " + countA5);
//        if (countA5 <= data.A5.size() && countA5 >= 4) {
//            System.out.println("It's A5");
//        }
//    }
//
//    public static void isAA5(ArrayList<Integer> index) {
//
//        int countAA5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 43) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.AA5.size(); j++) {
//                    if (index.get(i - 1).equals(data.AA5.get(j))) {
//                        countAA5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.AA5.get(j))) {
//                            countAA5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countAA5: " + countAA5);
//        if (countAA5 <= data.AA5.size() && countAA5 >= 4) {
//            System.out.println("It's AA5");
//        }
//    }
//
//    public static void isB5(ArrayList<Integer> index) {
//
//        int countB5 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 46) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.B5.size(); j++) {
//                    if (index.get(i - 1).equals(data.B5.get(j))) {
//                        countB5++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.B5.get(j))) {
//                            countB5++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countB5: " + countB5);
//        if (countB5 <= data.B5.size() && countB5 >= 3) {
//            System.out.println("It's B5");
//        }
//    }
//
//    public static void isC6(ArrayList<Integer> index) {
//
//        int countC6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 49) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.C6.size(); j++) {
//                    if (index.get(i - 1).equals(data.C6.get(j))) {
//                        countC6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.C6.get(j))) {
//                            countC6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countC6: " + countC6);
//        if (countC6 <= data.C6.size() && countC6 >= 3) {
//            System.out.println("It's C6");
//        }
//    }
//
//    public static void isCC6(ArrayList<Integer> index) {
//
//        int countCC6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 51) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.CC6.size(); j++) {
//                    if (index.get(i - 1).equals(data.CC6.get(j))) {
//                        countCC6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.CC6.get(j))) {
//                            countCC6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countCC6: " + countCC6);
//        if (countCC6 <= data.CC6.size() && countCC6 >= 3) {
//            System.out.println("It's CC6");
//        }
//    }
//
//    public static void isD6(ArrayList<Integer> index) {
//
//        int countD6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 55) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.D6.size(); j++) {
//                    if (index.get(i - 1).equals(data.D6.get(j))) {
//                        countD6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.D6.get(j))) {
//                            countD6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countD6: " + countD6);
//        if (countD6 <= data.D6.size() && countD6 >= 3) {
//            System.out.println("It's D6");
//        }
//    }
//
//    public static void isDD6(ArrayList<Integer> index) {
//
//        int countDD6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 58) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.DD6.size(); j++) {
//                    if (index.get(i - 1).equals(data.DD6.get(j))) {
//                        countDD6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.DD6.get(j))) {
//                            countDD6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countDD6: " + countDD6);
//        if (countDD6 <= data.DD6.size() && countDD6 >= 3) {
//            System.out.println("It's DD6");
//        }
//    }
//
//    public static void isE6(ArrayList<Integer> index) {
//
//        int countE6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 62) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.E6.size(); j++) {
//                    if (index.get(i - 1).equals(data.E6.get(j))) {
//                        countE6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.E6.get(j))) {
//                            countE6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countE6: " + countE6);
//        if (countE6 <= data.E6.size() && countE6 >= 3) {
//            System.out.println("It's E6");
//        }
//    }
//
//    public static void isF6(ArrayList<Integer> index) {
//
//        int countF6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 65) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.F6.size(); j++) {
//                    if (index.get(i - 1).equals(data.F6.get(j))) {
//                        countF6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.F6.get(j))) {
//                            countF6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countF6: " + countF6);
//        if (countF6 <= data.F6.size() && countF6 >= 2) {
//            System.out.println("It's F6");
//        }
//    }
//
//    public static void isFF6(ArrayList<Integer> index) {
//
//        int countFF6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 69) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.FF5.size(); j++) {
//                    if (index.get(i - 1).equals(data.FF5.get(j))) {
//                        countFF6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.FF5.get(j))) {
//                            countFF6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countFF6: " + countFF6);
//        if (countFF6 <= data.FF5.size() && countFF6 >= 3) {
//            System.out.println("It's FF6");
//        }
//    }
//
//    public static void isG6(ArrayList<Integer> index) {
//
//        int countG6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 74) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.G6.size(); j++) {
//                    if (index.get(i - 1).equals(data.G6.get(j))) {
//                        countG6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.G6.get(j))) {
//                            countG6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countG6: " + countG6);
//        if (countG6 <= data.G6.size() && countG6 >= 2) {
//            System.out.println("It's G6");
//        }
//    }
//
//    public static void isGG6(ArrayList<Integer> index) {
//
//        int countGG6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 78) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.GG6.size(); j++) {
//                    if (index.get(i - 1).equals(data.GG6.get(j))) {
//                        countGG6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.GG6.get(j))) {
//                            countGG6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countGG6: " + countGG6);
//        if (countGG6 <= data.GG6.size() && countGG6 >= 2) {
//            System.out.println("It's GG6");
//        }
//    }
//
//    public static void isA6(ArrayList<Integer> index) {
//
//        int countA6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 84) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.A6.size(); j++) {
//                    if (index.get(i - 1).equals(data.A6.get(j))) {
//                        countA6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.A6.get(j))) {
//                            countA6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countA6: " + countA6);
//        if (countA6 <= data.A6.size() && countA6 >= 2) {
//            System.out.println("It's A6");
//        }
//    }
//
//    public static void isAA6(ArrayList<Integer> index) {
//
//        int countAA6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 87) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.AA6.size(); j++) {
//                    if (index.get(i - 1).equals(data.AA6.get(j))) {
//                        countAA6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.AA6.get(j))) {
//                            countAA6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countAA6: " + countAA6);
//        if (countAA6 <= data.AA6.size() && countAA6 >= 2) {
//            System.out.println("It's AA6");
//        }
//    }
//
//    public static void isB6(ArrayList<Integer> index) {
//
//        int countB6 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 95) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.B6.size(); j++) {
//                    if (index.get(i - 1).equals(data.B6.get(j))) {
//                        countB6++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.B6.get(j))) {
//                            countB6++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countB6: " + countB6);
//        if (countB6 >= data.B6.size()) {
//            System.out.println("It's B6");
//        }
//    }
//
//    public static void isC7(ArrayList<Integer> index) {
//
//        int countC7 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 97) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.C7.size(); j++) {
//                    if (index.get(i - 1).equals(data.C7.get(j))) {
//                        countC7++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.C7.get(j))) {
//                            countC7++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countC7: " + countC7);
//        if (countC7 <= data.C7.size() && countC7 >= 1) {
//            System.out.println("It's C7");
//        }
//    }
//
//    public static void isCC7(ArrayList<Integer> index) {
//
//        int countCC7 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 103) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.CC7.size(); j++) {
//                    if (index.get(i - 1).equals(data.CC7.get(j))) {
//                        countCC7++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.CC7.get(j))) {
//                            countCC7++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countCC7: " + countCC7);
//        if (countCC7 <= data.CC7.size() && countCC7 >= 1) {
//            System.out.println("It's CC7");
//        }
//    }
//
//    public static void isD7(ArrayList<Integer> index) {
//
//        int countD7 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 109) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.D7.size(); j++) {
//                    if (index.get(i - 1).equals(data.D7.get(j))) {
//                        countD7++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.D7.get(j))) {
//                            countD7++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countCC7: " + countCC7);
//        if (countD7 <= data.D7.size() && countD7 >= 1) {
//            System.out.println("It's D7");
//        }
//    }
//
//    public static void isDD7(ArrayList<Integer> index) {
//
//        int countDD7 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 116) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.DD7.size(); j++) {
//                    if (index.get(i - 1).equals(data.DD7.get(j))) {
//                        countDD7++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.DD7.get(j))) {
//                            countDD7++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countDD7: " + countDD7);
//        if (countDD7 <= data.DD7.size() && countDD7 >= 1) {
//            System.out.println("It's DD7");
//        }
//    }
//
//    public static void isE7(ArrayList<Integer> index) {
//
//        int countE7 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 123) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.E7.size(); j++) {
//                    if (index.get(i - 1).equals(data.E7.get(j))) {
//                        countE7++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.E7.get(j))) {
//                            countE7++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countE7: " + countE7);
//        if (countE7 <= data.E7.size() && countE7 >= 1) {
//            System.out.println("It's E7");
//        }
//    }
//
//    public static void isF7(ArrayList<Integer> index) {
//
//        int countF7 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 132) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.F7.size(); j++) {
//                    if (index.get(i - 1).equals(data.F7.get(j))) {
//                        countF7++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.F7.get(j))) {
//                            countF7++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countF7: " + countF7);
//        if (countF7 >= 1) {
//            System.out.println("It's F7");
//        }
//    }
//
//    public static void isFF7(ArrayList<Integer> index) {
//
//        int countFF7 = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 138) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.FF7.size(); j++) {
//                    if (index.get(i - 1).equals(data.FF7.get(j))) {
//                        countFF7++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.FF7.get(j))) {
//                            countFF7++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countFF7: " + countFF7);
//        if (countFF7 >= 1) {
//            System.out.println("It's FF7");
//        }
//    }
//
//    //和弦辨識
//    public static void isCEG(ArrayList<Integer> index) {
//
//        int countCEG = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.CEG.size(); j++) {
//                    if (index.get(i - 1).equals(data.CEG.get(j))) {
//                        countCEG++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.CEG.get(j))) {
//                            countCEG++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countCEG: " + countCEG);
//        if (countCEG <= data.CEG.size() && countCEG >= 9) {
//            System.out.println("It's 135");
//        }
//    }
//
//    public static void isBFG(ArrayList<Integer> index) {
//
//        int countBFG = 0;  // 計算有幾筆資料符合
//        boolean isGreaterThan = true;
//
//        for (int i = 1; i < index.size(); i++) {
//            if (Math.abs(index.get(i) - index.get(i - 1)) < 10) {
//                isGreaterThan = false;
//                break;
//            }
//            if (isGreaterThan) {
//                for (int j = 0; j < data.BFG.size(); j++) {
//                    if (index.get(i - 1).equals(data.BFG.get(j))) {
//                        countBFG++;
//                    }
//                    if (i == (index.size() - 1)) {
//                        if (index.get(i).equals(data.BFG.get(j))) {
//                            countBFG++;
//                        }
//                    }
//                }
//            }
//        }
////        System.out.println("countBFG: " + countBFG);
//        if (countBFG <= data.BFG.size() && countBFG >= 8) {
//            System.out.println("It's 745");
//        }
//    }
//    //和弦辨識End
//
//    public static void main(String[] args) {
//
//    }
//
//}


//  public void findPeak(double sound[]) {
//
//        max = 0; // maxList的最大值
//        min_value = 1000;   // 最低峰值
//        max_value = 0;   // 最高峰值
//        avg = 0.0;
//        maxList = new ArrayList();
//        indexList = new ArrayList();
//        tempList = new ArrayList();
//        //        long startTime = System.currentTimeMillis();    // 獲取開始時間
//        // 找波峰的極大值
//        slowSum = 0.0;
//        for (int i = 0; i < FFTNo; i++) {
//            //p1[i] = p1[i] * 0.4 + sound[i] * 0.6;
//            //p2[i] = p2[i] * 0.95 + sound[i] * 0.05;
//            //slow[i] = Math.abs(p1[i] - p2[i]);
//            slow[i] = slow[i] * 0.3 + sound[i] * 0.7;
//            slowSum += slow[i];
//        }
//        if (longSum == 0.0) {
//            longSum = slowSum;
//        } else {
//            longSum = longSum * 0.999 + slowSum * 0.001;
//        }
//        if ((slowSum / longSum) < 1.3) {
//            return;
//        }
//        for (int i = now; i <= sample; i++) {
//            if (slow[i] < min_value) {
//                min_value = slow[i];
//            } else if (slow[i] > max_value) {
//                max_value = slow[i];
//                if (isMax_value(i, max_value, slow)) {
//                    double maxLog = Math.log10(max_value);  // 訊號以10為底取log，單位是分貝 (dB)
//                    DecimalFormat df = new DecimalFormat("##.00000"); // 四捨五入取到小數點第三位
//                    maxLog = Double.parseDouble(df.format(maxLog));
//                    maxList.add(maxLog);
//                    indexList.add(i);
//                    tempList.add(maxLog);
//                    Collections.sort(tempList);
////                    if (count % 20 == 0) {
////                    System.out.printf("TRUE! sample index: %d, Max_value: %.5f \r\n", i, maxLog);
////                    }
//                    i = i + interval;
//                    max_value = slow[i];
//                }
//            }
//        }
//
//        //中位數過濾雜音
//        int size = tempList.size();
//        double mid = 0; //中位數
//        //如果是奇數的話
//        if (size % 2 != 0) {
//            mid = tempList.get((size - 1) / 2);
//        } else if (size % 2 == 0) {    //如果是偶數的話
//            //加0.0把int轉成double型別，否則除以2會算錯
//            mid = (tempList.get(size / 2 - 1) + tempList.get(size / 2) + 0.0) / 2;
//        }
//
//        System.out.println("mid: " + mid);
//
//        //過濾中位數以下
//        for (int i = 0; i < indexList.size(); i++) {
//            if (maxList.get(i) < (mid / 1.08)) {
//                maxList.remove(i);
//                indexList.remove(i);
//                i -= 1;
//            }
//        }
//
////        System.out.printf("Result index: %s \r\n", indexList);
//        int[] peaks = new int[FFTNo];
//        for (int i = 0; i < FFTNo; i++) {
//            peaks[i] = 0;
//        }
//        for (int idx : indexList) {
//            peaks[idx] = 1;
//        }
//        // pmain.traceFrame.pInsert(peaks);
//
//        list.offer(peaks);
//        while (list.size() > 6) {
//            list.poll();
//        }
//        for (int i = 0; i < FFTNo; i++) {
//            pSum[i] = 0;
//        }
//        for (int[] a : list) {
//            for (int i = 0; i < FFTNo; i++) {
//                pSum[i] += a[i];
//            }
//        }
//        for (int i = 0; i < FFTNo; i++) {
//            if (pSum[i] >= 2) {
//                pSum[i] = 1;
//            } else {
//                pSum[i] = 0;
//            }
//        }
//        pmain.traceFrame.pInsert(pSum);
//
//        String res = "";
//
//        if (sampleCounter == 0) {
//            accumulator = new int[36];
//            for (int i = 0; i < 36; i++) {
//                accumulator[i] = 0;
//            }
//        }
//        sampleCounter++;
//        excludeSet.clear();
//        for (int i = 0; i < 36; i++) {
//            if (isLevel3(i)) {
//                res += name3[i] + " ";
//                accumulator[i]++;
//                for (int j = 0; j < 12; j++) {
//                    excludeSet.add(arr3[j][i]);
//                }
//            } else if (isLevel(i)) {
//                res += name[i] + " ";
//                accumulator[12 + i]++;
//            } else if (isLevel5(i)) {
//                res += name5[i] + " ";
//                accumulator[24 + i]++;
//            }
//        }
//        if (sampleCounter >= 5) {
//            for (int i = 0; i < 36; i++) {
//                if (accumulator[i] > 1) {   ////  -----------------------
//                    accumulator[i] = 1;
//                } else {
//                    accumulator[i] = 0;
//                }
//            }
//            fiveFinal.offer(accumulator);
//            while (fiveFinal.size() > 5) {
//                fiveFinal.poll();
//            }
//            if (musicState == 0) {
//                if (fiveFinal.size() >= 5) {
//                    int[] tempVec = new int[36];
//                    for (int i = 0; i < 36; i++) {
//                        tempVec[i] = 0;
//                    }
//                    for (int[] vec : fiveFinal) {
//                        for (int i = 0; i < 36; i++) {
//                            tempVec[i] += vec[i];
//                        }
//                    }
//                    for (int i = 0; i < 36; i++) {
//                        if (tempVec[i] > 1) {  // -------------------------------
//                            tempVec[i] = 1;
//                        } else {
//                            tempVec[i] = 0;
//                        }
//                    }
//                    boolean hasVoice = false;
//                    for (int i = 0; i < 36; i++) {
//                        if (tempVec[i] > 0) {
//                            hasVoice = true;
//                            break;
//                        }
//                    }
//                    if (hasVoice) {
//                        show("cclo: There is voice detected!");
//                        musicTimer = new Timer();
//                        musicTimer.schedule(new NewClass.MusicTask(), 750);
//                        silentTimer.cancel();
//                        silentTimer.purge();
//                        // write levels to file
//                        for (int i = 0; i < 36; i++) {
//                            if (tempVec[i] > 0) {
//                                try {
//                                    writer.append(i + " ");
//                                } catch (IOException e) {
//                                    e.printStackTrace();
//                                }
//                            }
//                        }
//                        try {
//                            writer.append("-1\r\n");
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//
//                        // white -1 to file
//                        show("cclo: hasVoice, musicState change to 1");
//                        musicState = 1;
//                        // musicTimer.schedule(musicTask, 750);
//                    }
//                }
//            }
//            sampleCounter = 0;
//        }
//
//        pmain.showMsg(res);
//
//    }

import static cclo.Share.FFTNo;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Timer;
import project.NewClass;

