/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import cclo.DiscreteFourierTransform;
import cclo.*;
//import edu.cmu.sphinx.util.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

public class NewClass implements Share {

    static int count = 0;  //計算偵測筆數
    Main pmain;
    double slow[] = new double[FFTNo];
    double db[] = new double[FFTNo];
    double llong[] = new double[FFTNo];
    double dbSum = 0.0, longSum = 0.0;

    int now = 0;    // 當前位置從第五個開始，前五個頻率不算

    String mix_name[] = {"Do3 Mi3 Sol3 ", "Si3 Fa Sol ", "Do Mi Sol ", "Mi Sol+ Si ", "Fa La Do5 "};

    String name[] = {
        "Do3", "Do3+", "Re3", "Re3+", "Mi3", "Fa3", "Fa3+", "Sol3", "Sol3+", "La3", "La3+", "Si3",
        "Do", "Do+", "Re", "Re+", "Mi", "Fa", "Fa+", "Sol", "Sol+", "La", "La+", "Si",
        "Do5", "Do5+", "Re5", "Re5+", "Mi5", "Fa5", "Fa5+", "Sol5", "Sol5+", "La5", "La5+", "Si5", "Do6"};

    int[][] location = {
        {6, 12, 18, 24, 30, 37, 43, 48, 55, 61}, // 0 do
        {6, 13, 19, 26, 32, 38, 45, 52, 58, 65}, //  1 do^
        {7, 14, 21, 27, 34, 41, 48, 55, 62, 69}, // 2 re
        {7, 14, 22, 29, 37, 43, 51, 59, 65, 72}, // 3 re^
        {8, 15, 23, 30, 38, 46, 54, 62, 69, 77}, // 4 mi
        {8, 16, 24, 33, 41, 49, 58, 65, 74, 82}, // 5 fa
        {9, 17, 26, 34, 42, 51, 60, 69, 78, 87}, // 6 fa^
        {9, 18, 27, 36, 45, 54, 64, 74, 83, 91}, // 7 sol
        {10, 19, 29, 39, 48, 58, 68, 78, 87, 97}, // 8 sol^
        {10, 21, 31, 41, 50, 61, 71, 82, 93, 103}, // 9 la
        {11, 22, 32, 43, 53, 65, 76, 87, 98, 109}, // 10 la^
        {11, 23, 35, 46, 57, 68, 80, 92, 104, 116}, // 11 si
        {12, 24, 36, 49, 61, 73, 86, 98, 111, 123}, // 12 do
        {13, 26, 38, 52, 65, 78, 91, 104, 117, 130}, // 13 do^
        {14, 27, 41, 55, 68, 83, 96, 110, 124, 138}, // 14 re
        {14, 29, 43, 58, 72, 87, 102, 117, 131, 147}, // 15 re^
        {15, 31, 46, 61, 77, 92, 108, 124, 139, 155}, // 16 mi
        {16, 32, 49, 65, 81, 98, 114, 131, 147, 164}, // 17 fa
        {17, 34, 51, 69, 86, 104, 121, 139, 156, 174}, // 18 fa^
        {18, 36, 54, 73, 91, 110, 128, 147, 165, 185}, // 19 sol
        {19, 39, 58, 78, 97, 117, 137, 157, 177, 198}, // 20 sol^
        {20, 41, 62, 82, 103, 124, 145, 166, 188, 208}, // 21 la
        {22, 43, 65, 87, 109, 131, 153, 176, 199, 222}, // 22 la^
        {23, 46, 69, 92, 115, 139, 162, 186, 211, 235}, // 23 si
        {24, 49, 73, 98, 122, 147, 172, 199, 224, 250}, // 24 do
        {26, 52, 77, 104, 129, 156, 182, 209, 237, 264}, // 25 do^ 
        {27, 55, 82, 110, 137, 165, 193, 223, 251, 278}, // 26 re
        {29, 58, 87, 117, 148, 179, 212, 244, 278, 314}, // 27 re^
        {31, 61, 93, 124, 156, 184, 258, 294, 317, 31}, // 28 mi
        {32, 65, 99, 131, 165, 192, 298, 32, 65, 99}, // 29 fa
        {34, 69, 104, 139, 176, 212, 252, 34, 69, 104}, // 30 fa^
        {36, 73, 110, 147, 186, 226, 266, 36, 73, 110}, // 31 sol
        {38, 77, 115, 156, 199, 240, 199, 156, 115, 77}, // 32 sol^
        {41, 82, 123, 165, 209, 253, 209, 165, 123, 82}, // 33 la
        {43, 87, 132, 177, 43, 87, 132, 177, 43, 87}, // 34 la^
        {46, 93, 140, 188, 292, 46, 93, 140, 188, 292}, // 35 si
        {49, 98, 148, 199, 254, 49, 98, 148, 199, 254} // 36 do
    };

    int mix[][] = {
        {7, 12, 18, 24, 31, 37, 46, 55, 63, 83}, // Do3 Mi3 Sol3
        {11, 17, 23, 33, 55, 69, 82, 92, 131, 147}, // Si3 Fa4 Sol4
        {12, 18, 24, 31, 36, 61, 92, 98, 124, 147}, // Do4 Mi4 Sol4
        {19, 23, 31, 69, 77, 115, 124, 138, 187, 204}, // Mi Sol+ Si
        {16, 24, 32, 41, 73, 81, 98, 122, 131, 172} // Fa4 La4 Do5
    };

    int[][] mixLevel = {
        {0, 4, 7}, // Do3 Mi3 Sol3
        {11, 17, 19}, // Si3 Fa4 Sol4
        {12, 16, 19}, // Do4 Mi4 Sol4
        {16, 20, 23}, // Mi Sol+ Si
        {17, 21, 24} // Fa4 La4 Do5  
    };

    int mix_count = 0;

    double max = 0; // maxList的最大值
    double min_value = 1000;   // 最低峰值
    double max_value = 0;   // 最高峰值
    double avg = 0.0;
    ArrayList<Double> maxList = new ArrayList();
    ArrayList<Integer> indexList = new ArrayList();
    ArrayList<Double> tempList = new ArrayList();

    // ----------  cclo 9/24
    Queue<int[]> fiveFinal = new LinkedList<>();
    int sampleCounter = 0;
    int[] accumulator = new int[37];
    public int musicState = -1;
    //  0  : silent mode
    //  1  : music mode
    // -1  : stop

    boolean timeUp = false;

    Timer musicTimer;

    MaxIdentifier identifier = new MaxIdentifier();

    // Timer periodTimer = new Timer();
    public NewClass(Main main_) {
        pmain = main_;
        musicState = -1;
        show("\ncclo: Constructor: musicState = -1\n");

    }

    Queue<int[]> list = new LinkedList<>();
    int[] pSum = new int[FFTNo];

    HashSet<Integer> excludeSet = new HashSet<>();
    BufferedWriter writer;

    public void beginRec() {
        show("\ncclo: beginRec \n");
        musicState = 0;
        try {
        String basePath = new File("").getAbsolutePath();
            writer = new BufferedWriter(new FileWriter(basePath + "\\Result.txt", false));
        } catch (IOException e) {
            e.printStackTrace();
        }
        doSum();
    }

    public void stopRec() {
        try {
            writer.close();
            musicState = -1;
            show("\ncclo: stopRec: musicState = -1\n");
            musicTimer.cancel();
            musicTimer.purge();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    int voiceCnt = 0;

    public void findPeak(double sound[]) {

        max = 0; // maxList的最大值
        min_value = 1000;   // 最低峰值
        max_value = 0;   // 最高峰值
        avg = 0.0;
        maxList = new ArrayList();
        indexList = new ArrayList();
        tempList = new ArrayList();

        // 找波峰的極大值
        dbSum = 0.0;
        for (int i = 0; i < FFTNo; i++) {
            slow[i] = slow[i] * 0.2 + sound[i] * 0.8;
            db[i] = Math.log10(slow[i]);
            dbSum += db[i];
        }

        pmain.freqFr.updateSpec(db);

        if (longSum == 0.0) {
            longSum = dbSum;
        } else {
            longSum = longSum * 0.999 + dbSum * 0.001;
        }
        if ((dbSum / longSum) < 1.3) {
            voiceCnt = 0;
            return;
        }

        voiceCnt++;
        if (voiceCnt > 2 && musicState == 0) {
            show("\ncclo: Start musicTimer! \n");
            if (musicTimer != null) {
                musicTimer.cancel();
                musicTimer.purge();
            }
            musicTimer = new Timer();
            musicTimer.schedule(new MusicTask(), 750, 750);
            musicState = 1;
        }
        int[] peaks = new int[FFTNo];

        int interval = 0;
        for (int i = 6; i < 500; i++) {
            if (i < 50) {
                interval = 2;
            } else if (i < 100) {
                interval = 4;
            } else if (i < 150) {
                interval = 6;
            } else if (i < 200) {
                interval = 8;
            } else {
                interval = 10;
            }
            int min = i - interval;
            int max = i + interval;
            identifier.clear();
            for (int j = min; j <= max; j++) {
                identifier.add(db[j]);
            }
            if (identifier.isMax(db[i])) {
                peaks[i] = 1;
            } else {
                peaks[i] = 0;
            }
        }
        list.offer(peaks);
        while (list.size() > 7) {
            list.poll();
        }
        for (int i = 0; i < FFTNo; i++) {
            pSum[i] = 0;
        }
        for (int[] a : list) {
            for (int i = 0; i < FFTNo; i++) {
                pSum[i] += a[i];
            }
        }
        for (int i = 0; i < FFTNo; i++) {
            if (pSum[i] >= 4) {
                pSum[i] = 1;
            } else {
                pSum[i] = 0;
            }
        }
        pmain.traceFrame.pInsert(pSum);
        showPeaks(peaks);

        String res = "";
        excludeSet.clear();
        for (int i = 0; i < 5; i++) {
            if (isMix(i)) {
                for (int x : mixLevel[i]) {
                    res += name[x] + " ";
                    accumulator[x]++;
                    excludeSet.add(x);
                }
                switch (i) {
                    case 0:
                        excludeSet.add(0);
                        excludeSet.add(4);
                        excludeSet.add(7);
                        excludeSet.add(12);
                        excludeSet.add(16);
                        excludeSet.add(19);
//                        excludeSet.add(24);
//                        excludeSet.add(28);
//                        excludeSet.add(31);
//                        excludeSet.add(36);
                        break;
                    case 1:
                        excludeSet.add(23);
                        excludeSet.add(30);
//                        excludeSet.add(7);
//                        excludeSet.add(12);
//                        excludeSet.add(16);
//                        excludeSet.add(19);
//                        excludeSet.add(24);
//                        excludeSet.add(28);
//                        excludeSet.add(31);
//                        excludeSet.add(36);
                        break;
                    case 2:
                        excludeSet.add(0);
                        excludeSet.add(4);
                        excludeSet.add(7);
                        excludeSet.add(12);
                        excludeSet.add(16);
                        excludeSet.add(19);
                        excludeSet.add(24);
                        excludeSet.add(28);
                        excludeSet.add(31);
                        excludeSet.add(36);
                        break;
                    case 3:
                        excludeSet.add(4);
                        excludeSet.add(32);
                        excludeSet.add(35);
                        break;
                    case 4:
                        excludeSet.add(5);
                        excludeSet.add(9);
                        excludeSet.add(12);
                        break;
                }
                break;
            }
        }
        for (int i = 0; i < 37; i++) {
            if (isLevel(i)) {
                if (!excludeSet.contains(i)) {
                    res += name[i] + " ";
                    accumulator[i]++;
                }
                switch (i) {
                    case 0:
                        excludeSet.add(12);
                        excludeSet.add(16);
                        excludeSet.add(19);
                        excludeSet.add(24);
                        excludeSet.add(36);
                        excludeSet.add(34);
                        excludeSet.add(31);
                        break;
                    case 1:
                        excludeSet.add(13);
                        excludeSet.add(20);
                        excludeSet.add(25);
                        break;
                    case 2:
                        excludeSet.add(14);
                        excludeSet.add(14);
                        excludeSet.add(36);
                        break;
                    case 3:
                        excludeSet.add(15);
                        excludeSet.add(34);
                        break;
                    case 4:
                        excludeSet.add(16);
                        excludeSet.add(28);
                        break;
                    case 5:
                        excludeSet.add(17);
                        excludeSet.add(29);
                        break;
                    case 6:
                        excludeSet.add(18);
                        excludeSet.add(34);
                        break;
                    case 7:
                        excludeSet.add(19);
                        excludeSet.add(31);
                        excludeSet.add(35);
                        break;
                    case 8:
                        excludeSet.add(20);
                        excludeSet.add(27);
                        excludeSet.add(32);
                        excludeSet.add(36);
                        break;
                    case 9:
                        excludeSet.add(21);
                        excludeSet.add(28);
                        break;
                    case 10:
                        excludeSet.add(22);
                        excludeSet.add(29);
                        excludeSet.add(34);
                        break;
                    case 11:
                        excludeSet.add(23);
                        excludeSet.add(30);
                        excludeSet.add(35);
                        break;
                    case 12:
                        excludeSet.add(24);
                        excludeSet.add(34);
                        break;
                    case 13:
                        excludeSet.add(25);
                        excludeSet.add(32);
                        break;
                    case 14:
                        excludeSet.add(26);
                        excludeSet.add(18);
                        excludeSet.add(22);
                        break;
                    case 15:
                        excludeSet.add(27);
                        excludeSet.add(34);
                        break;
                    case 16:
                        excludeSet.add(28);
                        excludeSet.add(35);
                        break;
                    case 17:
                        excludeSet.add(29);
                        excludeSet.add(36);
                    case 18:
                        excludeSet.add(30);
                        excludeSet.add(34);
                        break;
                    case 19:
                        excludeSet.add(31);
                        break;
                    case 20:
                        excludeSet.add(32);
                        excludeSet.add(36);
                        break;
                    case 21:
                        excludeSet.add(33);
                        break;
                    case 22:
                        excludeSet.add(34);
                        break;
                    case 23:
                        excludeSet.add(35);
                        break;
                    case 24:
                        excludeSet.add(36);
                        break;
                }
            }
        }
        for (int i = 0; i < mix_name.length; i++) {
            if (res.equals(mix_name[i])) {
                mix_count = i + 37;
            }
        }
        pmain.showMsg(res);
    }

    public void doSum() {
        boolean hasVoice = false;
        int[] tempVec = new int[37];
        for (int i = 0; i < 37; i++) {
            if (accumulator[i] > 5) {
                tempVec[i] = 1;
            } else {
                tempVec[i] = 0;
            }
        }
        for (int i = 0; i < 37; i++) {
            if (tempVec[i] > 0) {
                hasVoice = true;
                break;
            }
        }
        if (hasVoice) {
            show("\ncclo: There is voice detected!\n");
            // write levels to file
            show("\n Voices are: ");
            int single = 0;
            for (int i = 0; i < 37; i++) {
                if (tempVec[i] > 0) {
                    try {
                        show(i + " ");
                        writer.append(i + " ");
                        single = i;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            if (mix_count < 37) {
                pmain.sheetFrame.add(single);
            } else if (mix_count > 36) {
                pmain.sheetFrame.add(mix_count);
            }
            mix_count = 0;
            show("\n");
            try {
                writer.append("-1\r\n");
                show("\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            musicState = 0;
            try {
                writer.append("-1\r\n");
                show("\n No voice, write -1 to line \n");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        for (int i = 0; i < 37; i++) {
            accumulator[i] = 0;
        }
    }

    public void showPeaks(int[] pks_) {
        for (int i = 0; i < 400; i++) {
            if (pks_[i] == 1) {
                show(i + ", ");
            }
        }
        show("\n");
    }

    public boolean isMix(int mIdx) {
        int cnt = 0;
        boolean res = false;
        int idx, min, max;
        for (int i = 0; i < 10; i++) {
            idx = mix[mIdx][i];
            if (idx <= 1) {
                min = 0;
                max = idx + 1;
            } else if (idx < 100) {
                min = idx - 1;
                max = idx + 1;
            } else {
                min = idx - 2;
                max = idx + 2;
            }
            for (int j = min; j <= max; j++) {
                if (pSum[j] > 0) {
                    cnt++;
                    break;
                }
            }
        }
        if (cnt > 8) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isLevel(int level_) {
        int cnt = 0;
        boolean res = false;
        int idx, min, max;
        for (int i = 0; i < 10; i++) {
            idx = location[level_][i];
            if (idx <= 1) {
                min = 0;
                max = idx + 1;
            } else if (idx < 100) {
                min = idx - 1;
                max = idx + 1;
            } else {
                min = idx - 2;
                max = idx + 2;
            }
            for (int j = min; j <= max; j++) {
                if (pSum[j] > 0) {
                    cnt++;
                    break;
                }
            }
        }
        if (cnt > 8) {
            return true;
        } else {
            return false;

        }
    }

    class SilentTask extends TimerTask {

        @Override
        public void run() {
            try {
                writer.append("-1\r\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
            show("\ncclo: silent task ended, new silentTimer started, musicState = 0\n");

        }
    }

    class MusicTask extends TimerTask {

        @Override
        public void run() {
            show("\ncclo: music task executed!\n");
            doSum();
        }
    }

    public void show(String str) {
        System.out.print(str);
    }

    class MaxIdentifier {

        ArrayList<Double> list = new ArrayList<>();

        public void clear() {
            list.clear();
        }

        public void add(double new_) {
            list.add(new_);
        }

        public boolean isMax(double x_) {
            for (double d : list) {
                if (d > x_) {
                    return false;
                }
            }
            return true;
        }
    }
}
