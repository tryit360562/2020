/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import cclo.DiscreteFourierTransform;
import cclo.*;
//import edu.cmu.sphinx.util.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

public class NewClass2 implements Share {

    static int count = 0;  //計算偵測筆數
    Main pmain;
    double slow[] = new double[1024];
    double llong[] = new double[FFTNo];
    double p2[] = new double[FFTNo];
    int vote = 6;
    double slowSum = 0.0, longSum = 0.0;

    int now = 0;    // 當前位置從第五個開始，前五個頻率不算
    int interval = 4;  // 取樣間隔為10
    int sample = 500;    // 設取樣點為256個
    int arr3[][] = {
        {18, 19, 14, 22, 15, 16, 17, 18, 19, 20, 22, 23},
        {24, 26, 20, 29, 23, 24, 35, 37, 29, 41, 33, 34},
        {31, 33, 27, 37, 31, 33, 44, 46, 39, 51, 44, 46},
        {44, 45, 34, 51, 38, 41, 60, 64, 49, 61, 55, 58},
        {49, 52, 48, 58, 46, 49, 78, 73, 58, 77, 65, 69},
        {55, 58, 55, 65, 54, 57, 87, 82, 68, 82, 76, 81},
        {61, 65, 62, 72, 62, 65, 95, 92, 78, 93, 87, 93},
        {73, 71, 69, 79, 69, 73, 104, 101, 88, 104, 98, 105},
        {80, 78, 76, 87, 77, 82, 113, 111, 98, 114, 110, 116},
        {93, 85, 83, 94, 85, 90, 123, 120, 108, 125, 121, 128},
        {99, 91, 90, 102, 93, 98, 130, 140, 118, 136, 132, 140,},
        {113, 98, 97, 110, 101, 106, 140, 149, 128, 145, 144, 153}};
    int arr4[][] = {
        {24, 26, 27, 29, 15, 16, 18, 18, 19, 20, 22, 23},
        {36, 39, 41, 44, 31, 32, 34, 28, 39, 41, 43, 32},
        {49, 52, 55, 58, 46, 49, 52, 36, 58, 62, 65, 46},
        {73, 65, 68, 73, 62, 65, 69, 55, 78, 82, 88, 69},
        {86, 78, 83, 88, 77, 82, 87, 73, 117, 103, 110, 93},
        {98, 91, 96, 102, 93, 99, 97, 92, 138, 124, 132, 116},
        {111, 105, 111, 110, 108, 115, 105, 111, 157, 146, 155, 140},
        {123, 118, 125, 125, 124, 132, 122, 117, 177, 168, 175, 165}};
    int arr5[][] = {
        {24, 26, 27, 29, 31, 33, 34, 36, 40, 42, 45, 46},
        {49, 52, 55, 58, 61, 65, 69, 73, 78, 82, 88, 92},
        {73, 78, 82, 88, 93, 98, 104, 148, 118, 166, 132, 139},
        {98, 104, 110, 117, 124, 132, 139, 186, 157, 209, 176, 186},
        {123, 130, 138, 148, 157, 166, 175, 226, 197, 253, 220, 235},
        {149, 155, 167, 178, 189, 200, 212, 268, 239, 300, 268, 284},
        {174, 212, 225, 242, 222, 235, 249, 309, 283, 342, 318, 332},
        {200, 241, 255, 275, 256, 272, 288, 333, 312, 386, 362, 380}};
    String name3[] = {"Do3", "Do3+", "Re3", "Re3+", "Mi3", "Fa3", "Fa3+", "Sol3", "Sol3+", "La3", "La3+", "Si3"};
    String name[] = {"Do", "Do+", "Re", "Re+", "Mi", "Fa", "Fa+", "Sol", "Sol+", "La", "La+", "Si"};
    String name5[] = {"Do5", "Do5+", "Re5", "Re5+", "Mi5", "Fa5", "Fa5+", "Sol5", "Sol5+", "La5", "La5+", "Si5"};
    double max = 0; // maxList的最大值
    double min_value = 1000;   // 最低峰值
    double max_value = 0;   // 最高峰值
    double avg = 0.0;
    ArrayList<Double> maxList = new ArrayList();
    ArrayList<Integer> indexList = new ArrayList();
    ArrayList<Double> tempList = new ArrayList();

    // ----------  cclo 9/24
    Queue<int[]> fiveFinal = new LinkedList<>();
    int sampleCounter = 0;
    int[] accumulator;
    public int musicState = -1;
    // 0 : silent mode
    // 1 : music mode
    // -1: stop

    boolean timeUp = false;

    TimerTask silentTask = new TimerTask() {
        // write -1 to file

        @Override
        public void run() {

            try {
                writer.append("-1\r\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
            silentTimer.cancel();
            silentTimer.purge();
            silentTimer = new Timer();
            silentTimer.schedule(silentTask, 750);
        }
    };

    TimerTask musicTask = new TimerTask() {

        @Override
        public void run() {

            musicState = 0;
            show("cclo: music task: musicState = 0");
            silentTimer.schedule(silentTask, 750);
        }
    };
    Timer musicTimer = new Timer();
    Timer silentTimer = new Timer();

    // Timer periodTimer = new Timer();
    public NewClass2(Main main_) {
        pmain = main_;
        musicState = -1;
        show("cclo: Constructor: musicState = -1");
    }

    Queue<int[]> list = new LinkedList<>();
    int[] pSum = new int[FFTNo];

    HashSet<Integer> excludeSet = new HashSet<>();
    BufferedWriter writer;

    public void beginRec() {
        silentTimer = new Timer();
        show("cclo: beginRec: musicState = 0");
        musicState = 0;
//        silentTimer.schedule(new SilentTask(), 750);
        try {
            writer = new BufferedWriter(new FileWriter("C:\\Han\\Work\\result.txt", false));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void stopRec() {
        try {
            writer.close();
            musicState = -1;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void findPeak(double sound[]) {

        max = 0; // maxList的最大值
        min_value = 1000;   // 最低峰值
        max_value = 0;   // 最高峰值
        avg = 0.0;
        maxList = new ArrayList();
        indexList = new ArrayList();
        tempList = new ArrayList();
        //        long startTime = System.currentTimeMillis();    // 獲取開始時間
        // 找波峰的極大值
        slowSum = 0.0;
        for (int i = 0; i < 1024; i++) {
            //p1[i] = p1[i] * 0.4 + sound[i] * 0.6;
            //p2[i] = p2[i] * 0.95 + sound[i] * 0.05;
            //slow[i] = Math.abs(p1[i] - p2[i]);
            slow[i] = slow[i] * 0.3 + sound[i] * 0.7;
            slowSum += slow[i];
        }
        if (longSum == 0.0) {
            longSum = slowSum;
        } else {
            longSum = longSum * 0.999 + slowSum * 0.001;
        }
        if ((slowSum / longSum) < 1.3) {
            return;
        }
        for (int i = now; i <= sample; i++) {
            if (slow[i] < min_value) {
                min_value = slow[i];
            } else if (slow[i] > max_value) {
                max_value = slow[i];
                if (isMax_value(i, max_value, slow)) {
                    double maxLog = Math.log10(max_value);  // 訊號以10為底取log，單位是分貝 (dB)
                    DecimalFormat df = new DecimalFormat("##.00000"); // 四捨五入取到小數點第三位
                    maxLog = Double.parseDouble(df.format(maxLog));
                    maxList.add(maxLog);
                    indexList.add(i);
                    tempList.add(maxLog);
                    Collections.sort(tempList);
//                    if (count % 20 == 0) {
//                    System.out.printf("TRUE! sample index: %d, Max_value: %.5f \r\n", i, maxLog);
//                    }
                    i = i + interval;
                    max_value = slow[i];
                }
            }
        }

        //中位數過濾雜音
        int size = tempList.size();
        double mid = 0; //中位數
        //如果是奇數的話
        if (size % 2 != 0) {
            mid = tempList.get((size - 1) / 2);
        } else if (size % 2 == 0) {    //如果是偶數的話
            //加0.0把int轉成double型別，否則除以2會算錯
            mid = (tempList.get(size / 2 - 1) + tempList.get(size / 2) + 0.0) / 2;
        }

        System.out.println("mid: " + mid);

        //過濾中位數以下
        for (int i = 0; i < indexList.size(); i++) {
            if (maxList.get(i) < (mid / 1.08)) {
                maxList.remove(i);
                indexList.remove(i);
                i -= 1;
            }
        }

//        System.out.printf("Result index: %s \r\n", indexList);
        int[] peaks = new int[FFTNo];
        for (int i = 0; i < FFTNo; i++) {
            peaks[i] = 0;
        }
        for (int idx : indexList) {
            peaks[idx] = 1;
        }
        // pmain.traceFrame.pInsert(peaks);

        list.offer(peaks);
        while (list.size() > 6) {
            list.poll();
        }
        for (int i = 0; i < FFTNo; i++) {
            pSum[i] = 0;
        }
        for (int[] a : list) {
            for (int i = 0; i < FFTNo; i++) {
                pSum[i] += a[i];
            }
        }
        for (int i = 0; i < FFTNo; i++) {
            if (pSum[i] >= 2) {
                pSum[i] = 1;
            } else {
                pSum[i] = 0;
            }
        }
        pmain.traceFrame.pInsert(pSum);

        String res = "";

        if (sampleCounter == 0) {
            accumulator = new int[36];
            for (int i = 0; i < 36; i++) {
                accumulator[i] = 0;
            }
        }
        sampleCounter++;
        excludeSet.clear();
        for (int i = 0; i < 12; i++) {
            if (isLevel3(i)) {
                res += name3[i] + " ";
                accumulator[i]++;
                for (int j = 0; j < 12; j++) {
                    excludeSet.add(arr3[j][i]);
                }
            } else if (isLevel(i)) {
                res += name[i] + " ";
                accumulator[12 + i]++;
            } else if (isLevel5(i)) {
                res += name5[i] + " ";
                accumulator[24 + i]++;
            }
        }
        if (sampleCounter >= 5) {
            for (int i = 0; i < 36; i++) {
                if (accumulator[i] > 1) {   ////  -----------------------
                    accumulator[i] = 1;
                } else {
                    accumulator[i] = 0;
                }
            }
            fiveFinal.offer(accumulator);
            while (fiveFinal.size() > 5) {
                fiveFinal.poll();
            }
            if (musicState == 0) {
                if (fiveFinal.size() >= 5) {
                    int[] tempVec = new int[36];
                    for (int i = 0; i < 36; i++) {
                        tempVec[i] = 0;
                    }
                    for (int[] vec : fiveFinal) {
                        for (int i = 0; i < 36; i++) {
                            tempVec[i] += vec[i];
                        }
                    }
                    for (int i = 0; i < 36; i++) {
                        if (tempVec[i] > 1) {  // -------------------------------
                            tempVec[i] = 1;
                        } else {
                            tempVec[i] = 0;
                        }
                    }
                    boolean hasVoice = false;
                    for (int i = 0; i < 36; i++) {
                        if (tempVec[i] > 0) {
                            hasVoice = true;
                            break;
                        }
                    }
                    if (hasVoice) {
                        show("cclo: There is voice detected!");
                        musicTimer = new Timer();
//                        musicTimer.schedule(new MusicTask(), 750);
                        silentTimer.cancel();
                        silentTimer.purge();
                        // write levels to file
                        for (int i = 0; i < 36; i++) {
                            if (tempVec[i] > 0) {
                                try {
                                    writer.append(i + " ");
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                        try {
                            writer.append("-1\r\n");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        // white -1 to file
                        show("cclo: hasVoice, musicState change to 1");
                        musicState = 1;
                        // musicTimer.schedule(musicTask, 750);
                    }
                }
            }
            sampleCounter = 0;
        }

        pmain.showMsg(res);

    }

    public boolean isLevel3(int level_) {
        boolean res = false;
        int idx, cnt = 0;
        for (int i = 0; i < 12; i++) {
            idx = arr3[i][level_];
            // if (pSum[idx - 2] > 0 || pSum[idx - 1] > 0 || pSum[idx] > 0 || pSum[idx + 1] > 0 || pSum[idx + 2] > 0) {
            if (pSum[idx - 1] > 0 || pSum[idx] > 0 || pSum[idx + 1] > 0) {
                cnt++;
            }
        }
        if (cnt > 6) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isLevel(int level_) {
        boolean res = false;
        int idx, cnt = 0, cnt2 = 0;
        for (int i = 0; i < 8; i++) {
            idx = arr4[i][level_];
            // if (pSum[idx - 2] > 0 || pSum[idx - 1] > 0 || pSum[idx] > 0 || pSum[idx + 1] > 0 || pSum[idx + 2] > 0) {
            if (pSum[idx - 1] > 0 || pSum[idx] > 0 || pSum[idx + 1] > 0) {
                if (excludeSet.contains(idx - 1) || excludeSet.contains(idx) || excludeSet.contains(idx + 1)) {
                } else {
                    cnt2++;
                }
                cnt++;
            }

        }
        if (cnt > 5 && cnt2 > 3) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isLevel5(int level_) {
        boolean res = false;
        int idx, cnt = 0, cnt2 = 0;
        for (int i = 0; i < 8; i++) {
            idx = arr5[i][level_];
            // if (pSum[idx - 2] > 0 || pSum[idx - 1] > 0 || pSum[idx] > 0 || pSum[idx + 1] > 0 || pSum[idx + 2] > 0) {
            if (pSum[idx - 1] > 0 || pSum[idx] > 0 || pSum[idx + 1] > 0) {
                if (excludeSet.contains(idx - 1) || excludeSet.contains(idx) || excludeSet.contains(idx + 1)) {
                } else {
                    cnt2++;
                }
                cnt++;
            }
        }
        if (cnt > 5 && cnt2 > 3) {
            return true;
        } else {
            return false;
        }
    }

    // 是否找到波峰
    public boolean isMax_value(int current, double currentMax, double sound[]) {
        boolean isMax = true;

        for (int i = current + 1; i <= current + 3; i++) // 先判斷右邊五個位置
        {
            if (sound[i] > currentMax) {
                isMax = false;
                break;
            }
        }

        if (isMax) // 右邊判斷完換判斷左邊，如果右邊已經找到另一個最大值，就不用再判斷了，因為抓得值並不是波峰的極大值
        {
            for (int i = current - 1; i >= current - 3; i--) {
                if (sound[i] > currentMax) {
                    isMax = false;
                    break;
                }
            }
        }
        return isMax;
    }

    public static void main(String[] args) {

    }

 

    public void show(String str) {
        System.out.println(str);
    }
}
