package com.THLight.USBeacon.Sample.ui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.THLight.USBeacon.Sample.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;

import androidx.annotation.NonNull;

public class Winstonghost extends Activity {
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.wistonghost);

        //firebase
        final FirebaseStorage storage = FirebaseStorage.getInstance();
        // Create a storage reference from our app
        //StorageReference storageRef = storage.getReference();

        Button RnP = (Button)findViewById(R.id.update);

        if(UIMain.winstonFlag == "ok"){
            Toast.makeText(Winstonghost.this, "prepare the door", Toast.LENGTH_SHORT).show();

            RnP.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EditText CarNum = (EditText)findViewById(R.id.edID);
                    String CarN = CarNum.getText().toString();
                    if(!CarN.matches("\\d+")){
                        Toast.makeText(Winstonghost.this, "Num fomat error", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    StorageReference storageRef = storage.getReference("log.txt");
                    UploadTask uploadTask = storageRef.putBytes(CarN.getBytes());
                    uploadTask.addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // Handle unsuccessful uploads
                            Toast.makeText(Winstonghost.this, "Car Num upload fail", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                            // ...
                            Toast.makeText(Winstonghost.this, "Car Num upload Success", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
        }
        //上傳ｄａｔａｂａｓｅ資訊　隨後開門
        //....

    }
}
