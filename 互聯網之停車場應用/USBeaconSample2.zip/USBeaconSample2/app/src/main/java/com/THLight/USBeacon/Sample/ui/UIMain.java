/** ============================================================== */
package com.THLight.USBeacon.Sample.ui;
/** ============================================================== */
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.THLight.USBeacon.App.Lib.BatteryPowerData;
import com.THLight.USBeacon.App.Lib.USBeaconConnection;
import com.THLight.USBeacon.App.Lib.USBeaconData;
import com.THLight.USBeacon.App.Lib.USBeaconList;
import com.THLight.USBeacon.App.Lib.USBeaconServerInfo;
import com.THLight.USBeacon.App.Lib.iBeaconData;
import com.THLight.USBeacon.App.Lib.iBeaconScanManager;
import com.THLight.USBeacon.Sample.R;
import com.THLight.USBeacon.Sample.ScanediBeacon;
import com.THLight.USBeacon.Sample.THLApp;
import com.THLight.USBeacon.Sample.THLConfig;
import com.THLight.Util.THLLog;


/** ============================================================== */
public class UIMain extends Activity implements iBeaconScanManager.OniBeaconScan, USBeaconConnection.OnResponse
{
	public static String winstonFlag = "";
	public static String bRssi1;
	public static String bRssi2;
	public static String way = "N";
	private static Toast toast;
	private static Handler handler = new Handler();

	/** this UUID is generate by Server while register a new account. */
	final UUID QUERY_UUID		= UUID.fromString("BB746F72-282F-4378-9416-89178C1019FC");
	/** server http api url. */
	final String HTTP_API		= "https://www.usbeacon.com.tw/api/func";
	
	static String STORE_PATH	= Environment.getExternalStorageDirectory().toString()+ "/USBeaconSample/";
	
	final int REQ_ENABLE_BT		= 2000;
	final int REQ_ENABLE_WIFI	= 2001;
	
	final int MSG_SCAN_IBEACON			= 1000;
	final int MSG_UPDATE_BEACON_LIST	= 1001;
	final int MSG_START_SCAN_BEACON		= 2000;
	final int MSG_STOP_SCAN_BEACON		= 2001;
	final int MSG_SERVER_RESPONSE		= 3000;
	
	final int TIME_BEACON_TIMEOUT		= 30000;
	
	THLApp App		= null;
	THLConfig Config= null;
	
	BluetoothAdapter mBLEAdapter= BluetoothAdapter.getDefaultAdapter();

	/** scaner for scanning iBeacon around. */
	iBeaconScanManager miScaner	= null;
	
	/** USBeacon server. */
	USBeaconConnection mBServer	= new USBeaconConnection();
	
	USBeaconList mUSBList		= null;
	
	ListView mLVBLE= null;
	
	BLEListAdapter mListAdapter		= null;
	
	List<ScanediBeacon> miBeacons	= new ArrayList<ScanediBeacon>();
	
	/** ================================================ */
	Handler mHandler= new Handler()
	{
		@Override
		public void handleMessage(Message msg)
		{
			switch(msg.what)
			{
				case MSG_SCAN_IBEACON:
				{
					int timeForScaning		= msg.arg1;
					int nextTimeStartScan	= msg.arg2;

					miScaner.startScaniBeacon(timeForScaning);
					this.sendMessageDelayed(Message.obtain(msg), nextTimeStartScan);
				}
				break;

				case MSG_UPDATE_BEACON_LIST:
					synchronized(mListAdapter)
					{
						verifyiBeacons();
						mListAdapter.notifyDataSetChanged();
						mHandler.sendEmptyMessageDelayed(MSG_UPDATE_BEACON_LIST, 500);
					}
					break;

				case MSG_SERVER_RESPONSE:
					switch(msg.arg1)
					{
						case USBeaconConnection.MSG_NETWORK_NOT_AVAILABLE:
							break;

						case USBeaconConnection.MSG_HAS_UPDATE:
							mBServer.downloadBeaconListFile();
							Toast.makeText(UIMain.this, "HAS_UPDATE.", Toast.LENGTH_SHORT).show();
							break;

						case USBeaconConnection.MSG_HAS_NO_UPDATE:
							Toast.makeText(UIMain.this, "No new BeaconList.", Toast.LENGTH_SHORT).show();
							break;

						case USBeaconConnection.MSG_DOWNLOAD_FINISHED:
							break;

						case USBeaconConnection.MSG_DOWNLOAD_FAILED:
							Toast.makeText(UIMain.this, "Download file failed!", Toast.LENGTH_SHORT).show();
							break;

						case USBeaconConnection.MSG_DATA_UPDATE_FINISHED:
						{
							USBeaconList BList= mBServer.getUSBeaconList();

							if(null == BList)
							{
								Toast.makeText(UIMain.this, "Data Updated failed.", Toast.LENGTH_SHORT).show();
								THLLog.d("debug", "update failed.");
							}
							else if(BList.getList().isEmpty())
							{
								Toast.makeText(UIMain.this, "Data Updated but empty.", Toast.LENGTH_SHORT).show();
								THLLog.d("debug", "this account doesn't contain any devices.");
							}
							else
							{
								Toast.makeText(UIMain.this, "Data Updated("+ BList.getList().size()+ ")", Toast.LENGTH_SHORT).show();

								for(USBeaconData data : BList.getList())
								{
									THLLog.d("debug", "Name("+ data.name+ "), Ver("+ data.major+ "."+ data.minor+ ")");
								}
							}
						}
						break;

						case USBeaconConnection.MSG_DATA_UPDATE_FAILED:
							Toast.makeText(UIMain.this, "UPDATE_FAILED!", Toast.LENGTH_SHORT).show();
							break;
					}
					break;
			}
		}
	};
	
	/** ================================================ */
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui_main);
		
		App		= THLApp.getApp();
		Config	= THLApp.Config;
		
		/** create instance of iBeaconScanManager. */
		miScaner		= new iBeaconScanManager(this, this);
		
		mListAdapter	= new BLEListAdapter(this);
		
		mLVBLE			= (ListView)findViewById(R.id.beacon_list);
		mLVBLE.setAdapter(mListAdapter);
		
		if(!mBLEAdapter.isEnabled())
		{
			Intent intent= new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
			startActivityForResult(intent, REQ_ENABLE_BT);
		}
		else
		{
			Message msg= Message.obtain(mHandler, MSG_SCAN_IBEACON, 1000, 1100);
			msg.sendToTarget();
		}

		/** create store folder. */
		File file= new File(STORE_PATH);
		if(!file.exists())
		{
			if(!file.mkdirs())
			{
				Toast.makeText(this, "Create folder("+ STORE_PATH+ ") failed.", Toast.LENGTH_SHORT).show();
			}
		}
		
		/** check network is available or not. */
		ConnectivityManager cm	= (ConnectivityManager)getSystemService(UIMain.CONNECTIVITY_SERVICE);
		if(null != cm)
		{
			NetworkInfo ni = cm.getActiveNetworkInfo();
			if(null == ni || (!ni.isConnected()))
			{
				dlgNetworkNotAvailable();
			}
			else
			{
				THLLog.d("debug", "NI not null");

				NetworkInfo niMobile= cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
				if(null != niMobile)
				{
					boolean is3g	= niMobile.isConnectedOrConnecting();
					
					if(is3g)
					{
						dlgNetwork3G();
					}
					else
					{
						USBeaconServerInfo info= new USBeaconServerInfo();
						
						info.serverUrl		= HTTP_API;
						info.queryUuid		= QUERY_UUID;
						info.downloadPath	= STORE_PATH;
						
						mBServer.setServerInfo(info, this);
						mBServer.checkForUpdates();
					}
				}
			}
		}
		else
		{
			THLLog.d("debug", "CM null");
		}
		
		mHandler.sendEmptyMessageDelayed(MSG_UPDATE_BEACON_LIST, 500);
	}
	
	/** ================================================ */
	@Override
	public void onResume()
	{
		super.onResume();
	}
	
	/** ================================================ */
	@Override
	public void onPause()
	{
		super.onPause();
	}

	/** ================================================ */
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
	}
	
	/** ================================================ */
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
  	{
  		THLLog.d("DEBUG", "onActivityResult()");

  		switch(requestCode)
  		{
  			case REQ_ENABLE_BT:
	  			if(RESULT_OK == resultCode)
	  			{
				}
	  			break;
	  			
  			case REQ_ENABLE_WIFI:
  				if(RESULT_OK == resultCode)
	  			{
				}
  				break;
  		}
  	}

    /** ================================================ */
    /** implementation of  */

	private static void makeTextAndShow(final Context context, final String text) {
		if (toast == null) {
			//如果還沒有用過makeText方法，才使用
			toast = android.widget.Toast.makeText(context, text, Toast.LENGTH_SHORT);
		} else {
			handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					// Do something after 5s = 5000ms
					toast.setText(text);
				}
			},350);
		}
		toast.show();
	}
	@Override
	public void onScaned(final iBeaconData iBeacon)
	{
		if(winstonFlag.equals("ok")){
			return;
		}
		synchronized(mListAdapter)
		{
			addOrUpdateiBeacon(iBeacon);
		}
		//Toast.makeText(UIMain.this,"scanning wait...",Toast.LENGTH_SHORT).show();
		makeTextAndShow(UIMain.this,"scanning wait...");

		if(way.equals("N") && !mListAdapter.isEmpty() && !way.equals("S")){ //初始 給位置
			if(iBeacon.macAddress.equals("7C:01:0A:FE:43:CE")){
				bRssi1 = mListAdapter.mListItems.get(0).text4;
				bRssi2 = mListAdapter.mListItems.get(1).text4;
			}
			if(iBeacon.macAddress.equals("C8:DF:84:28:E5:60")){
				bRssi1 = mListAdapter.mListItems.get(0).text4;
				bRssi2 = mListAdapter.mListItems.get(1).text4;
			}
			if(Math.abs(Integer.parseInt(bRssi1)) <= 62 && Math.abs(Integer.parseInt(bRssi2)) <= 62){
				way = "P";
				//Toast.makeText(UIMain.this,"car wait to park",Toast.LENGTH_SHORT).show();
				makeTextAndShow(UIMain.this,"car wait to park");
			}
			else if(Math.abs(Integer.parseInt(bRssi1)) > 63 && Math.abs(Integer.parseInt(bRssi2)) <= 63){
				way = "L";
				//Toast.makeText(UIMain.this,"car at left",Toast.LENGTH_SHORT).show();
				makeTextAndShow(UIMain.this,"car at left");
			}
			else if(Math.abs(Integer.parseInt(bRssi1)) <= 63 && Math.abs(Integer.parseInt(bRssi2)) > 63){
				way = "R";
				//Toast.makeText(UIMain.this,"car at right",Toast.LENGTH_SHORT).show();
				makeTextAndShow(UIMain.this,"car at right");
			}
			else if(Math.abs(Integer.parseInt(bRssi1)) > 62 && Math.abs(Integer.parseInt(bRssi2)) > 62){
				way = "F";
				//Toast.makeText(UIMain.this,"car too far",Toast.LENGTH_SHORT).show();
				makeTextAndShow(UIMain.this,"car too far");
			}
		}
		else if(!way.equals("N") && !way.equals("S")){
			if(iBeacon.macAddress.equals("7C:01:0A:FE:43:CE")){
				bRssi1 = mListAdapter.mListItems.get(0).text4;
				bRssi2 = mListAdapter.mListItems.get(1).text4;
			}
			if(iBeacon.macAddress.equals("C8:DF:84:28:E5:60")){
				bRssi1 = mListAdapter.mListItems.get(0).text4;
				bRssi2 = mListAdapter.mListItems.get(1).text4;
			}
			if(Math.abs(Integer.parseInt(bRssi1)) <= 62 && Math.abs(Integer.parseInt(bRssi2)) <= 62){ //中
				if(way.equals("P")){
					//Toast.makeText(UIMain.this,"car already to park",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car already to park");
					winstonFlag = "ok";
					Intent intent = new Intent();
					intent.setClass(UIMain.this, Winstonghost.class);
					startActivity(intent);
					way = "S";
					this.finish();
				}
				else if(way.equals("L")){
					//Toast.makeText(UIMain.this,"car from left to park",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car from left to park");
					way = "P";
				}
				else if(way.equals("R")){
					//Toast.makeText(UIMain.this,"car from right to park",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car from right to park");
					way = "P";
				}
				else if(way.equals("F")){
					//Toast.makeText(UIMain.this,"car from far way to park",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car from far way to park");
					way = "P";
				}
			}
			else if(Math.abs(Integer.parseInt(bRssi1)) > 63 && Math.abs(Integer.parseInt(bRssi2)) <= 63){ //左
				if(way.equals("P")){
					//Toast.makeText(UIMain.this,"car from door to left",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car from door to left");
				}
				else if(way.equals("L")){
					//Toast.makeText(UIMain.this,"car stll at left",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car stll at left");
				}
				else if(way.equals("R")){
					//Toast.makeText(UIMain.this,"car from right to left",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car from right to left");
				}
				else if(way.equals("F")){
					//Toast.makeText(UIMain.this,"car from far way to left",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car from far way to left");
				}
				way = "L";
			}
			else if(Math.abs(Integer.parseInt(bRssi1)) <= 63 && Math.abs(Integer.parseInt(bRssi2)) > 63){ //右
				if(way.equals("P")){
					//Toast.makeText(UIMain.this,"car from door to right",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car from door to right");
				}
				else if(way.equals("L")){
					//Toast.makeText(UIMain.this,"car from left to right",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car from left to right");
				}
				else if(way.equals("R")){
					//Toast.makeText(UIMain.this,"car still at right",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car still at right");
				}
				else if(way.equals("F")){
					//Toast.makeText(UIMain.this,"car from far way to right",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car from far way to right");
				}
				way = "R";
			}
			else if(Math.abs(Integer.parseInt(bRssi1)) > 62 && Math.abs(Integer.parseInt(bRssi2)) > 62){ //遠
				if(way.equals("P")){
					//Toast.makeText(UIMain.this,"car far away",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car far away");
				}
				else if(way.equals("L")){
					//Toast.makeText(UIMain.this,"car from left to far",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car from left to far");
				}
				else if(way.equals("R")){
					//Toast.makeText(UIMain.this,"car from right to far",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car from right to far");
				}
				else if(way.equals("F")){
					//Toast.makeText(UIMain.this,"car still too far",Toast.LENGTH_SHORT).show();
					makeTextAndShow(UIMain.this,"car still too far");
				}
				way = "F";
			}
		}
	}

	/** ================================================ */
    /** implementation of  */
	@Override
	public void onBatteryPowerScaned(BatteryPowerData batteryPowerData) {
		// TODO Auto-generated method stub
		Log.d("debug", batteryPowerData.batteryPower+"");
		for(int i = 0 ; i < miBeacons.size() ; i++)
		{
			if(miBeacons.get(i).macAddress.equals(batteryPowerData.macAddress))
			{
				ScanediBeacon ib = miBeacons.get(i);
				ib.batteryPower = batteryPowerData.batteryPower;
				miBeacons.set(i, ib);
			}
		}
	}
	
	/** ========================================================== */
	public void onResponse(int msg)
	{
		THLLog.d("debug", "Response("+ msg+ ")");
		mHandler.obtainMessage(MSG_SERVER_RESPONSE, msg, 0).sendToTarget();
	}
	
	/** ========================================================== */
	public void dlgNetworkNotAvailable()
	{
		final AlertDialog dlg = new AlertDialog.Builder(UIMain.this).create();
		
		dlg.setTitle("Network");
		dlg.setMessage("Please enable your network for updating beacon list.");

		dlg.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dlg.dismiss();
			}
		});
		
		dlg.show();
	}
	
	/** ========================================================== */
	public void dlgNetwork3G()
	{
		final AlertDialog dlg = new AlertDialog.Builder(UIMain.this).create();
		
		dlg.setTitle("3G");
		dlg.setMessage("App will send/recv data via 3G, this may result in significant data charges.");

		dlg.setButton(AlertDialog.BUTTON_POSITIVE, "Allow", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				Config.allow3G= true;
				dlg.dismiss();
				USBeaconServerInfo info= new USBeaconServerInfo();
				
				info.serverUrl		= HTTP_API;
				info.queryUuid		= QUERY_UUID;
				info.downloadPath	= STORE_PATH;
				
				mBServer.setServerInfo(info, UIMain.this);
				mBServer.checkForUpdates();
			}
		});
		
		dlg.setButton(AlertDialog.BUTTON_NEGATIVE, "Reject", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				Config.allow3G= false;
				dlg.dismiss();
			}
		});
	
		dlg.show();
	}
	
	/** ========================================================== */
	public void addOrUpdateiBeacon(iBeaconData iBeacon)
	{
		long currTime= System.currentTimeMillis();
		
		ScanediBeacon beacon= null;
		
		for(ScanediBeacon b : miBeacons)
		{
			if(b.equals(iBeacon, false))
			{
				beacon= b;
				break;
			}
		}
		
		if(null == beacon)
		{
			beacon= ScanediBeacon.copyOf(iBeacon);
			miBeacons.add(beacon);
		}
		else
		{
			beacon.rssi= iBeacon.rssi;
		}
		
		beacon.lastUpdate= currTime;
	}
	
	/** ========================================================== */
	public void verifyiBeacons()
	{
		{
			long currTime	= System.currentTimeMillis();
			
			int len= miBeacons.size();
			ScanediBeacon beacon= null;
			
			for(int i= len- 1; 0 <= i; i--)
			{
				beacon= miBeacons.get(i);
				
				if(null != beacon && TIME_BEACON_TIMEOUT < (currTime- beacon.lastUpdate))
				{
					miBeacons.remove(i);
				}
			}
		}
		
		{
			mListAdapter.clear();
			
			for(ScanediBeacon beacon : miBeacons)
			{
				if(beacon.major == 1){
					mListAdapter.addItem(new ListItem("senser1", ""+ beacon.major, ""+ beacon.minor, ""+ beacon.rssi,""+beacon.batteryPower));
				}
				else if(beacon.major == 2){
					mListAdapter.addItem(new ListItem("senser2", ""+ beacon.major, ""+ beacon.minor, ""+ beacon.rssi,""+beacon.batteryPower));
				}
				else{
					mListAdapter.addItem(new ListItem("another", ""+ beacon.major, ""+ beacon.minor, ""+ beacon.rssi,""+beacon.batteryPower));
				}
			}
		}
	}
	
	/** ========================================================== */
	public void cleariBeacons()
	{
		mListAdapter.clear();
	}

}

/** ============================================================== */
class ListItem
{
	public String text1= "";
	public String text2= "";
	public String text3= "";
	public String text4= "";
	public String text5= "";
	
	public ListItem()
	{
	}
	
	public ListItem(String text1, String text2, String text3, String text4, String text5)
	{
		this.text1= text1;
		this.text2= text2;
		this.text3= text3;
		this.text4= text4;
		this.text5= text5;
	}
}

/** ============================================================== */
class BLEListAdapter extends BaseAdapter
{
	private Context mContext;
	  
	List<ListItem> mListItems= new ArrayList<ListItem>();

	/** ================================================ */
	public BLEListAdapter(Context c) { mContext= c; }

	/** ================================================ */
	public int getCount() { return mListItems.size(); }
	
	/** ================================================ */
	public Object getItem(int position)
	{
		if((!mListItems.isEmpty()) && mListItems.size() > position)
		{
			return mListItems.toArray()[position];
		}
		
		return null;
	}
	  
	public String getItemText(int position)
	{
		if((!mListItems.isEmpty()) && mListItems.size() > position)
		{
			return ((ListItem)mListItems.toArray()[position]).text1;
		}
		
		return null;
	}
	
	/** ================================================ */
	public long getItemId(int position) { return 0; }
	
	/** ================================================ */
	// create a new ImageView for each item referenced by the Adapter
	public View getView(int position, View convertView, ViewGroup parent)
	{
	    View view= (View)convertView;
	     
	    if(null == view)
	    	view= View.inflate(mContext, R.layout.item_text_3, null);
	
	    // view.setLayoutParams(new AbsListView.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));

	    if((!mListItems.isEmpty()) && mListItems.size() > position)
	    {
		    TextView text1	= (TextView)view.findViewById(R.id.it3_text1);
		    TextView text2	= (TextView)view.findViewById(R.id.it3_text2);
		    TextView text3	= (TextView)view.findViewById(R.id.it3_text3);
		    TextView text4	= (TextView)view.findViewById(R.id.it3_text4);
		    TextView text5	= (TextView)view.findViewById(R.id.it3_text5);

	    	ListItem item= (ListItem)mListItems.toArray()[position];

			text1.setText(item.text1);
			text2.setText(item.text2);
			text3.setText(item.text3);
			text4.setText(item.text4+ " dbm");
			text5.setText(item.text5+ " V");
		}
	    else
	    {
	    	view.setVisibility(View.GONE);
	    }

	    return view;
	}

	/** ================================================ */
	@Override
    public boolean isEnabled(int position) 
    {
		if(mListItems.size() <= position)
			return false;

        return true;
    }

	/** ================================================ */
	public boolean addItem(ListItem item)
	{
		mListItems.add(item);
	  	return true;
	}
  
	/** ================================================ */
	public void clear()
	{
		mListItems.clear();
	}
}

/** ============================================================== */
