package tw.yukina.portal.framework.api.job.enums;

public enum JobDeclaredType {
    PUBLIC,JOB_PUBLIC,PRIVATE
}
