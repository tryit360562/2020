package tw.yukina.portal.framework.api.job.enums;

public enum WorkTypeEnum {
    JOB,STEP,EMPTY
}
