package tw.yukina.portal.framework.test;

import tw.yukina.portal.framework.api.module.annotation.Module;

@Module(id = "TestModule")
public class TestModule {

}
