package tw.yukina.portal.framework.core.input.event;

public class ExampleEvent {
}
