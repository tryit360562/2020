package tw.yukina.portal.framework.api.exception;

public class StepVerifyException extends Exception {
    public StepVerifyException(String message){
        super(message);
    }
}
