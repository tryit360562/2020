package tw.yukina.portal.framework.core.job;

public class ConfJobPlan {
}
