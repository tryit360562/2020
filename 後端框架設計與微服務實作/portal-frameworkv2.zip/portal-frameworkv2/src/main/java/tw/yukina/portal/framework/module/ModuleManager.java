package tw.yukina.portal.framework.module;

import org.springframework.stereotype.Service;

@Service
public class ModuleManager {

}
