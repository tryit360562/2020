package tw.yukina.portal.framework.api.exception;

public class JobVerifyException extends Exception {
    public JobVerifyException(String message){
        super(message);
    }
}
