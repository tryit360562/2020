package tw.yukina.portal.framework.api.exception;

public class TypeNotMatchException extends Exception {
}
