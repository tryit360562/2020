<html>
<head><title>確認郵件地址及寄出</title></head>
<meta  charset = "utf-8" />
<?php
	ob_start();
	session_start();


	if(isset($_POST["Send"])){
	
	$link=@mysqli_connect('db4free.net','fastfood','fastfood88','fastfood')
		        or die("無法開啟資料庫連接!<br/>".mysqli_connect_error());
 
		        mysqli_query($link,'SET NAMES utf8');

	$ue = $_SESSION["US"];
	$pid = rand(10000,32677);
	$code = rand(0,9);
	$sql="INSERT INTO amount(c_id,username,code) 
				VALUES ('".$pid."','".$ue."','".$code."')";
	$retval = mysqli_query( $link, $sql );
	if(! $retval )
	{
    die('無法開啟資料庫連接 ' . mysqli_error($link));
	}
	mb_internal_encoding("utf-8");
	$to = $_POST["To"];
	$from = "s1063669@pu.edu.tw";
	$subject = "訂單通知";
	$body="訂單內容如下:\n";
	$total=0;
 	$subject=mb_encode_mimeheader("$subject","utf-8");
	while(list($arr,$value)=each($_COOKIE)){
    if(is_array($_COOKIE[$arr])){
	while(list($name,$value)=each($_COOKIE[$arr])){
				$body.="* $name : $value\n";
				if($name=="Price") $price=$value;
				if($name=="Qua") $qua=$value;
			
			}
			$n=$price*$qua;
			$total+=$n;
			$body.="小計:$n \n------------------\n";
		}
	}
			$body.="訂單編號:$total\n";
			$body.="總價:$total\n------------------\n";
			$body.="領取碼:$code\n------------------\n";
			
$header = "From: $from \nReply-To: $from \n";
	if(mail($to, $subject, $body,$header)){
		echo "郵件已經成功寄出!<br>";
			header("Location: delete.php");
	}else{
		echo "郵件寄出失敗!<br>";	
			header("Location: shoppingcart.php");
}
}
?>
<body>
<form action="mail.php" method="post">
  親愛的顧客，感謝您的訂購。<br>
	請輸入您的郵件地址，<br>
	我們隨後會寄出訂單通知。
  </td></tr><br/>
輸入郵件地址:<input type="text" name="To" size="15"/><br/>
<input type="submit" name="Send" value="送出郵件"/><br/>
</form></body>
</html>