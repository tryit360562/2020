<?php session_start();?>
<html>
<head><title>Bye</title></head>
<meta   http-equiv="Content-Type"  content="text/html;  charset=UTF-8"  >
<!-- <link rel="stylesheet" href="assets/logout.css"> -->
<link rel="stylesheet" href="assets/reset.css">
<link href="assets/bootstrap/bootstrap-grid.css" rel="stylesheet">
<link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">
<script src="assets/jquery.js"></script>
<script src="assets/jquery_slim.js"></script>
<script src="assets/js/bootheader.js"></script>
<script src="assets/js/bootstrap.bundle.js"></script>
<script src="assets/analytics.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-151662645-1"></script>
<body>
<?php if(isset($_SESSION["US"])){
	print "HI!~".$_SESSION["US"];
}
?>
<br><h4 style="text-align: center;">你已經登出 請重新登入</h4><br>
<?php
setcookie("SF","",time()-7200);
unset($_SESSION["US"]);
session_destroy();
?>
<hr/><h4 style="text-align: center;">|<a href="login.php">重新登入</a>|</h4>
<br>
<h4 style="text-align: center;">|<a href="food.php">返回首頁</a>|</h4>
</body>
</html>