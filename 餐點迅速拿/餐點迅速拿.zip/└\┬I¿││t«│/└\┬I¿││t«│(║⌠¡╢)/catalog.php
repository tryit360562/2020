<html>
<head><meta  charset = "utf-8" /><title>目錄</title></head>
<?php
	session_start();
	$_SESSION["t"]=0;
	if(isset($_POST["Item"])){
		$_SESSION["Qua"] = $_POST["Qua"];
		$id = $_POST["Item"];
		$_SESSION["ID"] = $id;
		switch(strtoupper($id)){
			case "S001":
			$_SESSION["Name"] = "紅茶";
			$_SESSION["Price"] = 20;
			break;
			case "S002":
			$_SESSION["Name"] = "綠茶";
			$_SESSION["Price"] = 20;
			break;
			case "S003":
			$_SESSION["Name"] = "奶茶";
			$_SESSION["Price"] = 25;
			break;
			case "S004":
			$_SESSION["Name"] = "咖啡";
			$_SESSION["Price"] = 40;
			break;
			case "S005":
			$_SESSION["Name"] = "拿鐵";
			$_SESSION["Price"] = 45;
			break;
		}
		header("Location:savecart.php");
	}
?>
<body bgcolor= "#FFCC77" text="blue">
<form action="catalog.php" method="post">
選擇商品:
<select name="Item">
	<option value="S001">紅茶 - $20</option>
	<option value="S002">綠茶 - $20</option>
	<option value="S003">奶茶 - $25</option>
	<option value="S004">咖啡 - $40</option>
	<option value="S005">拿鐵 - $45</option>
</select>
<input type="text" size="5" name="Qua" value="1"/>
<input type="submit" value="訂購"/>
</form>
<a href="shoppingcart.php">檢視購物車</a>
<a href="update.php">更改密碼</a>
<a href="searchorder.php">查詢領取碼</a>
</body>
</html>