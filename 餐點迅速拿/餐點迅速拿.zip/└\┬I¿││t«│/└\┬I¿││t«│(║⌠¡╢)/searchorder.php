<html>
<head><title>訂單領取碼查詢</title></head>
<meta  charset = "utf-8" />
<?php

session_start();
//$d = date_default_timezone_set("Asia/Shanghai");
//echo .date("Y-m-d h:i:sa", $d);
$link=@mysqli_connect("db4free.net","fastfood","fastfood88","fastfood")
		or die("無法開啟資料庫連接!<br/>");
$un = $_SESSION["US"];
mysqli_query($link , "set names utf8");
 $sql = "SELECT c_id, username, 
        code
        FROM amount
        where  username = '$un'
				ORDER BY n_id DESC";
 
mysqli_select_db( $link, 'fastfood' );


$retval = mysqli_query( $link, $sql );
if(! $retval )
{
    die('無法開啟資料庫連接 ' . mysqli_error($link));
}
echo '<table border="1"><tr><td>訂單編號</td><td>訂購人</td><td>領取碼</td></tr>';
while($row = mysqli_fetch_array($retval, MYSQLI_ASSOC))
{
    echo "<tr><td> {$row['c_id']}</td> ".
         "<td>{$row['username']} </td> ".
         "<td>{$row['code']} </td> ".
         "</tr>";
}
echo '</table>';
mysqli_close($link);
?>
<body>
<a href="catalog.php">目錄</a>
</body>
</html>