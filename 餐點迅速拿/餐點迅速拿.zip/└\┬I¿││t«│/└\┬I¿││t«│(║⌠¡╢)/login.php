<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>登入</title>
    <link rel="stylesheet" href="assets/login.css">
    <link rel="stylesheet" href="assets/reset.css">
    <link href="assets/bootstrap/bootstrap-grid.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">
    <script src="assets/login.js"></script>
    <script src="assets/jquery.js"></script>
    <script src="assets/jquery_slim.js"></script>
    <script src="assets/js/bootheader.js"></script>
    <script src="assets/js/bootstrap.bundle.js"></script>
    <script src="assets/analytics.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-151662645-1"></script>
</head>
<body>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <div class="bglog">
    <?php
        session_start();
        ob_start();
        if(isset($_COOKIE["SF"])){
	        $showform=false;
        }else{
	        $showform=true;
        }
        $username = "";
        $_SESSION["SF"]=$showform;
        if(isset($_POST["username"]))
		        $username=$_POST["username"];
		        $_SESSION["US"]=$username;
        if(isset($_POST["password"]))
		        $password=$_POST["password"];

        if(isset($_POST["login"])){
		        if($username != "" && $password != ""){
	        $link=@mysqli_connect('db4free.net','fastfood','fastfood88','fastfood')
		        or die("無法開啟資料庫連接!<br/>".mysqli_connect_error());

		        mysqli_query($link,'SET NAMES utf8');

		        $sql="SELECT * FROM member WHERE username='";
		        $sql.=$username."' AND password='".$password."'";

		        $result=mysqli_query($link,$sql);
		        $total_records = mysqli_num_rows($result);
	
        if($total_records>0){
		        setcookie("SF",$showform,time()+3600*24);
		        $showform=false;
        }else{
	        echo "<font color='red'>使用者名稱或密碼錯誤!</font><br>";
	        }
	        mysqli_close($link);
	        }
        }

        if(isset($_POST["register"])){
	        header("Location:register.php");
        }
        if($showform){
    ?>
        <form action="login.php" method="POST">
            <div style="margin-top: 1.5rem">
                <div class="container">
                    <div class="form-group row">
                        <font size="3" class="col-md-4 col-form-label text-md-right">使用者名稱:</font>
                        <!-- <div class="col-md-6"> -->
                            <input type="text" name="username" size="10"/></font>
                        <!-- </div> -->
                    </div>
                    <div class="form-group row">
                        <font size="3" class="col-md-4 col-form-label text-md-right">密碼</font>
                        <!-- <div class="col-md-6"> -->
                            <input type="password" name="password" size="10"/></font>
                        <!-- </div> -->
                    </div>
                </div>
            </div>
        
            <div class="d-flex justify-content-around" style="margin-top: 3rem">
                <input type="submit" class="btn btn-success badge-pill" name="login" value="登入">
                <input type="submit" class="btn btn-success badge-pill" value="註冊" name="register"/>
                <!-- <button type="button" class="btn btn-secondary badge-pill canc" data-dismiss="modal">取消</button> -->
            </div>
        </form>

        <?php
        }else{
            header("Location:catalog.php");
        }?>
    </div>

    <?php
        // header("Content-type: text/html; charset=utf-8");
        
        // if(! (empty($_POST['account']) || empty($_POST['password']))){
        //     include('connect.php');
        //     $account = $_POST['account'];
        //     $password = $_POST['password'];

        //     if($account && $password){
        //         $sql = "SELECT * FROM user where account = 'account' AND password = 'password'";
        //         $result = mysqli_query($db_link, $sql);
        //         $row = mysqli_num_rows($result);
        //         if($row){
        //             header('refresh:0;url=food.php');
        //             exit;
        //         }else{
        //             echo "帳號或密碼錯誤";
        //         }
        //     }else{
        //         echo "填寫不完整";
        //     }

        //     $db_link -> close();
        // }

    ?>

    <!-- back -->
    <div class="container row">
        <div class="back">
            <button type="button" class="btn btn-outline-dark" onclick="goBack()"><span><h5>Home</h5></span></button>
        </div>
    </div>

</body>
</html>