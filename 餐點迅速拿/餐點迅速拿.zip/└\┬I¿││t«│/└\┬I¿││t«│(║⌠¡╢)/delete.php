<?php
session_start();
while(list($arr,$value)=each($_COOKIE)){
		while(list($name,$value)=each($_COOKIE[$arr])){
		setcookie($arr."[".$name."]","",time()-3600);
	}
}
if(isset($_SESSION["t"])){
	$_SESSION["t"]=-1;
}
header("Location: shoppingcart.php");
?>