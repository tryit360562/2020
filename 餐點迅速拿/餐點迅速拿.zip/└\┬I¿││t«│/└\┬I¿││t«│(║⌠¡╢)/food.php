<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>餐點迅速拿</title>
    <link rel="stylesheet" href="assets/food.css">
    <link rel="stylesheet" href="assets/reset.css">
    <link href="assets/bootstrap/bootstrap-grid.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">
    <script src="assets/jquery.js"></script>
    <script src="assets/jquery_slim.js"></script>
    <script src="assets/js/bootheader.js"></script>
    <script src="assets/js/bootstrap.bundle.js"></script>
    <script src="assets/analytics.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-151662645-1"></script>

</head>
<body>

    <nav class="navbar navbar-expand-xl navbar-light bg-light fixed-top shadow-sm header" style="background-color: azure;">
        <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="login.php" class="nav-link btn-link navbar-btn" style="color: black">登入</a>
                    </li>
                    <li class="nav-item">
                        <a href="register.php" class="nav-link btn-link navbar-btn" style="color: black">註冊</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container foodimg clearfix bgrow">
        
       
        <div class="responsive" style="margin-top: 5rem; margin-left: 5rem;">
            <div class="gallery">
                <a href="catalog.php" class="home">
                    <img src="./assets/img/restaurant.jpg" alt="Restaurant" style="width=350px height:400px">
                    <div class="desc"><span>餐廳</span></div>
                </a>
              </div>
        </div>

        <div class="responsive" style="margin-top: 5rem; margin-left: 5rem;">
            <div class="gallery">
                <a href="aboutus.php"  class="home" >
                    <img src="./assets/img/about.jpg" alt="Aboutus"  style="width=350px height:400px">
                    <div class="desc"><span>意見回饋</span></div>
                </a>
            </div>
        </div>
    </div>
</body>
</html>