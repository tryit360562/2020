<?php
ob_start();
session_start();
?>
<html>
<head><meta charset="utf-8"/><title>購物暫存</title></head>
<?php
	if(isset($_SESSION["ID"])){
	$id=$_SESSION["ID"];
	$name=$_SESSION["Name"];
	$price=$_SESSION["Price"];
	$qua=$_SESSION["Qua"];
	
	setcookie($id."[ID]",$id,time()+3600);
	setcookie($id."[Name]",$name,time()+3600);
	setcookie($id."[Price]",$price,time()+3600);
	setcookie($id."[Qua]",$qua,time()+7200);
}
	header("Location: shoppingcart.php");
?>
</html>