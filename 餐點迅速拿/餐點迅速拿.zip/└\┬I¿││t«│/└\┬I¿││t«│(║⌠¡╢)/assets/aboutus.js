function antpage(event, page) {
    var i, other, now;
     other= document.getElementsByClassName("cl");
    for (i = 0; i < other.length; i++) {
      other[i].style.display = "none";
    }
    now = document.getElementsByClassName("now");
    for (i = 0; i < now.length; i++) {
      now[i].className = now[i].className.replace(" active", "");
    }
    document.getElementById(page).style.display = "block";
    event.currentTarget.className += " active";
  }
  function checkForm() {
      var name = document.getElementById('name').value;
    //   var sex = document.getElementById('sex').value;
      var phone = document.getElementById('phone').value;
    //   var email = document.getElementById('email').value;
      var text = document.getElementById('words').value;
  
      if (name == "") alert("姓名不能为空");
      else {
          if (name.length > 4)
          alert("姓名过长！") ;
      }
      if (phone == "") alert ("手机号码不能为空");
      else {
          if (!/^(13[0-9]\d{8}$|15[012356789]\d{8}$|18[0-9]\{8}$|14[57]\d{8})$/.test(phone))
              alert("手机号码格式不正确");
      }
    //   if (email == "") alert("邮箱地址不能为空") ;
    //   else {
    //       if (!/^([0-9a-zA-Z_]{5,12}@(163|126|qq|yahoo|gmail|sina|QQ)\.(com|com\.cn|cn|la))$/.test(email))
    //           alert("邮箱地址格式不正确");
    //   }
      if (text == "") alert("留言内容不能为空");
  }
  
  function DoSave() {
      if (checkForm()) {
          alert("留言成功！");
  
      }
  }