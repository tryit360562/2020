function goBack() {
    window.location.href='./food.php'
}  

function goOrder() {
    window.location.href='./myorder.php'
}