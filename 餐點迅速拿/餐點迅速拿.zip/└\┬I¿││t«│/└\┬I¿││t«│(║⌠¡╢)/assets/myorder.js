function buy() {
    alert("訂單已送出");
    document.getElementById("demo").innerHTML = "訂單已完成";
}

function Previous() {
    window.history.back(-1);
}

function goBack() {
    window.location.href='./food.php'
}  