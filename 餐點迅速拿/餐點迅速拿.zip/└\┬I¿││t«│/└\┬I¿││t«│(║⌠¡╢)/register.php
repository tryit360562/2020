<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>註冊</title>
    <link rel="stylesheet" href="assets/register.css">
    <link rel="stylesheet" href="assets/reset.css">
    <link href="assets/bootstrap/bootstrap-grid.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">
    <script src="assets/register.js"></script>
    <script src="assets/jquery.js"></script>
    <script src="assets/jquery_slim.js"></script>
    <script src="assets/js/bootheader.js"></script>
    <script src="assets/js/bootstrap.bundle.js"></script>
    <script src="assets/analytics.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-151662645-1"></script>
</head>
<body>
    <div class="bgreg">
        <div style="margin-top: 1.5rem">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <?php
            $showform=0;
            session_start();
            ob_start();
            echo"=====註冊:請輸入帳號密碼=====<br>";
            if(isset($_POST["up"])){
	            $name = $_POST["name"];
	            $email = $_POST["email"];
	            $username = $_POST["username"];
	            $password = $_POST["password"];
	  
	            if($username=="" || $password==""){
	                echo "<font color='red'>錯誤:帳號/密碼空白</font>";
	            }else if($password==$_POST["password2"]){
	                $link=@mysqli_connect('db4free.net','fastfood','fastfood88','fastfood')
		            or die("無法開啟資料庫連接!<br/>");
			            $smail = "SELECT * FROM member WHERE email='".$email."'";
			            $suname = "SELECT * FROM member WHERE username='".$username."'";
			            $r_name=mysqli_query($link,$suname);
			            $r_email=mysqli_query($link,$smail);
			            $t_name=mysqli_num_rows($r_name);
			            $t_email=mysqli_num_rows($r_email);	
			            if($t_name>0){
					        echo"<font color='red'>錯誤:帳號已被註冊!<br></font>";
			            }else if($t_email>0){
					        echo"<font color='red'>錯誤:Email已被註冊!<br></font>";
			            }else{
				            $sql="INSERT INTO member(name,email,username,password) VALUES ('".$name."','".$email."','".$username."','".$password."')";
				            if($result=mysqli_query($link,$sql)){
				                echo"=====".$username."註冊成功=====<br>請按返回登入系統!<br>";
				                $showform=-1;
				            }
			            }
	            }else{
				    echo "<font color='red'>錯誤:兩次密碼不相等</font>";
	            }
		        mysqli_close($link);
            }
                if($showform==0){
        ?>
            <form method="post" action="register.php">
                <div class="container">
                    <div class="form-group row">
                        <font size="3" class="col-md-4 col-form-label text-md-right">姓名:</font>
                        <!-- <div class="col-md-6"> -->
                            <input type="text" name="name" size="10"/></font><br/>
                        <!-- </div> -->
                    </div>
                    <div class="form-group row">
                        <font size="3" class="col-md-4 col-form-label text-md-right">信箱:</font>
                        <!-- <div class="col-md-6"> -->
                            <input type="text" name="email" size="50"/></font><br/>
                        <!-- </div> -->
                    </div>
                    <div class="form-group row">
                        <font size="3" class="col-md-4 col-form-label text-md-right">帳號:</font>
                        <!-- <div class="col-md-6"> -->
                            <input type="text" name="username" size="10"/></font><br/>
                        <!-- </div> -->
                    </div>
                    <div class="form-group row">
                        <font size="3" class="col-md-4 col-form-label text-md-right">密碼:</font>
                        <!-- <div class="col-md-6"> -->
                        <input type="password" name="password" size="10"/></font><br/>
                    </div>
                    <!-- </div> -->
                    <div class="form-group row">
                        <font size="3" class="col-md-4 col-form-label text-md-right">再度輸入密碼:</font>
                        <!-- <div class="col-md-6"> -->
                        <input type="password" name="password2" size="10"/></font><br/>
                    <!-- </div> -->
                    </div>
                </div>

                <div class="d-flex justify-content-around">
                    <!-- <input type="hidden" name="action" value="add">   -->
                    <input  type="submit" name="up" class="btn btn-success badge-pill" value="註冊">
                    <a href="login.php"><button type="button" class="btn btn-success badge-pill">取消</button></a>
                    <!-- <button type="button" class="btn btn-secondary badge-pill canc" data-dismiss="modal">取消</button> -->
                </div>
            </form>
        </div>
    </div>
    
            <?php
                }else if($showform==-1){
            ?>
                    <a href="login.php"><button type="button">返回登入</button></a>
                    <?php
                }
        // if(! (empty($_POST['name']) || empty($_POST['email']) || empty($_POST['account']) || empty($_POST['password']))){
        //     include('connect.php');

        //     $account = $_POST['account'];
        //     $password = $_POST['password'];
        //     $name = $_POST['name'];
        //     $email = $_POST['email'];

        //     $sql_query = "INSERT INTO user (account, password, name, email) VALUES ('$account', '$password', '$name', '$email')";
        //     mysqli_query($db_link, $sql_query);

        //     $sql_findID = "SELECT * FROM user WHERE account = '".$_POST['account']."'";

        //     $data = mysqli_query($db_link, $sql_findID);
        //     $user = mysqli_fetch_assoc($data);

        //     session_start();
        //     $_SESSION['id'] = $user['id'];
        //     $_SESSION['name'] = $user['name'];
        //     $_SESSION['email'] = $user['email'];
        //     $_SESSION['account'] = $user['account'];
        //     $_SESSION['password'] = $user['password'];

        //     $db_link->close();

        //     header('Location: login.php');
        // }
    ?>

    <!-- back -->
    <div class="container row">
        <div class="back">
            <button type="button" class="btn btn-outline-dark" onclick="goBack()"><span><h5>Home</h5></span></button>
        </div>
    </div>
</body>
</html>