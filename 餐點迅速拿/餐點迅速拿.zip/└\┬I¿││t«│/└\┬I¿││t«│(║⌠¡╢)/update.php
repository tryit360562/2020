<html>
<head>
<title>更改密碼</title>
</head>
<body>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php
session_start();
$showform=0;
echo"=====".$_SESSION["US"]."更改密碼=====<br>";
if(isset($_POST["up"])){
$link=@mysqli_connect("db4free.net","fastfood","fastfood88","fastfood")
		or die("無法開啟資料庫連接!<br/>");
	$username=$_SESSION["US"];
	$new1=$_POST["password1"];
	if($new1==$_POST["password2"]){
			$sql="UPDATE member SET password='";
			$sql.=$new1."' WHERE username'".$username."'";
	if($result = mysqli_query($link,$sql)){
	print "<font color='red'>更改成功!<br></font>";}
	$showform=-1;
	}else
	echo"<font color='red'>錯誤:密碼不相等!</font>";
}	
?>
<?php
if($showform==0){
?>
<form method="post" action="update.php">
<font size="2">密碼:</font>
<input type="password" name="password1" size="10"/></font><br/>
<font size="2">再度輸入密碼:</font>
<input type="password" name="password2" size="10"/></font><br/>
<input type="submit" value="update" name="up"/>
</form>
<?php
}else if($showform==-1){
	unset($_COOKIE["SF"]);
	setcookie("SF","",time()-3600);
?>
<a href="login.php"><input type="sumbit" value="返回"/></a><br/>
<?php
}
?>
</body>
</html>