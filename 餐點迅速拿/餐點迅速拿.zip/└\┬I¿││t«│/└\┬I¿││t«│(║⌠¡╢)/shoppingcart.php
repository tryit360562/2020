<?php
	ob_start();
	session_start();
?>
<html>
<head><meta  charset = "utf-8" /><title>清單</title></head>
<body bgcolor= "#FFCC77" text="blue">
<table border = "0">
	<tr bgcolor = "#CC99FF">
		<td>功能</td><td>編號</td><td>名稱</td>
		<td>價格</td><td>數量</td><td>小計</td>
	</tr>
	<?php
		$flag = false; $total = 0;
		while(list($arr,$value) = each($_COOKIE)){

			if(isset($_COOKIE[$arr]) &&is_array($_COOKIE[$arr])){
				if($flag){
					$flag=false;
					$color="#FF99CC";	
				}else{
					$flag=true;
					$color="#99FFC";
				}
			echo "<tr bgcolor='".$color."'><td>";
			echo "<a href='deleteal.php?Id=".$arr."'>";
			echo "刪除</a></td>";
			$price=0;
			$qua=0;
			while(list($name,$value)=each($_COOKIE[$arr])){
				echo "<td>".$value."</td>";
				if($name=="Price") $price=$value;
				if($name=="Qua") $qua+=$value;
				$_SESSION["t"]++;
			}
			echo "<td>".$price*$qua."</td>";
			$total+=$price*$qua;
			echo "</tr>";
		}
	}
	if($total!=0){
		echo "<tr bgcolor=yellow><td colspan=6 align=right>";
		echo "總金額 = <font color=blue>NT$ $total 元</font></td></tr>";
	}
?>
</table>
<hr/>|<a href="catalog.php">商品目錄</a>| 
<?php
if($_SESSION["t"]>0){
	echo"| <a href='mail.php'>訂單送出</a> |";
	echo"| <a href='delete.php'>清空購物車</a> |";
	
}?>
| <a href="logout.php">登出</a> |
</body>
</html>