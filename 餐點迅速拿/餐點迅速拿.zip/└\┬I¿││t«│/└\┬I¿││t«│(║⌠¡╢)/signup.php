<html>
<head><title>帳密註冊</title><head>
<body>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php
$showform=0;
session_start();
ob_start();
echo"=====註冊:請輸入帳號密碼=====<br>";
if(isset($_POST["up"])){
	$name = $_POST["name"];
	$email = $_POST["email"];
	$username = $_POST["username"];
	$password = $_POST["password"];
	  
	if($username=="" || $password==""){
	echo "<font color='red'>錯誤:帳號/密碼空白</font>";
	}else if($password==$_POST["password2"]){
	$link=@mysqli_connect('db4free.net','fastfood','fastfood88','fastfood')
		or die("無法開啟資料庫連接!<br/>");
			$smail = "SELECT * FROM member WHERE email='".$email."'";
			$suname = "SELECT * FROM member WHERE username='".$username."'";
			$r_name=mysqli_query($link,$suname);
			$r_email=mysqli_query($link,$smail);
			$t_name=mysqli_num_rows($r_name);
			$t_email=mysqli_num_rows($r_email);	
			if($t_name>0){
					echo"<font color='red'>錯誤:帳號已被註冊!<br></font>";
			}else if($t_email>0){
					echo"<font color='red'>錯誤:Email已被註冊!<br></font>";
			}else{
				$sql="INSERT INTO member(name,email,username,password) VALUES ('".$name."','".$email."','".$username."','".$password."')";
				if($result=mysqli_query($link,$sql)){
				echo"=====".$username."註冊成功=====<br>請按返回登入系統!<br>";
				$showform=-1;
				}
			}
	}else{
				echo "<font color='red'>錯誤:兩次密碼不相等</font>";
	}
		mysqli_close($link);
}
if($showform==0){
?>
<form method="post" action="signup.php">
<font size="3">姓名:</font>
<input type="text" name="name" size="10"/></font><br/>
<font size="3">信箱:</font>
<input type="text" name="email" size="50"/></font><br/>
<font size="3">帳號:</font>
<input type="text" name="username" size="10"/></font><br/>
<font size="3">密碼:</font>
<input type="password" name="password" size="10"/></font><br/>
<font size="3">再度輸入密碼:</font>
<input type="password" name="password2" size="10"/></font><br/>

<input type="submit" value="註冊" name="up"/>
<a href="login.php"><button type="button">取消</button></a>
</form>
<?php
}else if($showform==-1){
?>
<a href="login.php"><button type="button">返回登入</button></a>
<?php
}
?>
</body>
</html>