<?php
session_start();
        ob_start();
	  $link=@mysqli_connect('db4free.net','fastfood','fastfood88','fastfood')
		    or die("�L�k�}�Ҹ�Ʈw�s��!<br/>".mysqli_connect_error());
				mysqli_query($link,'SET NAMES utf8');
	$code = 001;
	$sql="INSERT INTO amount(username,code) VALUES (59,111)";
mysqli_close($link);
?>