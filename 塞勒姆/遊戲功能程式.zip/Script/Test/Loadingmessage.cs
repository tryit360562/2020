﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Loadingmessage: MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject LoadScreen;
    public Slider slider;
    public Text text;
    public void LoadNextLevel()
    {
        SceneManager.LoadScene("choose player");
       // StartCoroutine(Loadlevel());
    }
   /* IEnumerator Loadlevel()
    {
        LoadScreen.SetActive(true);

        AsyncOperation operation = SceneManager.LoadSceneAsync("choose player");
        //        SceneManager.GetActiveScene().buildIndex + 1
     operation.allowSceneActivation = false;

        while (!operation.isDone)
        {
            slider.value = operation.progress;

            text.text = operation.progress * 100 + "%";

            if (operation.progress >=0.9f)
            {
                slider.value = 1;
                text.text = "Please AnyKey to continue";

                if(Input.anyKeyDown)
                {
                    operation.allowSceneActivation = true;
                }
            }
            yield return null;
        }*/
    }

   /*https://www.bilibili.com/video/BV1V7411Y7Fu/?spm_id_from=333.788.videocard.2  */

