﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class joystick : MonoBehaviour
{
    // Start is called before the first frame update
    private int rect;
    private int dragging;
    public void StartDrag()
    {

    }
    public void Drag()
    {
    }
    public void StopDrag()
    {
    }
    private void Update()
    {
        Drag();
    }

    
}
