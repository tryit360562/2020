﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class 絞刑台 : MonoBehaviour
{
    public GameObject Player;
    void OnTriggerEnter(Collider a) //自訂碰撞自身a
    {
        if (a.tag == "Player")
        {
        //  Destroy(this.Player,3);
            StartCoroutine(LoadYourAsyncScene());
        }
        
    }
    void Update()
    {
        // Press the space key to start coroutine
     /*   if (Input.GetKeyDown(KeyCode.Space))
        {   // Use a coroutine to load the Scene in the background
            StartCoroutine(LoadYourAsyncScene());
        }*/
    }

    IEnumerator LoadYourAsyncScene()
    { 
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync("Gameover");
        while (!asyncLoad.isDone)
        {
            yield return null;
        }
    }
}





