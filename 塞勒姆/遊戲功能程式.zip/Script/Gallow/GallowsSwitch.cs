﻿using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;


public class GallowsSwitch : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        GetComponent<Gallows>().enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
    }
}