﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class CameraUNet : NetworkBehaviour//MonoBehaviour
{
    // Start is called before the first frame update
    public Camera cam;
    // Update is called once per frame
    void Update()
    {
        if(!isLocalPlayer)
        {
            cam.enabled = false;
            return;
        }
    }
}
