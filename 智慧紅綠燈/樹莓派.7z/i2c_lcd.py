import sys
import time
import smbus2
import RPi.GPIO as GPIO
import checktime2 as ct
####
####
chan_list = [17,27]
GPIO.setmode(GPIO.BCM)
GPIO.setup(chan_list,GPIO.OUT)
GPIO.setwarnings(False)
#GPIO.output(chan_list,GPIO.HIGH)
print("led check")

def r_led():
    GPIO.output(chan_list,(GPIO.HIGH,GPIO.LOW))
def g_led():
    GPIO.output(chan_list,(GPIO.LOW,GPIO.HIGH))
####
def tgi(a):
    if a > 90:
        a=90
    if a < 30:
        a=30
    g_led()
    while range(a):
        lcdd(a,0)
        a-=1
        time.sleep(1)
        if a == 0 :
            break
def tri(b):
    if b > 90:
        b=90
    if b < 30:
        b=30
    r_led()
    while range(b):
        lcdd(0,b)
        b-=1
        time.sleep(1)
        if b == 0:
            break
def lcdd(t,a):
    lcd_1="Cn&24_G %04d"%(t)
    lcd_2="Cn&24_R %04d"%(a)
    lcd.cursor_pos = (0, 0)
    lcd.write_string(lcd_1)
    lcd.cursor_pos = (1, 0)
    lcd.write_string(lcd_2)
sys.modules['smbus'] = smbus2

from RPLCD.i2c import CharLCD
 
lcd = CharLCD('PCF8574', address=0x27, port=1, backlight_enabled=False)
print("LCD check")
#####
def main():
    try:
        f=open('/home/pi/python/rb_n.txt','r')
        tim1=f.readline()
        tim2=f.readline()
        a=int(tim1)
        b=int(tim2)
    #a = time1.tim1
    #b = time2.tim2
    #print(a,b)
        tgi(a)
        tri(b)
        ct.main()
    except KeyboardInterrupt:
        print("stop")
    except:
        print("Other error or exception occurred")
    finally:
        GPIO.cleanup()
main()