import os
cari=12
tim13=50
tim24=50
tim1=20
tim2=30
def time1():
    return tim1
def time2():
    return tim2
def cht(car):
    global tim1
    global tim2
    min_time = 30
    Rgcar_count = 30
    extime = 60
    len_count = 8
    if Rgcar_count - len_count < car < Rgcar_count:
        tim1 = extime - 8
        tim2 = extime + 8
    if Rgcar_count - len_count*2 < car < Rgcar_count - len_count:
        tim1 = extime - 8*2
        tim2 = extime + 8*2
    if Rgcar_count - len_count*3 < car < Rgcar_count - len_count*2:
        tim1 = extime - 8*3
        tim2 = extime + 8*3
    if car < Rgcar_count - len_count*3:
        tim1 = extime - 8*4
        tim2 = extime + 8*4
    if Rgcar_count < car < Rgcar_count + len_count:
        tim1 = extime + 8
        tim2 = extime - 8
    if Rgcar_count + len_count < car < Rgcar_count + len_count*2:
        tim1 = extime + 8*2
        tim2 = extime - 8*2
    if Rgcar_count + len_count*2 < car < Rgcar_count + len_count*3:
        tim1 = extime + 8*3
        tim2 = extime - 8*3
    if Rgcar_count + len_count*3 < car :
        tim1 = extime + 8*4
        tim2 = extime - 8*4
    if 0 < car <10 :
        tim1 = min_time
        tim2 = min_time
    if car == Rgcar_count :
        tim1 = extime
        tim2 = extime
def read():
    global cari
    f=open("/home/pi/python/text.txt","r")
    car=f.readline()
    print(car)
    cari=int(car)
def write(a,b):
    q=open('/home/pi/python/rb_n.txt','w')
    print(a,b)
    a=str(a)
    b=str(b)
    n=["\n"]
    q.writelines(a)
    q.writelines(n)
    q.writelines(b)
    q.writelines(n)
def main():
#    if tim13>max_time:
#       tim13=max_time
#    if tim13<min_time:
#       tim13=min_time
#    if tim24>max_time:
#       tim24=max_time
#    if tim24<min_time:
#       tim24=min_time
    #while True:
    os.system('gdrive download --force 1nzfnunIMwstH9fNje9hRrHRYb-hlhmid')
    read()
    cht(cari)
    write(tim1,tim2)
    print("download check")
main()
