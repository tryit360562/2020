import i2c_lcd as i2c
while True:
    i2c.main()