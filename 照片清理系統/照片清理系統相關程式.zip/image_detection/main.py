import tkinter as tk
from src.MainPage import Main_page
from src.ImportPage import Import_page
from src.BlurPage import Blur_page
from src.RepeatPage import Repeat_page
from src.WelcomePage import Welcome_page


class Application(Welcome_page, Main_page, Import_page, Blur_page, Repeat_page):

    def __init__(self):
        self.root = tk.Tk()
        self.goWelcome_page()

    def goWelcome_page(self):
        Welcome_page.__init__(self, self.root, self.goMain_page)

    def goMain_page(self):
        Main_page.__init__(self, self.root, self.goBlur_page, self.goRepeat_page)

    # def goImport_page(self):
    #     Import_page.__init__(self, self.root, self.goMain_page)

    def goBlur_page(self, dir_path):
        Blur_page.__init__(self, self.root, self.goMain_page, dir_path)

    def goRepeat_page(self, dir_path):
        Repeat_page.__init__(self, self.root, self.goMain_page, dir_path)


if __name__ == '__main__':
    Application()