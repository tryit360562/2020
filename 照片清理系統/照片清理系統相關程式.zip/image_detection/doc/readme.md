## 说明文档

### 1.所需环境

- 系统： windows或unix类的系统皆可
- 安装包及依赖： python3+,  tkinter， PIL



### 2. 模块说明

- main.py 主程序入口
- MainPage.py 主界面
- ImportPage.py 导入界面
- BlurPage.py 模糊界面
- RepeatPage.py 重复界面



### 3. 运行步骤

- 终端：

  1. cd  image_detection 
  2. python src/main.py

- Pycharm

  1. 配置好工作目录为项目根目录

  2. Run  main.py

