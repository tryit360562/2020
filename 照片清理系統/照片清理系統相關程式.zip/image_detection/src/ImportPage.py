import os
import tkinter as tk
from tkinter import filedialog, Scrollbar, Canvas
from PIL import Image
from PIL import ImageTk


class Import_page(object):
    def __init__(self, master, goMain_page):
        self.root = master
        self.goMain_page = goMain_page
        # 窗口大小
        self.root.geometry("300x500")
        self.width = 300
        self.height = 500
        # 窗口名
        self.root.title("導入照片")
        # 在窗口内定义一个frame
        self.page = tk.Frame(self.root)
        self.page.place(x=0, y=0, height=self.height, width=self.width)
        # self.page.pack()

        self.canvas = Canvas(self.page, bg="black", height=self.height-150, width=self.width)
        self.vsb = Scrollbar(self.page, orient="vertical", command=self.canvas.yview)
        # self.canvas.configure(yscrollcommand=self.vsb.set, scrollregion=(0, 0, 300, 800))
        # self.canvas.place(x=0, y=180, height=self.height, width=self.width)
        # self.canvas.grid(sticky="news", row=0)


        # 标签
        self.label_title = tk.Label(self.page,
                                    text='導入照片',  # 标签的文字
                                    bg='brown',  # 标签背景颜色
                                    font=('Arial Bold', 20),  # 字体和字体大小
                                    # width=20, height=3  # 标签长宽（以字符长度计算)
                                    )
        # self.label_title.place(x=100, y=20, height=60, width=100)
        self.label_title.pack(pady=20)

        # 选择文件夹按钮
        self.bt_choose_dir = tk.Button(self.page,
                                       text='選擇文件夾',
                                       fg='brown',
                                       font=('Arial Bold', 20),
                                       # width=18, height=3,
                                       command=self.choose_dir  # 点击事件
                                       )

        # self.bt_choose_dir.place(x=80, y=100, height=60, width=150)
        self.bt_choose_dir.pack(pady=10)

        # 返回按钮
        self.img = Image.open("resource/circle_return.png")
        self.img = self.img.resize((50, 50), Image.ANTIALIAS)
        self.photoImg = ImageTk.PhotoImage(self.img)
        self.roundedbutton = tk.Button(self.page, image=self.photoImg, borderwidth=0, command=self.return_main_page)
        self.roundedbutton.place(x=10, height=50, width=50)

        self.root.mainloop()

    def choose_dir(self):
        # 照片大小 n*n
        self.n = 128

        dir_path = filedialog.askdirectory()
        if dir_path:
            names = [name for name in os.listdir(dir_path)]
            images = [Image.open(dir_path + "/" + name).resize((self.n, self.n)) for name in names]
            photos = [ImageTk.PhotoImage(image) for image in images]

            i = 50
            j = 75
            for p in photos:
                self.canvas.create_image(i, j, image=p)
                i += 150
                if i / 150 > 2:
                    i = 50
                    j += 150
            self.vsb = Scrollbar(self.page, orient="vertical", command=self.canvas.yview)
            self.canvas.configure(yscrollcommand=self.vsb.set, scrollregion=(0, 0, 0, (150 * len(photos))/2))
            self.vsb.pack(side="right", fill='y')
            self.canvas.pack(side="bottom")
            self.root.mainloop()


    def return_main_page(self):
        self.page.destroy()
        self.goMain_page()
