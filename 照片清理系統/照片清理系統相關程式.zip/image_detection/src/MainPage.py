import tkinter as tk
from tkinter import filedialog, messagebox


class Main_page(object):
    def __init__(self, master, goBlurPage, goRepeatPage):
        self.root = master
        self.goBlurPage = goBlurPage
        self.goRepeatPage = goRepeatPage
        self.dir_path = None
        # 窗口大小
        self.root.geometry("300x500")
        # 窗口名
        self.root.title("圖片管理系統")
        # 在窗口内定义一个frame
        self.main_page = tk.Frame(self.root)
        self.main_page.pack()

        self.label_title = tk.Label(self.main_page,
                                    text='照片管理系统',  # 标签的文字
                                    bg='brown',  # 标签背景颜色
                                    font=('Arial Bold', 20),  # 字体和字体大小
                                    width=20, height=3  # 标签长宽（以字符长度计算）
                                    )
        self.label_title.pack(side=tk.TOP, padx=3, pady=3)
        # 导入照片按钮
        self.bt_import_image = tk.Button(self.main_page,
                                         text='選擇原始文件夾',
                                         bg='brown',
                                         font=('Arial Bold', 20),
                                         width=18, height=1,
                                         command=self.choose_dir  # 点击事件
                                         )

        self.bt_import_image.pack(pady=20)
        # 模糊照片按钮
        self.bt_blur_image = tk.Button(self.main_page,
                                       text='模糊照片整理',
                                       bg='pink',
                                       font=('Arial Bold', 20),
                                       width=18, height=2,
                                       command=self.blur_image  # 点击事件
                                       )

        self.bt_blur_image.pack(pady=20)

        # 重复照片按钮
        self.bt_repeat_image = tk.Button(self.main_page,
                                         text='相似照片整理',
                                         bg='pink',
                                         font=('Arial Bold', 20),
                                         width=18, height=2,
                                         command=self.repeat_image  # 点击事件
                                         )

        self.bt_repeat_image.pack(pady=20)
        self.root.mainloop()

    def choose_dir(self):
        self.dir_path = filedialog.askdirectory()

    def blur_image(self):
        if not self.dir_path:
            messagebox.showerror("錯誤", "無選擇圖片文件夾")
        else:
            self.main_page.destroy()
            self.goBlurPage(self.dir_path)

    def repeat_image(self):
        if not self.dir_path:
            messagebox.showerror("錯誤", "無選擇圖片文件夾")
        else:
            self.main_page.destroy()
            self.goRepeatPage(self.dir_path)
