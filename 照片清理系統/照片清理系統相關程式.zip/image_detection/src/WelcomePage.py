import tkinter as tk
from PIL import Image, ImageTk


class Welcome_page(object):
    def __init__(self, master, goMainPage):
        self.root = master
        self.goMainPage = goMainPage
        # 窗口大小
        self.root.geometry("300x500")
        # 窗口名
        self.root.title("圖片管理系統")
        # 在窗口内定义一个frame
        self.welcome_page = tk.Frame(self.root)
        self.welcome_page.pack()

        self.label_title = tk.Label(self.welcome_page,
                                    text='照片管理系统',  # 标签的文字
                                    bg='brown',  # 标签背景颜色
                                    font=('Arial Bold', 20),  # 字体和字体大小
                                    width=31, height=2  # 标签长宽（以字符长度计算）
                                    )
        self.label_title.pack(side=tk.TOP, padx=0, pady=0)

        # 欢迎界面图片
        self.img = Image.open("resource/welcome_image.png")
        self.img = self.img.resize((280, 260), Image.ANTIALIAS)
        self.photoImg = ImageTk.PhotoImage(self.img)
        self.image_label = tk.Label(self.welcome_page, image=self.photoImg)
        self.image_label.pack(padx=0, pady=0)

        # 系统说明
        self.instructions_label = tk.Label(self.welcome_page,
                                           text='''此系統主要包含2個功能\n模糊圖片識別和相似圖片識別\n點即開始進入系統''',
                                           bg='grey',
                                           font=('Arial Bold', 15),
                                           width=32, height=4)
        # self.instructions_label.place(x=0, y=350, height=200, width=300)
        self.instructions_label.pack(pady=3)

        # 开始进入系统
        self.bt_start = tk.Button(self.welcome_page,
                                  text='開始',
                                  bg='red',
                                  font=('Arial Bold', 20),
                                  width=18, height=3,
                                  command=self.go_main_page  # 点击事件
                                  )

        # self.bt_start.place(x=0, y=350, height=200, width=100)
        self.bt_start.pack(pady=3)
        self.root.mainloop()

    def go_main_page(self):
        self.welcome_page.destroy()
        self.goMainPage()
