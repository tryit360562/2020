import os
from tkinter import filedialog, Canvas, messagebox, StringVar
import tkinter as tk
from PIL import Image
from PIL import ImageTk
from src.similar_pic_pro import simliarval

class Repeat_page:
    def __init__(self, master, goMain_page, dir_path):
        self.root = master
        self.goMain_page = goMain_page
        # 窗口大小
        self.root.geometry("300x500")
        self.width = 300
        self.height = 500
        self.dir_path = dir_path
        self.save_path = None
        # 窗口名
        self.root.title("相似照片")
        # 在窗口内定义一个frame
        self.page = tk.Frame(self.root)
        self.page.place(x=0, y=0, height=self.height, width=self.width)

        self.label_title = tk.Label(self.page,
                                    text='相似照片整理',  # 标签的文字
                                    bg='pale green',  # 标签背景颜色
                                    font=('Arial Bold', 20),  # 字体和字体大小
                                    # width=20, height=3  # 标签长宽（以字符长度计算)
                                    )
        # self.label_title.place(x=100, y=20, height=60, width=100)
        self.label_title.pack(pady=20)

        # 选择文件夹按钮
        self.bt_choose_dir = tk.Button(self.page,
                                       text='選擇相似照片存儲位置',
                                       fg='pale green',
                                       bg='black',
                                       font=('Arial Bold', 20),
                                       # width=18, height=3,
                                       command=self.choose_save_path  # 点击事件
                                       )
        self.bt_choose_dir.pack(pady=20)
        # self.bt_choose_dir.place(x=80, y=100, height=60, width=150)

        self.bt_clear_up = tk.Button(self.page,
                                       text='整理照片',
                                       fg='pale green',
                                       bg='black',
                                       font=('Arial Bold', 20),
                                       # width=18, height=3,
                                       command=self.save_repeat_image  # 点击事件
                                       )

        # self.bt_choose_dir.place(x=80, y=100, height=60, width=150)
        self.bt_clear_up.pack(pady=20)
        self.canvas = Canvas(self.page, width=200, height=50, bg="white")
        self.canvas.pack(pady=10)
        self.x = StringVar()
        # 进度条以及完成程度
        # out_rec = canvas.create_rectangle(5, 5, 105, 25, outline="blue", width=1)
        self.fill_rec = self.canvas.create_rectangle(2, 2, 0, 55, outline="", width=0, fill="green")

        tk.Label(self.page, textvariable=self.x).pack()

        # 返回按钮
        self.img = Image.open("resource/circle_return.png")
        self.img = self.img.resize((50, 50), Image.ANTIALIAS)
        self.photoImg = ImageTk.PhotoImage(self.img)
        self.roundedbutton = tk.Button(self.page, image=self.photoImg, borderwidth=0, command=self.return_main_page)
        self.roundedbutton.place(x=10, height=50, width=50)

        self.root.mainloop()

    def choose_save_path(self):
        self.save_path = filedialog.askdirectory()

    def save_repeat_image(self):
        if self.save_path:
            # ********** 此处调用重复图片筛选函数 **********
            simliarval(self.dir_path, self.save_path, self.root, self.canvas, self.x, self. fill_rec)
            # ********* end ***********
            self.x.set("整理完成")
        else:
            messagebox.showerror("錯誤", "未選擇資料文件夾")


    def return_main_page(self):
        self.page.destroy()
        self.goMain_page()