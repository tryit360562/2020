#!/usr/bin/env python
# coding: utf-8

#照片分为：模糊blured，疑似模糊maybe

import os
import cv2
import time
import math
import shutil
import numpy as np
import lightgbm as lgb


def brenner(img):
    """
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    """
    shape = np.shape(img)
    out = 0
    for x in range(0, shape[0]-2):
        for y in range(0, shape[1]):
            out += (int(img[x+2,y])-int(img[x,y]))**2
    return out


# 拉普拉斯算子计算图片边缘，图片越模糊，其边缘就越少
def Lapulase(img):
    """
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    """
    return cv2.Laplacian(img,cv2.CV_64F).var()


# SMD梯度函数计算
def SMD(img):
    """
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    """
    shape = np.shape(img)
    out = 0
    for x in range(1, shape[0]-1):
        for y in range(0, shape[1]):
            out += math.fabs(int(img[x, y])-int(img[x,y-1]))
            out += math.fabs(int(img[x, y]-int(img[x+1,y])))
    return out


# SMD2梯度函数计算
def SMD2(img):
    """
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    """
    shape = np.shape(img)
    out = 0
    for x in range(0, shape[0]-1):
        for y in range(0, shape[1]-1):
            out += math.fabs(int(img[x, y])-int(img[x+1, y]))*math.fabs(int(img[x, y]-int(img[x, y+1])))
    return out


# 方差函数计算
def variance(img):
    """
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    """
    out = 0
    u = np.mean(img)
    shape = np.shape(img)
    for x in range(0, shape[0]):
        for y in range(0, shape[1]):
            out += (img[x, y]-u)**2
    return out


# energy函数计算
def energy(img):
    """
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    """
    shape = np.shape(img)
    out = 0
    for x in range(0, shape[0]-1):
        for y in range(0, shape[1]-1):
            out += ((int(img[x+1, y])-int(img[x, y]))**2)*((int(img[x, y+1]-int(img[x, y])))**2)
    return out


# Vollath函数计算
def Vollath(img):
    """
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    """
    shape = np.shape(img)
    u = np.mean(img)
    out = -shape[0]*shape[1]*(u**2)
    for x in range(0, shape[0]-1):
        for y in range(0, shape[1]):
            out += int(img[x, y])*int(img[x+1,y])
    return out


# entropy函数计算
def entropy(img):
    """
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    """
    out = 0
    count = np.shape(img)[0]*np.shape(img)[1]
    p = np.bincount(np.array(img).flatten())
    for i in range(0, len(p)):
        if p[i] != 0:
            out -= p[i]*math.log(p[i]/count)/count
    return out


def Get_score(img):
    score1 = Lapulase(img)

    score2 = brenner(img)
    # print(score2)

    score3 = SMD(img)
    # print(score3)

    score4 = SMD2(img)
    # print(score4)

    score5 = variance(img)
    # print(score5)

    score6 = energy(img)
    #print(score6)

    score7 = Vollath(img)
    #print(score7)

    score8 = entropy(img)
    #print(score8)

    img_test_data = [score1, score2, score3, score4, score5, score6, score7, score8]
    
    
    return img_test_data
    

def Save_data(data):
    mytest_data_array = np.array(data).reshape(-1, 8)
    np.savetxt("data/temp_test_feature.txt", mytest_data_array)


# 建立文件夹
def mkdir(dir_name):
    if not os.path.exists(dir_name):
        os.mkdir(dir_name)


# 移动文件
def move(src, dst):
    shutil.move(src, dst)


def recognition(src_path, dst_path, root, canvas, x, fill_rec):
    test_feature_array = []
    imgs = os.listdir(src_path)
    # -----------------------
    # 测试部分
    # imgs = ["sh344.JPG", "bm79.JPG"]
    # -----------------------
    testpic_num = np.size(imgs)

    # print("正在生成特征...")
    x.set("正在生成特征...")
    root.update()
    i = 0

    for img_name in imgs:
        if img_name.endswith(".JPG"):
            img_path = os.path.join(src_path, img_name)
            # 读取图片
            org_img = cv2.imread(img_path)

            rs_img = cv2.resize(org_img,(1024,1024),interpolation=cv2.INTER_CUBIC)  # 图片大小统一化
            wd, ht, c = rs_img.shape
            wid = int(wd/2);higt = int(ht/2)
            cropImg = rs_img[(wid-256):(wid+256),(higt-256):(higt+256)]  # 获取感兴趣区

            # 均值滤波
            blurImg = cv2.blur(cropImg, (5,5))

            # 灰度图片
            img2gray = cv2.cvtColor(blurImg, cv2.COLOR_BGR2GRAY)

            # 计算图片特征（8个）
            img_test_feature = Get_score(img2gray)
            test_feature_array.append(img_test_feature)

            # 以矩形的长度作为变量值更新
            canvas.coords(fill_rec, (5, 5, 1 + (i / (testpic_num-1)) * 200, 55))
            root.update()
            x.set(str(round(i / (testpic_num-1) * 100, 2)) + '%')
            # if round(i / (size-1) * 100, 2) == 100.00:
            #     x.set("完成")
            time.sleep(0.01)
            i += 1
            # 每循环一次更新一个进度条
    
    Save_data(test_feature_array)
    x.set("生成特征完成!")

    # 模型加载
    gbm = lgb.Booster(model_file='resource/model.txt')
    x.set("移动图片...")
    # 载入测试数据
    threshold_value1 = 0.35
    threshold_value2 = 0.6
    X_test = np.loadtxt("data/temp_test_feature.txt")

    # 模型预测
    y_pred = gbm.predict(X_test, num_iteration=gbm.best_iteration)

    y_pred_new = []

    for y in y_pred:
        if y>=threshold_value2:
            result = 2
        elif y>=threshold_value1:
            result = 1
        else: result = 0        
                
        y_pred_new.append(result)

    # 为确保文件夹里可能还有其他非图片文件
    testpic_num = i
    # 将模糊照片放入dst_path
    dst_path1 = os.path.join(dst_path,'blured')
    mkdir(dst_path1)
    dst_path2 = os.path.join(dst_path,'maybe')
    mkdir(dst_path2)
    
    for i in range(testpic_num):
        # if img_name.endswith(".JPG"):
        img_path = os.path.join(src_path,imgs[i])
        
        
        if y_pred_new[i] == 0:
            shutil.move(img_path, dst_path1)
        elif y_pred_new[i] == 1:
            shutil.move(img_path, dst_path2)

    # print('模糊照片清理完成')
