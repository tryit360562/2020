#ifndef __EXTRINSIC_CALIBRATION_HPP__
#define __EXTRINSIC_CALIBRATION_HPP__

void extrinsic_calibration(void); 

#endif