#ifndef __COLOR_CALIBRATION_HPP__
#define __COLOR_CALIBRATION_HPP__

bool load_color_calibration(std::string yaml_path);
void hsv_color_thresholding_calibration(void);

#endif