#ifndef __INTRINSIC_CALIBRATION_HPP__
#define __INTRINSIC_CALIBRATION_HPP__

void intrinsic_calibration(void);

#endif