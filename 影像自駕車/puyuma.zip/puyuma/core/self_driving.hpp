#ifndef __SELF_DRIVING_HPP__
#define __SELF_DRIVING_HPP__

#define THROTTLE_BASE 45 //45% of the throttle

typedef struct {
        float kp, ki, kd;
} pid_control_t;

//void self_driving_control(cv::Mat& raw_image, float d, float phi, bool stop_motor_sign);
void self_driving_control(raspicam::RaspiCam_Cv& camera, float d, float phi, bool stop_motor_sign);


void load_pid_param(string yaml_path);
static double angle(cv::Point pt1, cv::Point pt2, cv::Point pt0);
void setLabel(cv::Mat& im, const std::string label, std::vector<cv::Point>& contour);
//int shape(cv::Mat& raw_image);
int shape(raspicam::RaspiCam_Cv& camera);

#endif
