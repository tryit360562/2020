#include <raspicam/raspicam_cv.h>
#include<opencv2/opencv.hpp>
#include <yaml-cpp/yaml.h>
#include <unistd.h>
#include "common.hpp"
#include "motor.hpp"
#include "lane_detector.hpp"
#include "self_driving.hpp"

using  namespace std;
using namespace cv;

pid_control_t pid_d;
pid_control_t pid_phi;

void load_pid_param(string yaml_path)
{
    try {
        YAML::Node yaml = YAML::LoadFile(yaml_path);

        pid_d.kp = yaml["pid_d"]["kp"].as<float>();
        pid_d.ki = yaml["pid_d"]["ki"].as<float>();
        pid_d.kd = yaml["pid_d"]["kd"].as<float>();
        pid_phi.kp = yaml["pid_phi"]["kp"].as<float>();
        pid_phi.ki = yaml["pid_phi"]["ki"].as<float>();
        pid_phi.kd = yaml["pid_phi"]["kd"].as<float>();

        cout << "[PID d controller]\n" <<
            "Kp: " << pid_d.kp <<  ", Ki: " << pid_d.ki << ", Kd:" << pid_d.kd <<
            "[PID phi controller]\n" <<
            "Kp: " << pid_phi.kp <<  ", Ki: " << pid_phi.ki << ", Kd:" << pid_phi.kd;
    } catch(...) {
        cout << "failed to load PID parameters, load default.\n" <<
            "[PID d controller]\n" <<
            "Kp: 0, Ki: 0, Kd: 0\n" <<
            "[PID phi controller]\n" <<
            "Kp: 0, Ki: 0, Kd: 0\n";

        pid_d.kp = 0;
        pid_d.ki = 0;
        pid_d.kd = 0;
        pid_phi.kp = 0;
        pid_phi.ki = 0;
        pid_phi.kd = 0;
    }
}

static float pid_control(int current_value, float setpoint, pid_control_t& pid)
{
    //a p controller is already good enough for this case
    return pid.kp * (current_value - setpoint);
}

/* the puyuma self-driving algorithm is a cascaded p controller */
//void self_driving_control(cv::Mat& raw_image,float d, float phi, bool stop_motor_sign)
void self_driving_control(raspicam::RaspiCam_Cv& camera,float d, float phi, bool stop_motor_sign)
{
    if(stop_motor_sign == true){
        cout << stop_motor_sign;
        halt_motor();
        //cout << shape(raw_image);
        int Direction =  shape(camera);  //0.Geradeaus 1.Rechts 2.Links
        if(Direction==0){
            cout << "Circle detected\n";
            set_straight_pwm(26, 25);
            sleep(2);
            return;
        }
        else if(Direction==1){
            cout << "Triangle detected\n";
            set_turnL_pwm(25, 20);
            sleep(2);
            return;
        }
        else if (Direction==2){
            cout << "Rectangle detected\n";
            set_turnR_pwm(20, 30);
            sleep(1);
            return;
        }
    cout << "Nothing detected";
    return;
    }
    int pwm_left, pwm_right;

    float d_setpoint = -2.5f; //[cm]
    float phi_setpoint = pid_control(d, d_setpoint, pid_d);

    bound(PHI_MIN, PHI_MAX, phi_setpoint);

    //cascading d controller with phi, controlling the d by changing phi setpoint
    int pwm = (int)pid_control(phi, phi_setpoint, pid_phi);

    pwm_left = THROTTLE_BASE + pwm;
    pwm_right = THROTTLE_BASE - pwm;

    bound(MOTOR_PWM_MIN, MOTOR_PWM_MAX, pwm_left);
    bound(MOTOR_PWM_MIN, MOTOR_PWM_MAX, pwm_right);

    set_motor_pwm(pwm_left, pwm_right);
}










////////////////////////////////////////////////////////// shape detect test

static double angle(cv::Point pt1, cv::Point pt2, cv::Point pt0)
{
        double dx1 = pt1.x - pt0.x;
        double dy1 = pt1.y - pt0.y;
        double dx2 = pt2.x - pt0.x;
        double dy2 = pt2.y - pt0.y;
        return (dx1*dx2 + dy1*dy2)/sqrt((dx1*dx1 + dy1*dy1)*(dx2*dx2 + dy2*dy2) + 1e-10);
}


//  * 輔助功能可在輪廓中心顯示文本(形狀)
 
void setLabel(cv::Mat& im, const std::string label, std::vector<cv::Point>& contour)
{
        int fontface = cv::FONT_HERSHEY_SIMPLEX;
        double scale = 0.4;
        int thickness = 1;
        int baseline = 0;

        cv::Size text = cv::getTextSize(label, fontface, scale, thickness, &baseline);
        cv::Rect r = cv::boundingRect(contour);

        cv::Point pt(r.x + ((r.width - text.width) / 2), r.y + ((r.height + text.height) / 2));
        cv::rectangle(im, pt + cv::Point(0, baseline), pt + cv::Point(text.width, -text.height), CV_RGB(0,0,0), CV_FILLED);
        cv::putText(im, label, pt, fontface, scale, CV_RGB(255,255,255), thickness, 8);
}

//int detectColor(Mat image);
//int shape(cv::Mat& raw_image){
int shape(raspicam::RaspiCam_Cv& camera){
    camera.release();
        int shapecount = 0;
        int random = 0;
        int circlecount = 0,trianglecount = 0,rectanglecount = 0;
        char direction;//0直走 1左 2右
cout<<"camera release"<<endl;
        //cv::Mat src = cv::imread("polygon.png");
        VideoCapture capture(0);

        while(1){
                cv::Mat src, color;
                capture>>src;


//src=raw_image;
         src = src(cv::Rect(320,100,150,70));
//                src = src(cv::Rect(300,70,170,150)); //偵測範圍中後 左上角x y 寬 高



//              color = Mat::zeros(src.size(), src.type());
//              if (src.empty())
//              return -1;

                // 轉灰階
                cv::Mat gray;

                cv::cvtColor(src, gray, CV_BGR2GRAY);
                //range = gray(Range(10,100),Range(10,100));

                // 使用Canny而不是threshold來捕獲帶有漸變底紋的正方形
                cv::Mat bw;
                cv::Canny(gray, bw, 0, 0, 5);


                // 查找輪廓
                std::vector<std::vector<cv::Point> > contours;
                cv::findContours(bw.clone(), contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);

                std::vector<cv::Point> approx;
                cv::Mat dst = src.clone();


                if(circlecount>=10 || trianglecount>=10 || rectanglecount>=10){
                        if(circlecount>=10){
                                cout<<"Go Straight"<<endl;
                                cout<<"Circle: "<<circlecount<<" Triangle: "<<trianglecount<<" Rectangle: "<<rectanglecount<<endl;
                capture.release();camera.open();
                                return 0;
                        }
                        else if(trianglecount>=10){
                                cout<<"Turn left"<<endl;
                                cout<<"Circle: "<<circlecount<<" Triangle: "<<trianglecount<<" Rectangle: "<<rectanglecount<<endl;
                capture.release();camera.open();
                                return 1;
                        }
                        else if(rectanglecount>=10){
                                cout<<"Turn right"<<endl;
                                cout<<"Circle: "<<circlecount<<" Triangle: "<<trianglecount<<" Rectangle: "<<rectanglecount<<endl;
                                capture.release();camera.open();
                return 2;
                        }
                }

//亂數產生
                random++;

                if(random>50){
                        cout<<"time out ,Turn left"<<endl;
                        cout<<"Circle: "<<circlecount<<" Triangle: "<<trianglecount<<" Rectangle: "<<rectanglecount<<endl;
                        capture.release();camera.open();
            return 1;
                }





                for (int i = 0; i < contours.size(); i++)
                {
                        // 近似輪廓，精度成正比
                        // 到輪廓周長
                        cv::approxPolyDP(cv::Mat(contours[i]), approx, cv::arcLength(cv::Mat(contours[i]), true)*0.02, true);

                        // Skip small or non-convex objects 跳過小的或不凸的對象
                        if (std::fabs(cv::contourArea(contours[i])) < 100 || !cv::isContourConvex(approx))
                                continue;

                        if (approx.size() == 3 || approx.size() == 1)
                        {
                                setLabel(dst, "TRI", contours[i]);    // Triangles

                                shapecount++;
                                trianglecount++;
                                if(shapecount>1){
                                        if(direction=='1'){
                                                cout<<"shape is TRIANGLE true, Turn Left"<<endl;
                                        }
                                        else if(direction=='2'){
                                                cout<<"shape is TRIANGLE false RECTANGLE"<<endl;
                                        }
                                        else if(direction=='0'){
                                                cout<<"shape is TRIANGLE false CIRCLE"<<endl;
                                        }


                                }
                                direction = '1';
                        }
                        else if (approx.size() >= 4 && approx.size() <= 6)
                        {
                                // 多邊形曲線的折點數
                                int vtc = approx.size();

                                // 獲取所有角的餘弦
                                std::vector<double> cos;
                                for (int j = 2; j < vtc+1; j++)
                                        cos.push_back(angle(approx[j%vtc], approx[j-2], approx[j-1]));

                                // 升序排列
                                std::sort(cos.begin(), cos.end());

                                // 獲得最低和最高的餘弦
                                double mincos = cos.front();
                                double maxcos = cos.back();

                                // 使用上面獲得的度數和頂點數
                                // 確定輪廓的形狀
                                if (vtc == 4 && mincos >= -0.1 && maxcos <= 0.3){
                                        setLabel(dst, "RECT", contours[i]);

                                        rectanglecount++;
                                        shapecount++;
                                        if(shapecount>1){
                                                if(direction=='2'){
                                                        cout<<"shape is RECTANGLE true, Turn right"<<endl;
                                                }
                                                else if(direction=='1'){
                                                        cout<<"shape is RECTANGLE false TRIANGLE"<<endl;
                                                }
                                                else if(direction=='0'){
                                                        cout<<"shape is RECTANGLE false CIRCLE"<<endl;
                                                }


                                        }
                                        direction = '2';


                                }
                                else if (vtc == 5 && mincos >= -0.34 && maxcos <= -0.27)
                                        setLabel(dst, "PENTA", contours[i]);
                                else if (vtc == 6 && mincos >= -0.55 && maxcos <= -0.45)
                                        setLabel(dst, "HEXA", contours[i]);
                        }
                        else
                        {
                                // 檢測並標記 circles
                                double area = cv::contourArea(contours[i]);
                                cv::Rect r = cv::boundingRect(contours[i]);
                                int radius = r.width / 2;

                                if (std::abs(1 - ((double)r.width / r.height)) <= 0.2 &&
                                    std::abs(1 - (area / (CV_PI * std::pow(radius, 2)))) <= 0.2){

                                        setLabel(dst, "CIR", contours[i]);

                                        circlecount++;
                                        shapecount++;
                                        if(shapecount>1){
                                                if(direction=='0'){
                                                        cout<<"shape is CIRCLE true, Go straight"<<endl;
                                                }
                                                else if(direction=='1'){
                                                        cout<<"shape is CIRCLE false TRIANGLE"<<endl;
                                                }
                                                else if(direction=='2'){
                                                        cout<<"shape is CIRCLE false TRIANGLE"<<endl;
                                                }


                                        }
                                        direction = '0';

                                }

                        }
                }
//              cv::imshow("raw", raw_image);
                cv::imshow("result", dst);
//              cv::imshow("bw", bw);
                cv::waitKey(10);

        }
//        return 0;

}
